import { motion, AnimatePresence } from 'motion/react';
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../../store/useStore';
import { 
  LogOut, 
  GraduationCap, 
  Clock, 
  PlayCircle, 
  Target, 
  TrendingUp, 
  X, 
  CheckCircle2, 
  Lock, 
  BookOpen, 
  Calendar, 
  ArrowLeft, 
  Search, 
  Sparkles, 
  Check, 
  HelpCircle, 
  Phone, 
  Award, 
  Layers,
  ChevronLeft,
  ChevronRight,
  Copy,
  Tag,
  MapPin,
  Laptop,
  ArrowRight,
  ChevronDown,
  Trophy,
  Medal,
  User,
  Users,
  Menu,
  FileText,
  AlertTriangle
} from 'lucide-react';
import { format } from 'date-fns';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Exam, Course, AppEvent } from '../../types';
import NotificationCenter from '../../components/NotificationCenter';

export default function StudentDashboard() {
  const navigate = useNavigate();
  const { 
    currentUser, 
    exams, 
    results, 
    logout, 
    payments, 
    paymentConfig, 
    submitPayment, 
    courses, 
    events,
    enrollInCourse,
    joinEvent,
    categories,
    users,
    faqs
  } = useStore();
  
  // Navigation states
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [selectedEvent, setSelectedEvent] = useState<AppEvent | null>(null);
  const [isMyCoursesOpen, setIsMyCoursesOpen] = useState(false);
  
  // Tab level state
  const [currentTab, setCurrentTab] = useState<'home' | 'exams' | 'results' | 'leaderboard' | 'routine' | 'report' | 'faq'>('home');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [selectedLeaderboardExamId, setSelectedLeaderboardExamId] = useState<string>('');
  const [leaderboardSearchQuery, setLeaderboardSearchQuery] = useState<string>('');
  const [resultsSearchQuery, setResultsSearchQuery] = useState<string>('');
  
  // Custom Exam Section Filters
  const [examSelectCourseId, setExamSelectCourseId] = useState<string>('');
  const [examSelectDate, setExamSelectDate] = useState<string>('');
  const [examSearchPracticeQuery, setExamSearchPracticeQuery] = useState<string>('');
  const [examSubTab, setExamSubTab] = useState<'quick' | 'upcoming'>('quick');
  
  // Search & Filter states for Main Grid
  const [selectedBatch, setSelectedBatch] = useState<string>('All Batches');
  const [selectedSubject, setSelectedSubject] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeSegment, setActiveSegment] = useState<'courses' | 'events' | 'public'>('courses');

  // Checkout states
  const [paymentTarget, setPaymentTarget] = useState<{ 
    id: string; 
    type: 'exam' | 'course' | 'event'; 
    title: string; 
    amount: number; 
  } | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<'bkash' | 'nagad' | 'rocket'>('bkash');
  const [trxId, setTrxId] = useState('');
  const [copiedNumber, setCopiedNumber] = useState<string | null>(null);

  const handleCopyToClipboard = (num: string) => {
    if (!num) return;
    navigator.clipboard.writeText(num).then(() => {
      setCopiedNumber(num);
      setTimeout(() => {
        setCopiedNumber(null);
      }, 2000);
    }).catch(err => {
      console.error('Failed to copy text: ', err);
    });
  };

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  // Promotional slider states
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);

  const enrolledCourseIds = currentUser?.enrolledCourses || [];
  const joinedEventIds = currentUser?.joinedEvents || [];

  const promotedCourses = React.useMemo(() => courses.filter(c => c.isPromoted), [courses]);
  const promotedEvents = React.useMemo(() => events.filter(e => e.isPromoted), [events]);

  const sliderSlides = React.useMemo(() => {
    const list = [
      {
        id: 'eid_welcome',
        type: 'announcement',
        title: 'Prepare for Excellence',
        description: 'Participate in live exam sessions, complete board practice questions, and elevate your academic achievements with detailed performance charts.',
        badge: '🌙 আসসালামু আলাইকুম — OTS Live Exam Hall',
        tagLine: '🌙 ঈদুল আযহা মোবারক!',
        bannerUrl: 'https://images.unsplash.com/photo-1518156677180-95a2893f3e9f?w=1600&q=80',
        actionText: 'Connect Support Helpline',
        action: () => {
          const element = document.getElementById('ots-support-section');
          if (element) {
            element.scrollIntoView({ behavior: 'smooth' });
          }
        }
      }
    ];

    promotedCourses.forEach(c => {
      const cost = (c.feeAmount || 0) - (c.discountAmount || 0);
      list.push({
        id: c.id,
        type: 'course',
        title: c.title,
        description: c.description || 'Unlock supreme admissions guide and test patterns compiled for the latest syllabus.',
        badge: `📖 Promoted Course • ${c.category || 'Batch Session'}`,
        tagLine: c.isPaid ? `Featured Course • ৳${cost}` : 'Free Learning Program',
        bannerUrl: c.bannerUrl || 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=1600&q=80',
        actionText: enrolledCourseIds.includes(c.id) ? 'Access Course Board' : 'Enquire & Enroll',
        action: () => {
          setSelectedCourse(c);
          setActiveSegment('courses');
        }
      });
    });

    promotedEvents.forEach(e => {
      const cost = (e.feeAmount || 0) - (e.discountAmount || 0);
      list.push({
        id: e.id,
        type: 'event',
        title: e.title,
        description: e.description || 'Special interactive event with live instruction, doubt solver, and board exam hacks.',
        badge: `⚡ Featured Live Event`,
        tagLine: e.isPaid ? `Exclusive Masterclass • ৳${cost}` : 'Free Admission Seminar',
        bannerUrl: e.bannerUrl || 'https://images.unsplash.com/photo-1546410531-bb4caa6b424d?w=1600&q=80',
        actionText: joinedEventIds.includes(e.id) ? 'View Joined Event' : 'Register Now',
        action: () => {
          setSelectedEvent(e);
          setActiveSegment('events');
        }
      });
    });

    return list;
  }, [promotedCourses, promotedEvents, courses, events, enrolledCourseIds, joinedEventIds]);

  React.useEffect(() => {
    setCurrentSlideIndex(0);
  }, [sliderSlides.length]);

  React.useEffect(() => {
    if (sliderSlides.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentSlideIndex(prev => (prev + 1) % sliderSlides.length);
    }, 6000);
    return () => clearInterval(interval);
  }, [sliderSlides.length]);

  // Helper check to verify if course / event is unlocked or enrolled
  const isCourseEnrolled = (courseId: string) => enrolledCourseIds.includes(courseId);
  const isEventJoined = (eventId: string) => joinedEventIds.includes(eventId);

  // Check verification of paid course/event via payments list
  const isCoursePaymentVerified = (id: string, course: Course) => {
    if (!course.isPaid) return true;
    if (isCourseEnrolled(id)) return true;
    const pay = payments.find(p => p.userId === currentUser?.id && p.targetId === id && p.targetType === 'event');
    return pay?.status === 'verified';
  };

  const isEventPaymentVerified = (id: string, event: AppEvent) => {
    if (!event.isPaid) return true;
    if (isEventJoined(id)) return true;
    const pay = payments.find(p => p.userId === currentUser?.id && p.targetId === id && p.targetType === 'event');
    return pay?.status === 'verified';
  };

  // Safe Start Attempt hook
  const handleStartAttempt = (exam: Exam) => {
    if (exam.isPaid) {
      const existingPayment = payments.find(
        p => p.userId === currentUser?.id && p.targetId === exam.id && p.targetType === 'exam'
      );
      if (existingPayment?.status === 'verified') {
        navigate(`/student/exam/${exam.id}`);
      } else if (existingPayment?.status === 'pending') {
        alert('Your exam payment is currently being verified by an admin. Please check back later.');
      } else {
        setPaymentTarget({
          id: exam.id,
          type: 'exam',
          title: exam.title,
          amount: (exam.feeAmount || 0) - (exam.discountAmount || 0)
        });
      }
    } else {
      navigate(`/student/exam/${exam.id}`);
    }
  };

  // Safe course enrollment flow with bkash checker
  const handleCourseEnrollClick = (course: Course) => {
    if (!currentUser) return;
    if (course.isPaid) {
      // Check if there is already a payment or if enrolled
      if (isCourseEnrolled(course.id)) return;
      const existingPayment = payments.find(
        p => p.userId === currentUser.id && p.targetId === course.id && p.targetType === 'event'
      );
      
      if (existingPayment?.status === 'verified') {
        enrollInCourse(currentUser.id, course.id);
        alert('Access instantly unlocked! Dive into your course.');
      } else if (existingPayment?.status === 'pending') {
        alert('Your batch payment is currently being reviewed by our admin team.');
      } else {
        // Direct checkout Modal trigger
        setPaymentTarget({
          id: course.id,
          type: 'course',
          title: course.title,
          amount: (course.feeAmount || 0) - (course.discountAmount || 0)
        });
      }
    } else {
      enrollInCourse(currentUser.id, course.id);
    }
  };

  // Safe event joining flow with payments check
  const handleEventJoinClick = (event: AppEvent) => {
    if (!currentUser) return;
    if (event.isPaid) {
      if (isEventJoined(event.id)) return;
      const existingPayment = payments.find(
        p => p.userId === currentUser.id && p.targetId === event.id && p.targetType === 'event'
      );
      if (existingPayment?.status === 'verified') {
        joinEvent(currentUser.id, event.id);
        alert('Access unlocked! Welcome to the Masterclass Event.');
      } else if (existingPayment?.status === 'pending') {
        alert('Your event registration fee verification is pending admin reviews.');
      } else {
        // Direct checkout Modal trigger
        setPaymentTarget({
          id: event.id,
          type: 'event',
          title: event.title,
          amount: (event.feeAmount || 0) - (event.discountAmount || 0)
        });
      }
    } else {
      joinEvent(currentUser.id, event.id);
    }
  };

  // Unified Payment Submit
  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!paymentTarget || !currentUser || !trxId) return;

    // Save payment
    submitPayment({
      userId: currentUser.id,
      targetId: paymentTarget.id,
      targetType: paymentTarget.type === 'exam' ? 'exam' : 'event',
      amount: paymentTarget.amount,
      method: paymentMethod,
      trxId
    });

    setTrxId('');
    setPaymentTarget(null);
    alert('Payment details submitted! You are instantly enrolled for test verification. Admin will verify your transaction ID shortly.');
  };

  // Eligible exams calculation
  const eligibleExams = exams.filter(e => {
    if (e.accessType === 'private') return false;
    if (e.accessType === 'course') return e.courseIds?.some(id => enrolledCourseIds.includes(id));
    if (e.accessType === 'event') return e.eventIds?.some(id => joinedEventIds.includes(id));
    return true; // public
  });

  // Stats
  const userResults = results
    .filter(r => r.userId === currentUser?.id)
    .sort((a, b) => a.submittedAt - b.submittedAt);

  const performanceData = userResults.map(result => {
    const exam = exams.find(e => e.id === result.examId);
    return {
      name: exam?.title ? (exam.title.length > 10 ? exam.title.substring(0, 10) + '...' : exam.title) : 'Exam',
      score: result.score,
      accuracy: Math.round(result.accuracy),
      date: format(result.submittedAt, 'MMM dd')
    };
  });

  const averageAccuracy = userResults.length > 0 
    ? Math.round(userResults.reduce((acc, curr) => acc + curr.accuracy, 0) / userResults.length)
    : 0;

  // Filtered results for the Results tab
  const filteredUserResults = React.useMemo(() => {
    return userResults.filter(r => {
      const exam = exams.find(e => e.id === r.examId);
      const searchTarget = ((exam?.title || '') + ' ' + (exam?.subject || '') + ' ' + (exam?.category || '')).toLowerCase();
      return searchTarget.includes(resultsSearchQuery.toLowerCase());
    }).reverse(); // Latest submissions on top
  }, [userResults, exams, resultsSearchQuery]);

  // Exams with rankings for Leaderboard selector
  const eligibleLeaderboardExams = React.useMemo(() => {
    return exams.filter(e => e.status === 'published' || e.status === 'completed');
  }, [exams]);

  const activeLeaderboardExamId = selectedLeaderboardExamId || eligibleLeaderboardExams[0]?.id || '';
  
  const chosenLeaderboardExam = React.useMemo(() => {
    return exams.find(e => e.id === activeLeaderboardExamId);
  }, [exams, activeLeaderboardExamId]);

  const leaderboardRows = React.useMemo(() => {
    if (!activeLeaderboardExamId) return [];
    const filtered = results.filter(r => r.examId === activeLeaderboardExamId);
    
    // Group by userId and pick the best result for each student
    const bestResultsMap = new Map<string, typeof results[0]>();
    
    filtered.forEach(res => {
      const existing = bestResultsMap.get(res.userId);
      // We prioritize higher score, then higher accuracy
      if (!existing || 
          res.score > existing.score || 
          (res.score === existing.score && res.accuracy > existing.accuracy)) {
        bestResultsMap.set(res.userId, res);
      }
    });

    return Array.from(bestResultsMap.values())
      .sort((a, b) => b.score - a.score || b.accuracy - a.accuracy);
  }, [results, activeLeaderboardExamId]);

  const filteredLeaderboardRows = React.useMemo(() => {
    return leaderboardRows.filter(r => {
      const student = users.find(u => u.id === r.userId);
      const text = `${student?.name || ''} ${student?.email || ''}`.toLowerCase();
      return text.includes(leaderboardSearchQuery.toLowerCase());
    });
  }, [leaderboardRows, users, leaderboardSearchQuery]);

  // Find current user's direct rank position
  const currentUserLeaderboardRank = React.useMemo(() => {
    if (!leaderboardRows.length || !currentUser) return null;
    const rankIndex = leaderboardRows.findIndex(r => r.userId === currentUser.id);
    return rankIndex !== -1 ? rankIndex + 1 : null;
  }, [leaderboardRows, currentUser]);

  // Dynamic categories list from admin categories
  const activeCategories = categories && categories.length > 0
    ? categories.map(cat => cat.name)
    : Array.from(new Set(courses.map(c => c.category).filter(Boolean))).sort((a, b) => b.localeCompare(a));
  const batchFilters = ['All Batches', ...activeCategories];

  // Sub-categories list based on selected category / batch
  const subCategoryFilters = React.useMemo(() => {
    if (selectedBatch === 'All Batches') {
      // Gather all subcategories from categories list
      const allSubs = (categories || []).flatMap(cat => cat.subCategories || []);
      const uniqueSubs = Array.from(new Set(allSubs));
      return ['All', ...uniqueSubs];
    } else {
      const matchCat = (categories || []).find(cat => cat.name === selectedBatch);
      if (matchCat) {
        return ['All', ...(matchCat.subCategories || [])];
      }
      return ['All'];
    }
  }, [categories, selectedBatch]);

  // Safeguard: Reset selected subcategory if it is no longer in the available options of the selected category batch
  React.useEffect(() => {
    if (!subCategoryFilters.includes(selectedSubject)) {
      setSelectedSubject('All');
    }
  }, [subCategoryFilters, selectedSubject]);

  // Filter lists based on interactive chips
  const filteredCourses = React.useMemo(() => {
    return courses.filter(c => {
      // Search filter
      if (searchQuery) {
        if (!c.title.toLowerCase().includes(searchQuery.toLowerCase()) && 
            !(c.description || '').toLowerCase().includes(searchQuery.toLowerCase())) {
          return false;
        }
      }
      // Batch filter
      const activeSelectedBatch = batchFilters.includes(selectedBatch) ? selectedBatch : 'All Batches';
      if (activeSelectedBatch !== 'All Batches') {
        if (c.category !== activeSelectedBatch) return false;
      }
      // Subject filter (Sub Category)
      if (selectedSubject !== 'All') {
        const matchesSubCategory = c.subCategory === selectedSubject;
        const matchesTextFallback = c.title.toLowerCase().includes(selectedSubject.toLowerCase()) || 
                                    (c.description || '').toLowerCase().includes(selectedSubject.toLowerCase());
        if (!matchesSubCategory && !matchesTextFallback) return false;
      }
      return true;
    });
  }, [courses, searchQuery, selectedBatch, selectedSubject, batchFilters]);

  const filteredEvents = React.useMemo(() => {
    return events.filter(ev => {
      if (searchQuery) {
        if (!ev.title.toLowerCase().includes(searchQuery.toLowerCase()) && 
            !(ev.description || '').toLowerCase().includes(searchQuery.toLowerCase())) {
          return false;
        }
      }
      if (selectedSubject !== 'All') {
        const matchSub = ev.title.toLowerCase().includes(selectedSubject.toLowerCase()) || 
                         (ev.description || '').toLowerCase().includes(selectedSubject.toLowerCase());
        if (!matchSub) return false;
      }
      return true;
    });
  }, [events, searchQuery, selectedSubject]);

  const activePublicExams = React.useMemo(() => {
    return exams.filter(e => {
      if (e.status !== 'published') return false;
      
      // Filter by Search Query
      if (searchQuery) {
        if (!e.title.toLowerCase().includes(searchQuery.toLowerCase()) && 
            !(e.description || '').toLowerCase().includes(searchQuery.toLowerCase())) {
          return false;
        }
      }

      // Filter by Target Admission Year/Batch (Category)
      const activeSelectedBatch = batchFilters.includes(selectedBatch) ? selectedBatch : 'All Batches';
      if (activeSelectedBatch !== 'All Batches') {
        if (e.category !== activeSelectedBatch) return false;
      }

      // Filter by Segments/Subject (Sub-Category)
      if (selectedSubject !== 'All') {
        const matchesSubCategory = e.subCategory === selectedSubject;
        const matchesSubject = e.subject?.toLowerCase() === selectedSubject.toLowerCase();
        const matchesTextFallback = e.title.toLowerCase().includes(selectedSubject.toLowerCase()) || 
                                    (e.description || '').toLowerCase().includes(selectedSubject.toLowerCase());
        if (!matchesSubCategory && !matchesSubject && !matchesTextFallback) return false;
      }

      return true;
    });
  }, [exams, searchQuery, selectedBatch, selectedSubject, batchFilters]);

  // Filter exams based on selected course and date in Exam Section
  const filteredExamsByCourseAndDate = React.useMemo(() => {
    return exams.filter(exam => {
      if (exam.status !== 'published') return false;
      
      // Course filter
      if (examSelectCourseId) {
        if (examSelectCourseId === 'public') {
          if (exam.accessType !== 'public') return false;
        } else {
          if (exam.accessType !== 'course' || !exam.courseIds?.includes(examSelectCourseId)) return false;
        }
      } else {
        // Default: display any matching enrolled courses or public
        const isPublic = exam.accessType === 'public';
        const isBelongingToMyEnrolledCourses = exam.accessType === 'course' && exam.courseIds?.some(cid => enrolledCourseIds.includes(cid));
        if (!isPublic && !isBelongingToMyEnrolledCourses) return false;
      }

      // Date filter
      if (examSelectDate) {
        const examDateStr = new Date(exam.startTime).toISOString().split('T')[0];
        if (examDateStr !== examSelectDate) return false;
      }

      return true;
    });
  }, [exams, examSelectCourseId, examSelectDate, enrolledCourseIds]);

  // Separate into Live vs Practice lists
  const liveExamsList = React.useMemo(() => {
    return filteredExamsByCourseAndDate.filter(exam => {
      const isPast = Date.now() > exam.endTime;
      return exam.examType === 'live' && !isPast;
    });
  }, [filteredExamsByCourseAndDate]);

  const practiceExamsList = React.useMemo(() => {
    return filteredExamsByCourseAndDate.filter(exam => {
      const isPast = Date.now() > exam.endTime;
      const isPractice = exam.examType === 'practice' || isPast;
      return isPractice;
    });
  }, [filteredExamsByCourseAndDate]);

  // Render standard Exam card
  const renderExamCard = (exam: Exam) => {
    const isActive = Date.now() >= exam.startTime && Date.now() <= exam.endTime;
    const isPast = Date.now() > exam.endTime;
    const isPracticeMode = exam.examType === 'practice' || isPast;
    
    // Check previous submissions
    const mySubmissions = results.filter(r => r.examId === exam.id && r.userId === currentUser?.id);
    const hasTaken = mySubmissions.length > 0;
    const latestResult = mySubmissions[mySubmissions.length - 1];
    
    return (
      <motion.div 
        key={exam.id} 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        whileHover={{ y: -4 }}
        className={`bg-white border p-5 rounded-[24px] flex flex-col md:flex-row gap-5 transition-all duration-300 shadow-[0_8px_30px_rgb(0,0,0,0.04)] border-b-[5px] ${hasTaken ? 'border-emerald-200 border-b-emerald-300/80 bg-emerald-50/20' : 'border-slate-200 border-b-slate-200 hover:border-indigo-400 hover:border-b-indigo-500 hover:shadow-indigo-500/20'}`}
      >
        {exam.thumbnailUrl ? (
          <img src={exam.thumbnailUrl} alt={exam.title} className="w-full md:w-32 h-24 bg-slate-100 rounded-2xl flex-shrink-0 object-cover border border-slate-100" />
        ) : (
          <div className="w-full md:w-32 h-24 bg-slate-100 rounded-2xl flex-shrink-0 flex items-center justify-center text-slate-400 border border-slate-200">
            <PlayCircle className="w-8 h-8 text-indigo-500" />
          </div>
        )}
        
        <div className="flex-1 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-2">
              <span className="text-[10px] font-extrabold text-indigo-600 uppercase tracking-widest">
                {exam.category} • {exam.subject}
              </span>
              {isPracticeMode ? (
                <span className="text-[9px] font-extrabold text-amber-600 bg-amber-50 px-2.5 py-1 rounded-full border border-amber-100 uppercase tracking-wider">Practice</span>
              ) : isActive ? (
                <span className="text-[9px] font-extrabold text-rose-600 bg-rose-50 px-2.5 py-1 rounded-full border border-rose-150 uppercase tracking-widest animate-pulse">LIVE EXAM</span>
              ) : (
                <span className="text-[9px] font-extrabold text-slate-500 bg-slate-100 px-2.5 py-1 rounded-full border border-slate-200 uppercase tracking-normal">
                  Starts At: {format(exam.startTime, 'MMM d, h:mm a')}
                </span>
              )}
            </div>
            <h4 className="font-extrabold text-slate-900 text-base leading-snug mt-1.5">{exam.title}</h4>
            <p className="text-slate-500 text-xs mt-1 font-medium line-clamp-1">{exam.description || 'Participate and get ranked on global leaderboard.'}</p>
          </div>
          
          <div className="flex flex-wrap items-center justify-between gap-4 mt-4 pt-3 border-t border-slate-100">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1.5 text-slate-500 text-xs font-bold">
                <Clock className="w-4 h-4 text-slate-400" />
                <span>{exam.durationMinutes} Mins</span>
              </div>
              {hasTaken && (
                <div className="flex items-center gap-1 text-[11px] font-bold text-emerald-600 bg-emerald-50 border border-emerald-150 px-2 py-0.5 rounded-lg">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Score: {latestResult.score} pts ({Math.round(latestResult.accuracy)}%)</span>
                </div>
              )}
            </div>
            
            <div className="flex items-center gap-2">
              {exam.isPaid && !hasTaken && (
                <div className="px-2.5 py-1.5 bg-amber-50 text-amber-700 text-[11px] font-black rounded-lg border border-amber-200 flex items-center gap-1">
                  <Lock className="w-3.5 h-3.5" />
                  <span>৳{(exam.feeAmount || 0) - (exam.discountAmount || 0)}</span>
                </div>
              )}
              
              {isPracticeMode || isActive ? (
                <div className="flex items-center gap-2">
                  {hasTaken && (
                    <button 
                      onClick={() => navigate(`/student/result/${exam.id}`)}
                      className="px-4 py-2 bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 text-xs font-extrabold rounded-xl transition-all"
                    >
                      Solutions & Rank
                    </button>
                  )}
                  
                  {isPracticeMode ? (
                    <button 
                      onClick={() => handleStartAttempt(exam)}
                      className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition-all shadow-md shadow-indigo-100"
                    >
                      {hasTaken ? 'Re-take Practice' : 'Start Practice'}
                    </button>
                  ) : (
                    // Live flow
                    hasTaken ? (
                      <span className="text-xs font-bold text-slate-400">Attempted</span>
                    ) : (
                      <button 
                        onClick={() => handleStartAttempt(exam)}
                        className="px-5 py-2 bg-rose-500 hover:bg-rose-600 text-white text-xs font-extrabold rounded-xl transition-all shadow-md shadow-rose-100"
                      >
                        {exam.isPaid ? 'Unlock & Start Live' : 'Join Live Exam'}
                      </button>
                    )
                  )}
                </div>
              ) : (
                <button disabled className="px-4 py-2 bg-slate-50 text-slate-400 text-xs font-bold rounded-xl cursor-not-allowed border border-slate-200 uppercase tracking-widest">
                  Upcoming
                </button>
              )}
            </div>
          </div>
        </div>
      </motion.div>
    );
  };

  // Render course list card
  const renderCourseCard = (course: Course) => {
    const isEnrolled = isCourseEnrolled(course.id);
    const cost = (course.feeAmount || 0) - (course.discountAmount || 0);
    const hasDiscount = course.discountAmount && course.discountAmount > 0;
    const enrolledCount = users.filter(u => u.enrolledCourses?.includes(course.id)).length;
    
    return (
      <motion.div 
        key={course.id} 
        initial={{ opacity: 0, scale: 0.95 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        whileHover={{ y: -8 }}
        className="bg-white border border-slate-200/80 border-b-[6px] border-b-slate-100/50 hover:border-indigo-400 hover:border-b-indigo-500 rounded-[32px] overflow-hidden transition-all duration-500 shadow-[0_4px_20px_rgba(0,0,0,0.03)] hover:shadow-[0_32px_50px_-12px_rgba(99,102,241,0.25)] flex flex-col group relative bg-gradient-to-b from-white to-slate-50/30"
      >
        {/* Course Banner Image Container */}
        <div className="relative aspect-[16/9] w-full overflow-hidden bg-slate-100">
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 via-transparent to-transparent z-10 pointer-events-none" />
          {course.bannerUrl ? (
            <img 
              src={course.bannerUrl} 
              alt={course.title} 
              className="w-full h-full object-cover transition-transform duration-1000 ease-out group-hover:scale-110" 
              referrerPolicy="no-referrer"
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-indigo-600/10 to-slate-600/10 flex items-center justify-center text-indigo-200">
              <BookOpen className="w-16 h-16 stroke-[1] opacity-50" />
            </div>
          )}
          
          {/* Overlay Floating Badges */}
          <div className="absolute top-4 left-4 right-4 flex justify-between items-center z-20">
            <span className="px-3 py-1.5 bg-white/90 backdrop-blur-md shadow-sm rounded-xl text-[9px] font-black text-indigo-600 uppercase tracking-widest border border-white/20">
              {course.category || 'Batch Session'}
            </span>
            
            {course.isPaid ? (
              <span className="px-3 py-1.5 bg-amber-500/90 backdrop-blur-md text-white shadow-sm rounded-xl text-[9px] font-black uppercase tracking-widest flex items-center gap-1.5 border border-white/10">
                <Lock className="w-3 h-3" /> Paid
              </span>
            ) : (
              <span className="px-3 py-1.5 bg-emerald-500/90 backdrop-blur-md text-white shadow-sm rounded-xl text-[9px] font-black uppercase tracking-widest border border-white/10">
                Free
              </span>
            )}
          </div>
        </div>

        {/* Detailed Card Body Section */}
        <div className="p-6 flex-1 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="space-y-1">
              <h4 className="font-black text-slate-900 group-hover:text-indigo-600 transition-colors text-lg tracking-tight leading-tight font-display line-clamp-1">
                {course.title}
              </h4>
              <p className="text-slate-500 text-[13px] font-bold leading-relaxed line-clamp-2">
                {course.description || 'Access supreme quality target admission papers & instant verification.'}
              </p>
            </div>

            {/* Feature Pills */}
            <div className="flex flex-wrap gap-2">
              <div className="bg-indigo-50/50 border border-indigo-100/50 px-3 py-1.5 rounded-xl flex items-center gap-2">
                <Users className="w-3.5 h-3.5 text-indigo-500" />
                <span className="text-[10px] font-black text-indigo-700 uppercase tracking-wider">{enrolledCount} Joined</span>
              </div>
              <div className="bg-slate-50 border border-slate-100 px-3 py-1.5 rounded-xl flex items-center gap-2">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span className="text-[10px] font-black text-slate-600 uppercase tracking-wider">Top Rated</span>
              </div>
            </div>
          </div>

          <div className="mt-8 pt-5 border-t border-slate-100/80 flex items-center justify-between">
            <div className="flex flex-col">
              <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1">Fee Starts From</span>
              <div className="flex items-baseline gap-1.5">
                <span className="text-xl font-black font-display text-slate-900">৳{cost}</span>
                {hasDiscount && (
                  <span className="text-xs text-slate-400 font-bold line-through">৳{course.feeAmount}</span>
                )}
              </div>
            </div>

            <div className="flex items-center gap-2">
              {isEnrolled ? (
                <button 
                  onClick={() => setSelectedCourse(course)}
                  className="px-5 py-3 bg-slate-900 hover:bg-slate-800 text-white text-[10px] font-black uppercase tracking-widest rounded-2xl transition-all shadow-lg shadow-slate-900/10 flex items-center gap-2 font-display active:scale-95"
                >
                  Enter
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              ) : (
                <button 
                  onClick={() => handleCourseEnrollClick(course)}
                  className="px-5 py-3 bg-indigo-600 hover:bg-indigo-700 text-white text-[10px] font-black uppercase tracking-widest rounded-2xl transition-all shadow-lg shadow-indigo-600/20 font-display active:scale-95"
                >
                  Join Now
                </button>
              )}
            </div>
          </div>
        </div>
      </motion.div>
    );
  };

  // Render event list card
  const renderEventCard = (ev: AppEvent) => {
    const isJoined = isEventJoined(ev.id);
    const cost = (ev.feeAmount || 0) - (ev.discountAmount || 0);
    
    return (
      <motion.div 
        key={ev.id} 
        initial={{ opacity: 0, scale: 0.95 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        whileHover={{ y: -8 }}
        className="bg-white border border-slate-200/80 border-b-[6px] border-b-slate-100/50 hover:border-rose-400 hover:border-b-rose-500 rounded-[32px] overflow-hidden transition-all duration-500 shadow-[0_4px_20px_rgba(0,0,0,0.03)] hover:shadow-[0_32px_50px_-12px_rgba(244,63,94,0.25)] flex flex-col group relative bg-gradient-to-b from-white to-slate-50/30"
      >
        {/* Event Banner Image Container */}
        <div className="relative aspect-[16/9] w-full overflow-hidden bg-slate-100">
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 via-transparent to-transparent z-10 pointer-events-none" />
          {ev.bannerUrl ? (
            <img 
              src={ev.bannerUrl} 
              alt={ev.title} 
              className="w-full h-full object-cover transition-transform duration-1000 ease-out group-hover:scale-110" 
              referrerPolicy="no-referrer"
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-rose-600/10 to-slate-600/10 flex items-center justify-center text-rose-200">
              <Calendar className="w-16 h-16 stroke-[1] opacity-50" />
            </div>
          )}
          
          <div className="absolute top-4 left-4 z-20">
            <span className="px-3.5 py-1.5 bg-rose-600/90 backdrop-blur-md text-white shadow-sm rounded-xl text-[9px] font-black uppercase tracking-widest flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" /> Live Event
            </span>
          </div>

          <div className="absolute bottom-4 left-4 right-4 z-20 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="bg-white px-2.5 py-1.5 rounded-xl border border-white/20 shadow-sm flex flex-col items-center min-w-[40px]">
                <span className="text-[10px] font-black text-rose-600 leading-none">{format(ev.date, 'MMM')}</span>
                <span className="text-sm font-black text-slate-900 leading-none mt-1">{format(ev.date, 'd')}</span>
              </div>
              <div className="flex flex-col">
                <span className="text-white text-[11px] font-black uppercase tracking-wider">{format(ev.date, 'EEEE')}</span>
                <span className="text-white/80 text-[10px] font-bold uppercase tracking-widest">{format(ev.date, 'h:mm a')}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Card Body Section */}
        <div className="p-6 flex-1 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="space-y-1">
              <h4 className="font-black text-slate-900 group-hover:text-rose-600 transition-colors text-lg tracking-tight leading-tight font-display line-clamp-1">
                {ev.title}
              </h4>
              <p className="text-slate-500 text-[13px] font-bold leading-relaxed line-clamp-2">
                {ev.description || 'Join live mock events with high yield questions sorted by top mentor teams.'}
              </p>
            </div>

            <div className="flex flex-wrap gap-2">
              <div className="bg-slate-50 border border-slate-100 px-3 py-1.5 rounded-xl flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-rose-500" />
                <span className="text-[10px] font-black text-slate-600 uppercase tracking-wider">{ev.location || 'Online Port'}</span>
              </div>
            </div>
          </div>

          <div className="mt-8 pt-5 border-t border-slate-100/80 flex items-center justify-between">
            <div className="flex flex-col">
              <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1">Registration</span>
              <span className="text-xl font-black font-display text-slate-900">
                {ev.isPaid ? `৳${cost}` : 'FREE'}
              </span>
            </div>

            <div className="flex items-center gap-2">
              {isJoined ? (
                <button 
                  onClick={() => setSelectedEvent(ev)}
                  className="px-5 py-3 bg-slate-900 hover:bg-slate-800 text-white text-[10px] font-black uppercase tracking-widest rounded-2xl transition-all shadow-lg shadow-slate-900/10 flex items-center gap-2 font-display active:scale-95"
                >
                  Enter
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              ) : (
                <button 
                  onClick={() => handleEventJoinClick(ev)}
                  className="px-5 py-3 bg-rose-600 hover:bg-rose-700 text-white text-[10px] font-black uppercase tracking-widest rounded-2xl transition-all shadow-lg shadow-rose-600/20 font-display active:scale-95"
                >
                  Register
                </button>
              )}
            </div>
          </div>
        </div>
      </motion.div>
    );
  };

  return (
    <div className="min-h-screen bg-slate-50 pb-20 flex flex-col relative overflow-hidden">
      {/* Sidebar Drawer */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/60 z-40 backdrop-blur-sm transition-opacity duration-300"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}
      <aside className={`fixed inset-y-0 left-0 z-50 w-72 bg-white shadow-2xl border-r border-slate-200 transform transition-transform duration-300 ease-in-out ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="p-6 h-full flex flex-col">
          <div className="flex items-center justify-between mb-8 cursor-pointer" onClick={() => setIsMobileMenuOpen(false)}>
            <div className="flex items-center gap-3">
              <img 
                src="https://i.postimg.cc/h40vHdRJ/IMG-20260217-WA0010.jpg" 
                alt="OTS Logo" 
                className="w-10 h-10 object-cover rounded-xl border border-slate-100 shadow-sm"
              />
              <div className="flex flex-col">
                <span className="font-extrabold text-slate-900 text-lg leading-tight tracking-tight mt-0.5">OTS</span>
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-0.5">Since 2023</span>
              </div>
            </div>
            <button className="text-slate-400 hover:text-slate-600 transition-colors p-2 rounded-xl bg-slate-50 hover:bg-slate-100"><X className="w-5 h-5"/></button>
          </div>
          
          <nav className="flex-1 space-y-1 overflow-y-auto">
            {[
              { id: 'home', label: 'Home', icon: Target },
              { id: 'exams', label: 'Exam Section', icon: PlayCircle },
              { id: 'results', label: 'Exam Results', icon: Medal },
              { id: 'leaderboard', label: 'Leaderboard', icon: Trophy },
              { id: 'routine', label: 'Course Routine', icon: Calendar },
              { id: 'history', label: 'Exam History', icon: Layers },
              { id: 'report', label: 'Report Issue', icon: AlertTriangle },
              { id: 'faq', label: 'FAQ', icon: FileText },
            ].map(item => (
              <button
                key={item.id}
                onClick={() => {
                  setCurrentTab(item.id as any);
                  setIsMobileMenuOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-4 py-3.5 rounded-2xl text-left transition-colors font-bold ${currentTab === item.id || (currentTab === 'results' && item.id === 'history') ? 'bg-indigo-50 text-indigo-700' : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'}`}
              >
                <item.icon className="w-5 h-5" />
                <span className="text-[13px]">{item.label}</span>
              </button>
            ))}
          </nav>
          
          <div className="mt-auto pt-6 border-t border-slate-100">
            <button 
              onClick={handleLogout}
              className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-rose-50 text-rose-600 font-bold rounded-2xl hover:bg-rose-100 hover:text-rose-700 transition-colors"
            >
              <LogOut className="w-5 h-5" />
              <span>Log out</span>
            </button>
          </div>
        </div>
      </aside>

      {/* Header */}
      <header className="py-6 sm:py-8 bg-slate-900 px-4 sm:px-8 flex items-center justify-between sticky top-0 z-20 shadow-md">
        <div className="flex items-center gap-3 sm:gap-4">
          <button 
            onClick={() => setIsMobileMenuOpen(true)}
            className="p-2 sm:p-2.5 bg-slate-800 text-slate-200 hover:bg-slate-700 rounded-xl transition-colors cursor-pointer shrink-0"
          >
            <Menu className="w-5 h-5 sm:w-6 sm:h-6" />
          </button>
          <img 
            src="https://i.postimg.cc/h40vHdRJ/IMG-20260217-WA0010.jpg" 
            alt="OTS Logo" 
            referrerPolicy="no-referrer"
            className="w-10 h-10 sm:w-14 sm:h-14 object-cover rounded-xl border border-indigo-950/40 shadow-md flex-shrink-0"
          />
          <div className="flex flex-col text-left justify-center pb-0.5">
            <span className="font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-slate-200 via-white to-slate-200 bg-[length:200%_auto] animate-spotlight animate-pulse-glow text-base sm:text-xl leading-none tracking-tight font-display font-black line-clamp-1 drop-shadow-md">
              OTS EXAM SYSTEM
            </span>
            <span className="text-[9px] sm:text-[10px] text-indigo-400 font-black tracking-widest uppercase mt-1">Student Portal</span>
          </div>
        </div>

        <div className="flex items-center gap-3 sm:gap-4 shrink-0">
          <div className="text-right hidden sm:block">
            <p className="text-sm font-bold text-slate-100">Hi, {currentUser?.name}</p>
            <p className="text-[10px] text-indigo-400 uppercase font-black tracking-widest">Active student</p>
          </div>

          <NotificationCenter />
          
          {/* My Courses Dropdown Button */}
          <div className="relative">
            <button
              onClick={() => setIsMyCoursesOpen(!isMyCoursesOpen)}
              className={`flex items-center gap-2 h-10 px-3.5 rounded-xl text-xs font-black uppercase tracking-wider transition-all cursor-pointer ${
                isMyCoursesOpen 
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30 font-display' 
                  : 'bg-slate-800 text-slate-200 hover:bg-slate-750 hover:text-white font-display'
              }`}
              title="My Enrolled Courses"
            >
              <BookOpen className="w-4 h-4 stroke-[2.5]" />
              <span className="hidden md:inline">My Courses</span>
              <span className="bg-indigo-550 text-indigo-300 font-extrabold px-1.5 py-0.5 rounded-md text-[10px] min-w-[18px] text-center border border-indigo-500/25">
                {enrolledCourseIds.length}
              </span>
            </button>

            {/* Dropdown Menu */}
            {isMyCoursesOpen && (
              <>
                {/* Backdrop overlay for closing dropdown */}
                <div className="fixed inset-0 z-40 bg-transparent" onClick={() => setIsMyCoursesOpen(false)} />
                
                <div className="absolute right-0 mt-3 w-80 bg-white border border-slate-200 rounded-2xl shadow-2xl z-50 overflow-hidden divide-y divide-slate-100 animation-fadeIn">
                  <div className="p-4 bg-slate-50 text-left">
                    <p className="text-[10px] uppercase font-black tracking-widest text-slate-400">My Enrolled Courses</p>
                    <h4 className="text-sm font-black text-slate-850 mt-1 uppercase">আমার কোর্সসমূহ ({enrolledCourseIds.length})</h4>
                  </div>
                  
                  <div className="max-h-64 overflow-y-auto py-1 text-left">
                    {enrolledCourseIds.length === 0 ? (
                      <div className="p-6 text-center text-slate-400">
                        <BookOpen className="w-8 h-8 mx-auto mb-2 text-slate-350 stroke-[1.5]" />
                        <p className="text-xs font-medium">You haven't enrolled in any course yet.</p>
                      </div>
                    ) : (
                      courses
                        .filter(c => enrolledCourseIds.includes(c.id))
                        .map(course => (
                          <button
                            key={course.id}
                            onClick={() => {
                              setSelectedCourse(course);
                              setSelectedEvent(null);
                              setActiveSegment('courses');
                              setIsMyCoursesOpen(false);
                            }}
                            className="w-full text-left p-3 hover:bg-indigo-50/50 flex items-start gap-3 transition-colors group cursor-pointer"
                          >
                            <div className="w-9 h-9 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold flex-shrink-0 border border-indigo-100 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                              <GraduationCap className="w-5 h-5" />
                            </div>
                            <div className="min-w-0 flex-1">
                              <p className="text-xs font-black text-slate-800 line-clamp-1 group-hover:text-indigo-950 transition-colors uppercase tracking-tight">
                                {course.title}
                              </p>
                              <p className="text-[10px] text-slate-400 font-bold uppercase mt-0.5 tracking-wider line-clamp-1">
                                {course.category || 'Batch Session'}
                              </p>
                            </div>
                          </button>
                        ))
                    )}
                  </div>

                  <div className="p-3 bg-slate-50 text-center">
                    <button
                      onClick={() => {
                        setSelectedCourse(null);
                        setSelectedEvent(null);
                        setActiveSegment('courses');
                        setIsMyCoursesOpen(false);
                      }}
                      className="text-[10px] font-black tracking-wider uppercase text-indigo-600 hover:text-indigo-800 transition-colors cursor-pointer"
                    >
                      Browse All Courses • সকল কোর্স দেখুন
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
          
          <button 
            onClick={() => navigate('/student/profile')}
            className="w-10 h-10 flex items-center justify-center text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-750 rounded-xl transition-colors shrink-0"
            title="Syllabus Personal Profile"
          >
            <div className="w-6 h-6 rounded-full bg-slate-600 overflow-hidden">
               {currentUser?.profile?.photoUrl ? (
                 <img src={currentUser.profile.photoUrl} alt="User profile" className="w-full h-full object-cover" />
               ) : (
                 <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-full h-full p-1"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
               )}
            </div>
          </button>
        </div>
      </header>

      <main className="flex-1 max-w-5xl mx-auto p-4 sm:p-8 w-full space-y-8">
        
        {/* ================= COURSE DETAILS SCREEN (SUB-VIEW) ================= */}
        {selectedCourse ? (
          <div className="space-y-6 animation-fadeIn">
            {/* Back action */}
            <button 
              onClick={() => setSelectedCourse(null)}
              className="flex items-center gap-2 text-indigo-600 hover:text-indigo-800 font-extrabold text-xs uppercase tracking-wider mb-2"
            >
              <ArrowLeft className="w-4 h-4" /> Back to Home Bar (All Courses)
            </button>

            {/* Banner block */}
            <div className="bg-gradient-to-br from-indigo-900 to-slate-900 text-white rounded-3xl overflow-hidden shadow-xl relative min-h-[220px]">
              {selectedCourse.bannerUrl && (
                <div className="absolute inset-0 opacity-20 pointer-events-none">
                  <img src={selectedCourse.bannerUrl} alt="banner blur" className="w-full h-full object-cover blur-md scale-105" />
                </div>
              )}
              <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-slate-950/80 to-transparent pointer-events-none z-0"></div>
              
              <div className="p-8 relative z-10 flex flex-col justify-between h-full min-h-[220px]">
                <div className="space-y-3">
                  <span className="px-3 py-1 bg-indigo-500/30 border border-indigo-400/30 rounded-full text-[10px] font-black uppercase tracking-widest text-indigo-200">
                    {selectedCourse.category} Batch Course Hub
                  </span>
                  <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white leading-tight">
                    {selectedCourse.title}
                  </h2>
                  <p className="text-slate-200/90 text-sm max-w-2xl font-medium leading-relaxed">
                    {selectedCourse.description || 'Welcome back to your course studies. Participate in mock examinations, check live status sheets, and download revision cards.'}
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mt-6 pt-6 border-t border-white/10 z-10">
                  <div className="flex items-center gap-3">
                    {isCourseEnrolled(selectedCourse.id) ? (
                      <span className="px-3.5 py-1.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/20 text-xs font-black uppercase tracking-wider rounded-xl flex items-center gap-1.5">
                        <Check className="w-4 h-4" /> Registered & Enrolled
                      </span>
                    ) : (
                      <span className="px-3.5 py-1.5 bg-amber-500/20 text-amber-300 border border-amber-500/20 text-xs font-black uppercase tracking-wider rounded-xl">
                        Not Enrolled
                      </span>
                    )}
                  </div>

                  {/* Enroll inside sub-view details */}
                  {!isCourseEnrolled(selectedCourse.id) && (
                    <button 
                      onClick={() => handleCourseEnrollClick(selectedCourse)}
                      className="bg-amber-500 hover:bg-amber-600 text-white px-6 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all shadow-md shadow-amber-500/20"
                    >
                      {selectedCourse.isPaid ? 'Buy Course Admission' : 'Enroll Now (Free)'}
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Course Content / Associated Mock Exams list */}
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
              <div>
                <h3 className="text-lg font-black text-slate-900 flex items-center gap-2">
                  <Layers className="w-5 h-5 text-indigo-500" />
                  Course Examination Board
                </h3>
                <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-0.5">Participate in custom exams configured for this specific batch.</p>
              </div>

              {!isCourseEnrolled(selectedCourse.id) ? (
                <div className="bg-slate-50 border border-slate-200 p-8 rounded-2xl text-center space-y-4">
                  <HelpCircle className="w-12 h-12 text-slate-400 mx-auto" />
                  <div className="space-y-1">
                    <h4 className="text-slate-800 font-black text-base">Locked Course Material</h4>
                    <p className="text-slate-500 text-xs max-w-sm mx-auto">Please enroll or request admission in this course to unlock all associated live mock trials and solution logs.</p>
                  </div>
                  <button 
                    onClick={() => handleCourseEnrollClick(selectedCourse)}
                    className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-xl text-xs font-bold"
                  >
                    Unlock Batch Admission
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Filter exams matching this courseId */}
                  {exams.filter(e => e.accessType === 'course' && e.courseIds?.includes(selectedCourse.id)).length === 0 ? (
                    <div className="p-8 text-center text-slate-500 font-semibold text-sm border border-dashed border-slate-200 rounded-2xl bg-slate-50">
                      No examinations have been linked to this course pack yet. Stay tuned, our instructors will publish them shortly!
                    </div>
                  ) : (
                    <div className="grid gap-4">
                      {exams
                        .filter(e => e.accessType === 'course' && e.courseIds?.includes(selectedCourse.id) && e.status === 'published')
                        .map(renderExamCard)
                      }
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>


        // ================= EVENT DETAILS SCREEN (SUB-VIEW) ================= 
        ) : selectedEvent ? (
          <div className="space-y-6 animation-fadeIn">
            {/* Back action */}
            <button 
              onClick={() => setSelectedEvent(null)}
              className="flex items-center gap-2 text-indigo-600 hover:text-indigo-800 font-extrabold text-xs uppercase tracking-wider mb-2"
            >
              <ArrowLeft className="w-4 h-4" /> Back to Home Bar (All Events)
            </button>

            {/* Banner block */}
            <div className="bg-gradient-to-br from-rose-950 to-slate-900 text-white rounded-3xl overflow-hidden shadow-xl relative min-h-[220px]">
              {selectedEvent.bannerUrl && (
                <div className="absolute inset-0 opacity-20 pointer-events-none">
                  <img src={selectedEvent.bannerUrl} alt="banner blur" className="w-full h-full object-cover blur-sm scale-105" />
                </div>
              )}
              <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-slate-950/80 to-transparent pointer-events-none z-0"></div>
              
              <div className="p-8 relative z-10 flex flex-col justify-between h-full min-h-[220px]">
                <div className="space-y-3">
                  <span className="px-3 py-1 bg-rose-500/30 border border-rose-400/30 rounded-full text-[10px] font-black uppercase tracking-widest text-rose-200 inline-block">
                    {format(selectedEvent.date, 'eeee, MMMM d, yyyy')}
                  </span>
                  <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white leading-tight">
                    {selectedEvent.title}
                  </h2>
                  <p className="text-slate-200/90 text-sm max-w-2xl font-medium leading-relaxed">
                    {selectedEvent.description || 'Welcome back to your event. Participate in mock examinations, check live status sheets, and download revision cards.'}
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mt-6 pt-6 border-t border-white/10 z-10">
                  <div className="flex items-center gap-3">
                    <span className="text-slate-300 font-bold text-xs">
                      📍 Location: {selectedEvent.location || 'Online Classroom'}
                    </span>
                    {isEventJoined(selectedEvent.id) ? (
                      <span className="px-3.5 py-1.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/20 text-xs font-black uppercase tracking-wider rounded-xl flex items-center gap-1.5">
                        <Check className="w-4 h-4" /> Registered Participant
                      </span>
                    ) : (
                      <span className="px-3.5 py-1.5 bg-amber-500/20 text-amber-300 border border-amber-500/20 text-xs font-black uppercase tracking-wider rounded-xl">
                        Not Registered
                      </span>
                    )}
                  </div>

                  {/* Enroll inside sub-view details */}
                  {!isEventJoined(selectedEvent.id) && (
                    <button 
                      onClick={() => handleEventJoinClick(selectedEvent)}
                      className="bg-amber-500 hover:bg-amber-600 text-white px-6 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all shadow-md shadow-amber-500/20"
                    >
                      {selectedEvent.isPaid ? 'Buy Event Ticket' : 'Register Now (Free)'}
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Event Content / Associated Mock Exams list */}
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
              <div>
                <h3 className="text-lg font-black text-slate-900 flex items-center gap-2">
                  <Award className="w-5 h-5 text-rose-500" />
                  Event Examination Room
                </h3>
                <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-0.5">Compete and get scored live in this exclusive bootcamp contest.</p>
              </div>

              {!isEventJoined(selectedEvent.id) ? (
                <div className="bg-slate-50 border border-slate-200 p-8 rounded-2xl text-center space-y-4">
                  <HelpCircle className="w-12 h-12 text-slate-400 mx-auto" />
                  <div className="space-y-1">
                    <h4 className="text-slate-800 font-black text-base">Locked Event Material</h4>
                    <p className="text-slate-500 text-xs max-w-sm mx-auto">Please join or register for this event to view and participate in its target exam sheets.</p>
                  </div>
                  <button 
                    onClick={() => handleEventJoinClick(selectedEvent)}
                    className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-xl text-xs font-bold"
                  >
                    Register for Event
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Filter exams matching this event ID */}
                  {exams.filter(e => e.accessType === 'event' && e.eventIds?.includes(selectedEvent.id)).length === 0 ? (
                    <div className="p-8 text-center text-slate-500 font-semibold text-sm border border-dashed border-slate-200 rounded-2xl bg-slate-50">
                      No live exams have been added to this event stream yet. Check back during live calendar hours!
                    </div>
                  ) : (
                    <div className="grid gap-4">
                      {exams
                        .filter(e => e.accessType === 'event' && e.eventIds?.includes(selectedEvent.id) && e.status === 'published')
                        .map(renderExamCard)
                      }
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>


        // ================= MAIN STUDENT PORTAL BOARD (DEFAULT TAB VIEW) ================= 
        ) : (
          <>
            {currentTab === 'home' && (
              <>
                {/* Promotional Slider Carousel with Parallax & Sparkle effects */}
            <div className="w-full min-h-[240px] sm:h-56 md:h-60 bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950 rounded-[32px] relative overflow-hidden shadow-2xl shadow-slate-950/20 border border-slate-800 flex flex-col justify-center group/carousel">
              {/* Slides renderer */}
              {sliderSlides.map((slide, sIdx) => {
                const isActive = sIdx === currentSlideIndex;
                return (
                  <div 
                    key={slide.id}
                    className={`absolute inset-0 w-full h-full transition-all duration-[850ms] cubic-bezier(0.16, 1, 0.3, 1) flex flex-col justify-between p-7 sm:p-9 ${
                      isActive 
                        ? 'opacity-100 translate-x-0 scale-100 pointer-events-auto z-10' 
                        : 'opacity-0 translate-x-12 scale-[0.97] pointer-events-none z-0'
                    }`}
                  >
                    {/* Background Banner with elegant slow-zoom transition */}
                    <div className="absolute inset-0 pointer-events-none overflow-hidden">
                      <img 
                        src={slide.bannerUrl} 
                        alt="" 
                        referrerPolicy="no-referrer"
                        className={`w-full h-full object-cover transition-all duration-[6000ms] ease-out ${
                          isActive ? 'scale-108 opacity-40' : 'scale-100 opacity-0'
                        }`} 
                      />
                      <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-950/90 to-transparent sm:via-slate-950/75" />
                    </div>
 
                    {/* Left content zone with elegant stagger effect */}
                    <div className="relative z-10 space-y-3 max-w-2xl text-left">
                      <div className="flex flex-wrap gap-2 items-center">
                        <span className="px-3 py-1 bg-indigo-600/90 backdrop-blur-md border border-indigo-400/20 rounded-full text-[9px] font-black uppercase tracking-widest text-indigo-50 shadow-md">
                          {slide.badge}
                        </span>
                        {slide.tagLine && (
                          <span className="px-3 py-1 bg-amber-500/10 border border-amber-500/20 rounded-full text-[9px] font-black uppercase tracking-widest text-amber-300">
                            {slide.tagLine}
                          </span>
                        )}
                      </div>
                      
                      <h2 className="text-xl sm:text-2xl md:text-3xl font-black text-white tracking-tight leading-tight line-clamp-1 font-display drop-shadow-sm">
                        {slide.title}
                      </h2>
                      
                      <p className="text-xs sm:text-sm text-slate-300 font-medium max-w-xl leading-relaxed line-clamp-2 drop-shadow-[0_1px_2px_rgba(0,0,0,0.5)]">
                        {slide.description}
                      </p>
                    </div>
 
                    {/* Action Zone */}
                    <div className="relative z-10 flex items-center justify-between mt-4">
                      <button
                        onClick={slide.action}
                        className="flex items-center gap-2 bg-white hover:bg-slate-100 text-slate-950 active:scale-95 px-5 py-3 rounded-2xl text-xs font-black uppercase tracking-wider transition-all shadow-xl hover:shadow-white/10 font-display cursor-pointer"
                      >
                        {slide.actionText}
                        <ArrowRight className="w-4 h-4 stroke-[2.5]" />
                      </button>
                    </div>
                  </div>
                );
              })}
 
              {/* Navigation Indicators (Dots) with glowing active track */}
              {sliderSlides.length > 1 && (
                <div className="absolute bottom-6 left-1/2 -translate-x-1/2 sm:translate-x-0 sm:left-auto sm:right-9 z-20 flex items-center gap-2.5">
                  {sliderSlides.map((_, dotIdx) => (
                    <button
                      key={dotIdx}
                      onClick={() => setCurrentSlideIndex(dotIdx)}
                      className={`h-2 rounded-full transition-all duration-300 cursor-pointer ${
                        dotIdx === currentSlideIndex 
                          ? 'w-7 bg-indigo-500 shadow-[0_0_10px_2px_rgba(99,102,241,0.5)]' 
                          : 'w-2.5 bg-slate-705/80 hover:bg-slate-600 bg-slate-700'
                      }`}
                      title={`Go to slide ${dotIdx + 1}`}
                    />
                  ))}
                </div>
              )}
 
              {/* Prev/Next Touch-friendly glassmorphic controllers visible on group-hover */}
              {sliderSlides.length > 1 && (
                <div className="hidden sm:flex opacity-0 group-hover/carousel:opacity-100 absolute left-6 right-6 top-1/2 -translate-y-1/2 z-20 justify-between pointer-events-none transition-all duration-300">
                  <button
                    onClick={() => setCurrentSlideIndex(prev => (prev - 1 + sliderSlides.length) % sliderSlides.length)}
                    className="p-3 bg-white/10 hover:bg-white/20 text-white backdrop-blur-md border border-white/10 rounded-2xl transition-all cursor-pointer pointer-events-auto shadow-xl hover:scale-105 active:scale-95"
                    title="Previous Slide"
                  >
                    <ChevronLeft className="w-5 h-5 stroke-[2.5]" />
                  </button>
                  <button
                    onClick={() => setCurrentSlideIndex(prev => (prev + 1) % sliderSlides.length)}
                    className="p-3 bg-white/10 hover:bg-white/20 text-white backdrop-blur-md border border-white/10 rounded-2xl transition-all cursor-pointer pointer-events-auto shadow-xl hover:scale-105 active:scale-95"
                    title="Next Slide"
                  >
                    <ChevronRight className="w-5 h-5 stroke-[2.5]" />
                  </button>
                </div>
              )}
            </div>

            {/* ================= PORTAL COMPREHENSIVE DIRECTORY FEED ================= */}
            <div className="space-y-6">
              
              {/* Header Titles */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h3 className="text-2xl font-black tracking-tight text-slate-900 font-display">Explore Courses & Events</h3>
                  <p className="text-xs text-slate-500 font-bold uppercase tracking-wider mt-0.5">Select your course batch, enter it, and access all exams.</p>
                </div>

                {/* Live Search bar */}
                <div className="relative w-full sm:w-60">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input 
                    type="text" 
                    placeholder="Search courses..." 
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    className="w-full pl-9 pr-4 py-2 bg-white border border-slate-200 hover:border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none text-slate-800 font-semibold text-xs transition-colors"
                  />
                </div>
              </div>

              {/* FILTER CONTROLS (BATCH YEARS & STREAMS) */}
              <div className="space-y-4 bg-white p-5 rounded-3xl border border-slate-200/80 shadow-sm relative overflow-hidden">
                
                {/* Years / Batch select Row with Touch Scrolling */}
                <div className="flex items-center gap-3">
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest mr-2 flex-shrink-0">Target Admission Year:</span>
                  <div className="flex flex-1 items-center gap-2 overflow-x-auto pb-1 scroll-smooth [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none] snap-x">
                    {batchFilters.map(year => (
                      <button 
                        key={year}
                        onClick={() => {
                          setSelectedBatch(year);
                          setSelectedSubject('All');
                        }}
                        className={`px-4 py-2 rounded-full text-xs font-black tracking-tight whitespace-nowrap transition-all duration-300 flex-shrink-0 snap-start cursor-pointer hover:scale-102 active:scale-98 ${
                          (batchFilters.includes(selectedBatch) ? selectedBatch : 'All Batches') === year 
                            ? 'bg-gradient-to-r from-indigo-600 to-indigo-700 text-white shadow-md shadow-indigo-600/15 ring-2 ring-indigo-600/10' 
                            : 'bg-slate-50 hover:bg-slate-100 text-slate-600 border border-slate-100'
                        }`}
                      >
                        {year}
                      </button>
                    ))}
                  </div>
                </div>

                {selectedBatch !== 'All Batches' && subCategoryFilters.length > 1 && (
                  <div className="animate-in slide-in-from-top-1.5 fade-in duration-300">
                    <div className="h-px bg-slate-100 w-full mb-4"></div>

                    {/* Dynamic Category Segments Row - Smooth Horizontal touch scroll */}
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest mr-2 flex-shrink-0">Select Segment:</span>
                      <div className="flex flex-1 items-center gap-2 overflow-x-auto pb-1 scroll-smooth [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none] snap-x">
                        {subCategoryFilters.map(sub => (
                          <button 
                            key={sub}
                            onClick={() => setSelectedSubject(sub)}
                            className={`px-4 py-2 rounded-2xl text-xs font-black uppercase tracking-wider whitespace-nowrap transition-all duration-300 border flex-shrink-0 snap-start cursor-pointer hover:scale-102 active:scale-98 ${
                              selectedSubject === sub 
                                ? 'bg-indigo-50 border-indigo-200 text-indigo-700 font-black shadow-sm' 
                                : 'bg-white border-slate-200 hover:border-slate-300 text-slate-500'
                            }`}
                          >
                            {sub === 'All' ? `All in ${selectedBatch}` : sub}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* CORE SEGMENT SELECTOR TAB BAR - Horizontal Touch Slider effect */}
              <div className="relative border-b border-slate-200">
                <div className="flex items-center overflow-x-auto pb-0.5 scroll-smooth [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none] w-full snap-x">
                  <button 
                    onClick={() => setActiveSegment('courses')}
                    className={`pb-3.5 px-5 font-black text-xs uppercase tracking-widest border-b-2 transition-all duration-300 whitespace-nowrap flex-shrink-0 snap-start flex items-center gap-2 cursor-pointer ${
                      activeSegment === 'courses' 
                        ? 'border-indigo-600 text-indigo-600' 
                        : 'border-transparent text-slate-400 hover:text-slate-900'
                    }`}
                  >
                    🎓 Available Courses ({filteredCourses.length})
                  </button>
                  <button 
                    onClick={() => setActiveSegment('events')}
                    className={`pb-3.5 px-5 font-black text-xs uppercase tracking-widest border-b-2 transition-all duration-300 whitespace-nowrap flex-shrink-0 snap-start flex items-center gap-1.5 cursor-pointer ${
                      activeSegment === 'events' 
                        ? 'border-indigo-600 text-indigo-600' 
                        : 'border-transparent text-slate-400 hover:text-slate-900'
                    }`}
                  >
                    ⚡ Special Events ({filteredEvents.length})
                  </button>
                  <button 
                    onClick={() => setActiveSegment('public')}
                    className={`pb-3.5 px-5 font-black text-xs uppercase tracking-widest border-b-2 transition-all duration-300 whitespace-nowrap flex-shrink-0 snap-start flex items-center gap-1.5 cursor-pointer ${
                      activeSegment === 'public' 
                        ? 'border-indigo-600 text-indigo-600' 
                        : 'border-transparent text-slate-400 hover:text-slate-900'
                    }`}
                  >
                    🎯 Direct Public Exams ({activePublicExams.length})
                  </button>
                </div>
              </div>

              {/* GRID RESULTS OF CHOSEN SEGMENT */}
              <motion.div
                key={activeSegment + selectedBatch + selectedSubject}
                initial="hidden"
                animate="visible"
                variants={{
                  hidden: { opacity: 0 },
                  visible: {
                    opacity: 1,
                    transition: {
                      staggerChildren: 0.1
                    }
                  }
                }}
              >
                {activeSegment === 'courses' ? (
                  filteredCourses.length === 0 ? (
                    <div className="bg-white p-12 rounded-3xl border border-dashed border-slate-200 text-center space-y-3">
                      <HelpCircle className="w-10 h-10 text-slate-350 mx-auto" />
                      <p className="text-slate-500 font-semibold text-sm">No courses matching your selected filter preferences were found.</p>
                      <button 
                        onClick={() => { setSelectedBatch('All Batches'); setSelectedSubject('All'); setSearchQuery(''); }}
                        className="text-xs font-bold text-indigo-600 hover:underline"
                      >
                        Reset Filters
                      </button>
                    </div>
                  ) : (
                    <div className="grid gap-6 sm:grid-cols-2">
                      {filteredCourses.map(course => (
                        <motion.div 
                          key={course.id}
                          variants={{
                            hidden: { opacity: 0, y: 20 },
                            visible: { opacity: 1, y: 0 }
                          }}
                        >
                          {renderCourseCard(course)}
                        </motion.div>
                      ))}
                    </div>
                  )
                ) : activeSegment === 'events' ? (
                  filteredEvents.length === 0 ? (
                    <div className="bg-white p-12 rounded-3xl border border-dashed border-slate-200 text-center space-y-3">
                      <HelpCircle className="w-10 h-10 text-slate-350 mx-auto" />
                      <p className="text-slate-500 font-semibold text-sm">No upcoming Events matching selected stream found.</p>
                      <button 
                        onClick={() => { setSelectedSubject('All'); setSearchQuery(''); }}
                        className="text-xs font-bold text-indigo-600 hover:underline"
                      >
                        Reset Stream Filters
                      </button>
                    </div>
                  ) : (
                    <div className="grid gap-6 sm:grid-cols-2">
                      {filteredEvents.map(ev => (
                        <motion.div 
                          key={ev.id}
                          variants={{
                            hidden: { opacity: 0, y: 20 },
                            visible: { opacity: 1, y: 0 }
                          }}
                        >
                          {renderEventCard(ev)}
                        </motion.div>
                      ))}
                    </div>
                  )
                ) : (
                  // Direct Public Mock list
                  activePublicExams.length === 0 ? (
                    <div className="bg-white p-10 rounded-3xl border border-slate-200 text-center font-medium text-slate-500 text-sm">
                      No public exams are currently open in the live slot. Please visit one of our courses to participate in exams!
                    </div>
                  ) : (
                    <div className="grid gap-4">
                      {activePublicExams.map(exam => (
                        <motion.div 
                          key={exam.id}
                          variants={{
                            hidden: { opacity: 0, y: 20 },
                            visible: { opacity: 1, y: 0 }
                          }}
                        >
                          {renderExamCard(exam)}
                        </motion.div>
                      ))}
                    </div>
                  )
                )}
              </motion.div>

            </div>


            {/* Contact & Support Section (Links configured with proper elements) */}
            <motion.section 
              id="ots-support-section" 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-sm mt-8"
            >
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                <div className="space-y-1">
                  <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                    <span className="p-1.5 bg-indigo-50 rounded-lg text-indigo-600 block">
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192l-3.536 3.536M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-5 0a4 4 0 11-8 0 4 4 0 018 0z" /></svg>
                    </span>
                    OTS Support Helpline
                  </h3>
                  <p className="text-xs font-semibold text-slate-400 uppercase tracking-widest">Connect with our support and community platform links below</p>
                </div>
                
                <div className="flex flex-wrap gap-2.5 w-full md:w-auto">
                  <a 
                    href="https://www.facebook.com/share/18j8TYZ1SE/" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-4 py-2 bg-[#1877F2]/10 hover:bg-[#1877F2]/20 border border-[#1877F2]/20 text-[#1877F2] text-xs font-black rounded-xl transition-all"
                  >
                    <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M22 12c0-5.52-4.48-10-10-10S2 6.48 2 12c0 4.84 3.44 8.87 8 9.8V15H8v-3h2V9.5C10 7.57 11.57 6 13.5 6H16v3h-2c-.55 0-1 .45-1 1v2h3v3h-3v6.95c4.56-.93 8-4.96 8-9.75z"/></svg>
                    <span>FB Page</span>
                  </a>

                  <a 
                    href="https://wa.me/8801912428298" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-4 py-2 bg-[#25D366]/10 hover:bg-[#25D366]/20 border border-[#25D366]/20 text-[#128C7E] text-xs font-black rounded-xl transition-all"
                  >
                    <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.06 5.348 5.397.01 12.008.01c3.202.001 6.212 1.246 8.477 3.513 2.266 2.268 3.507 5.28 3.505 8.484-.004 6.657-5.34 11.997-11.953 11.997-2.005-.001-3.973-.502-5.713-1.455L0 24zm6.79-11.362c.071-.117.265-.188.494-.301.23-.115 1.353-.667 1.56-.745.206-.077.356-.115.507.114.151.23.585.742.716.892.132.148.263.167.493.051.23-.115.97-.358 1.848-1.144.682-.609 1.143-1.361 1.277-1.59.134-.23.015-.354-.1-.469-.103-.105-.23-.269-.346-.403-.114-.135-.152-.23-.23-.385-.078-.153-.039-.289-.019-.404.019-.115.152-.385.206-.52.054-.131.107-.227.051-.341-.056-.114-.507-1.22-.693-1.67-.181-.437-.367-.378-.507-.385-.131-.007-.281-.007-.432-.007-.151 0-.397.057-.604.288-.206.23-.79.771-.79 1.879s.804 2.173.917 2.327c.113.153 1.58 2.413 3.829 3.385.535.232.953.371 1.277.474.538.17 1.027.146 1.414.089.431-.064 1.353-.553 1.543-1.085.19-.533.19-1.01.134-1.104-.055-.095-.205-.15-.436-.264z"/></svg>
                    <span>01912428298</span>
                  </a>

                  <a 
                    href="https://youtube.com/@onetimeschool-ots-31?si=Nv0XKhnRzqMXF2YU" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-4 py-2 bg-[#FF0000]/10 hover:bg-[#FF0000]/20 border border-[#FF0000]/20 text-[#FF0000] text-xs font-black rounded-xl transition-all"
                  >
                    <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M23.498 6.163a3.003 3.003 0 0 0-2.11-2.11C19.517 3.545 12 3.545 12 3.545s-7.517 0-9.388.507a3.003 3.003 0 0 0-2.11 2.11C0 8.033 0 12 0 12s0 3.967.502 5.837a3.003 3.003 0 0 0 2.11 2.11c1.871.507 9.388.507 9.388.507s7.517 0 9.388-.507a3.003 3.003 0 0 0 2.11-2.11C24 15.967 24 12 24 12s0-3.967-.502-5.837zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>
                    <span>Youtube Channel</span>
                  </a>
                </div>
              </div>
            </motion.section>
          </>
        )}

        {currentTab === 'exams' && (
          <div className="space-y-6 animate-fadeIn">
            {/* Upper Switch Micro-tabs */}
            <div className="flex bg-slate-200/65 p-1 rounded-2xl max-w-sm mb-2">
              <button 
                onClick={() => setExamSubTab('quick')}
                className={`flex-1 py-3 text-center font-extrabold text-xs rounded-xl tracking-wider uppercase transition-all duration-200 cursor-pointer ${
                  examSubTab === 'quick' 
                    ? 'bg-indigo-600 text-white shadow-md' 
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/40'
                }`}
              >
                Quick Access
              </button>
              <button 
                onClick={() => setExamSubTab('upcoming')}
                className={`flex-1 py-3 text-center font-extrabold text-xs rounded-xl tracking-wider uppercase transition-all duration-200 cursor-pointer ${
                  examSubTab === 'upcoming' 
                    ? 'bg-indigo-600 text-white shadow-md' 
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/40'
                }`}
              >
                Upcoming Exams
              </button>
            </div>

            {/* Glowing Live status box */}
            {liveExamsList.length > 0 ? (
              <div className="flex items-center gap-3 p-4 bg-rose-50 border border-rose-100 rounded-2xl shadow-sm animation-pulse">
                <div className="w-2.5 h-2.5 bg-rose-600 rounded-full animate-ping" />
                <span className="font-extrabold text-[10px] bg-rose-600 text-white uppercase tracking-widest px-2.5 py-1 rounded-md">
                  Live Exam
                </span>
                <span className="text-xs text-rose-800 font-extrabold font-display">
                  {liveExamsList.length} Live mock trial(s) are active right now! Join now to score.
                </span>
              </div>
            ) : (
              <div className="flex items-center gap-3 p-4 bg-slate-100 border border-slate-200/80 rounded-2xl">
                <div className="w-2.5 h-2.5 bg-slate-400 rounded-full" />
                <span className="font-extrabold text-[10px] bg-slate-500 text-white uppercase tracking-widest px-2.5 py-1 rounded-md">
                  Live Status
                </span>
                <span className="text-xs text-slate-500 font-bold font-display">
                  No Exam available in the live section at this timezone.
                </span>
              </div>
            )}

            {/* Primary Filter Selector Dashboard Card */}
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-5">
              <div className="border-b border-slate-100 pb-4">
                <h3 className="text-xl font-black text-slate-900 flex items-center gap-2 font-display">
                  <PlayCircle className="w-5.5 h-5.5 text-indigo-600" />
                  Exam Section (পরীক্ষা বিভাগ)
                </h3>
                <p className="text-slate-400 text-xs font-bold uppercase tracking-widest mt-1">Select your batch or stream custom filters to search exams.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                {/* Select Course Selection */}
                <div className="space-y-1.5 text-left">
                  <label className="block text-xs font-black text-slate-700 uppercase tracking-wider">Select Course (কোর্স সিলেক্ট করুন)</label>
                  <div className="relative">
                    <select 
                      value={examSelectCourseId} 
                      onChange={e => setExamSelectCourseId(e.target.value)}
                      className="w-full pl-4 pr-10 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-600 outline-none text-sm font-bold text-slate-800 cursor-pointer appearance-none transition-all"
                    >
                      <option value="">-- All Registered Courses --</option>
                      {courses.filter(c => enrolledCourseIds.includes(c.id)).map(course => (
                        <option key={course.id} value={course.id}>{course.title} ({course.category})</option>
                      ))}
                      <option value="public">🌍 General Public Exams (সবার জন্য উন্মুক্ত)</option>
                    </select>
                    <div className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 text-slate-500">
                      <ChevronDown className="w-4 h-4 stroke-[3]" />
                    </div>
                  </div>
                </div>

                {/* Date Input Select */}
                <div className="space-y-1.5 text-left">
                  <label className="block text-xs font-black text-slate-700 uppercase tracking-wider">Exam Date (পরীক্ষার তারিখ)</label>
                  <input 
                    type="date" 
                    value={examSelectDate} 
                    onChange={e => setExamSelectDate(e.target.value)}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-600 outline-none text-sm font-bold text-slate-800 transition-all font-mono"
                  />
                </div>
              </div>

              {/* Action and Redirect Area */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-3 border-t border-slate-150">
                <button 
                  onClick={() => {
                    // Force refresh/filter
                  }}
                  className="w-full sm:w-auto px-10 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs uppercase tracking-widest rounded-2xl transition-all shadow-lg shadow-indigo-600/20 active:scale-[0.98]"
                >
                  Apply Filters
                </button>
                
                <button 
                  onClick={() => {
                    setCurrentTab('home');
                    setActiveSegment('courses');
                  }}
                  className="text-xs font-black text-indigo-600 hover:text-indigo-800 transition-colors uppercase tracking-wider underline flex items-center gap-1.5"
                >
                  Didn't find all courses? Click here
                </button>
              </div>
            </div>

            {/* LIVE EXAMS LIST SECTION */}
            <div className="space-y-4 text-left">
              <div className="flex items-center gap-2 pl-1">
                <div className="w-2 h-2 bg-rose-600 rounded-full animate-ping" />
                <h4 className="text-sm font-black text-rose-600 uppercase tracking-widest">Live Exams (চলমান পরীক্ষা)</h4>
              </div>

              {examSubTab === 'upcoming' ? (
                // Upcoming list filtering
                exams.filter(e => e.status === 'published' && Date.now() < e.startTime).length === 0 ? (
                  <div className="bg-slate-50/50 border border-dashed border-slate-200 p-8 text-center rounded-3xl text-slate-400 font-bold text-xs uppercase tracking-widest">
                    No upcoming live scheduling sessions registered.
                  </div>
                ) : (
                  <div className="grid gap-4">
                    {exams
                      .filter(e => {
                        const isUpcoming = Date.now() < e.startTime;
                        // Match course
                        if (examSelectCourseId) {
                          if (examSelectCourseId === 'public') {
                            if (e.accessType !== 'public') return false;
                          } else {
                            if (e.accessType !== 'course' || !e.courseIds?.includes(examSelectCourseId)) return false;
                          }
                        }
                        return e.status === 'published' && isUpcoming;
                      })
                      .map(renderExamCard)
                    }
                  </div>
                )
              ) : (
                // Quick Access Live Exams
                liveExamsList.length === 0 ? (
                  <div className="bg-white border border-slate-150 p-8 rounded-3xl text-center shadow-sm space-y-3">
                    <Layers className="w-10 h-10 text-slate-300 mx-auto stroke-[1.5]" />
                    <div className="space-y-1">
                      <h4 className="text-slate-800 font-extrabold text-sm">No Exam available (কোনো পরীক্ষা চলমান নেই)</h4>
                      <p className="text-slate-400 text-[11px] font-semibold uppercase tracking-wider max-w-sm mx-auto">There are currently no live sessions matching this filter structure. Set parameters to check practice segments!</p>
                    </div>
                  </div>
                ) : (
                  <div className="grid gap-4">
                    {liveExamsList.map(renderExamCard)}
                  </div>
                )
              )}
            </div>

            {/* PRACTICE EXAMS SECTION */}
            {examSubTab === 'quick' && (
              <div className="space-y-4 text-left">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pl-1">
                  <h4 className="text-sm font-black text-indigo-600 uppercase tracking-widest flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-indigo-500" />
                    Practice Exams (অনুশীলন পরীক্ষা)
                  </h4>

                  {/* Search Title Field */}
                  <div className="relative w-full sm:w-72">
                    <input 
                      type="text" 
                      placeholder="Search by exam title..." 
                      value={examSearchPracticeQuery} 
                      onChange={e => setExamSearchPracticeQuery(e.target.value)}
                      className="w-full pl-4 pr-10 py-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none text-xs font-bold text-slate-800 transition-all placeholder:text-slate-400"
                    />
                    <div className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400">
                      <Search className="w-4 h-4" />
                    </div>
                  </div>
                </div>

                {/* Practice List rendering */}
                {practiceExamsList.length === 0 ? (
                  <div className="bg-slate-50 border border-slate-200 p-8 text-center rounded-3xl text-slate-400 font-extrabold text-xs uppercase tracking-widest">
                    No practice examinations found for this selection.
                  </div>
                ) : (
                  <div className="grid gap-4">
                    {practiceExamsList
                      .filter(exam => {
                        if (!examSearchPracticeQuery) return true;
                        return exam.title.toLowerCase().includes(examSearchPracticeQuery.toLowerCase());
                      })
                      .map(exam => {
                        const totalQuestions = exam.questions?.length || 0;
                        const totalMarks = exam.questions?.reduce((acc, q) => acc + (q.marks ?? 1), 0) || 0;
                        const mySubmissions = results.filter(r => r.examId === exam.id && r.userId === currentUser?.id);
                        const hasTaken = mySubmissions.length > 0;
                        const latestResult = mySubmissions[mySubmissions.length - 1];

                        return (
                          <div 
                            key={exam.id} 
                            className={`bg-white border p-5 sm:p-6 rounded-3xl flex flex-col md:flex-row gap-5 items-start md:items-center justify-between transition-all duration-300 shadow-sm border-b-4 hover:-translate-y-1 ${
                              hasTaken 
                                ? 'border-emerald-100 border-b-emerald-300 bg-emerald-50/10' 
                                : 'border-slate-200 border-b-slate-300 hover:border-indigo-400 hover:border-b-indigo-500 hover:shadow-indigo-500/10'
                            }`}
                          >
                            <div className="space-y-2">
                              {/* Headers and Badge */}
                              <div className="flex flex-wrap items-center gap-2">
                                <span className="text-[10px] font-extrabold text-indigo-600 uppercase tracking-widest">
                                  {exam.subject || 'Syllabus Topic'} • MCQ: {totalQuestions}
                                </span>
                                <span className="text-[9px] font-black text-amber-600 bg-amber-50 px-2.5 py-1 rounded-full border border-amber-100 uppercase tracking-widest">
                                  Practice Exam
                                </span>
                              </div>
                              
                              {/* Title */}
                              <h5 className="font-extrabold text-slate-900 text-base tracking-tight leading-snug">
                                {exam.title}
                              </h5>

                              <div className="text-xs text-slate-500 font-bold">
                                Topic: <span className="text-slate-700 font-extrabold">{exam.subject || 'All Units'}</span>
                              </div>

                              {/* Attributes Info */}
                              <div className="flex flex-wrap items-center gap-4 text-xs font-bold text-slate-600 pt-1.5">
                                <div className="flex items-center gap-1.5">
                                  <Clock className="w-4 h-4 text-slate-400" />
                                  <span>Duration: {exam.durationMinutes}m</span>
                                </div>
                                <div className="flex items-center gap-1.5">
                                  <Medal className="w-4 h-4 text-slate-400" />
                                  <span>Mark: {totalMarks}</span>
                                </div>
                                <div className="flex items-center gap-1 text-slate-400">
                                  <span className="w-1.5 h-1.5 bg-slate-400 rounded-full" />
                                  <span>Full Syllabus</span>
                                </div>
                                <div className="flex items-center gap-1 text-slate-400">
                                  <span className="w-1.5 h-1.5 bg-slate-400 rounded-full" />
                                  <span>{totalQuestions} MCQ</span>
                                </div>
                              </div>

                              {/* Previous Trial Result Badge */}
                              {hasTaken && (
                                <div className="inline-flex items-center gap-1.5 text-xs font-black text-emerald-600 bg-emerald-50 border border-emerald-100 py-1 px-3 rounded-lg mt-2">
                                  <Check className="w-3.5 h-3.5" />
                                  <span>Score: {latestResult.score} pts ({Math.round(latestResult.accuracy)}% Accuracy)</span>
                                </div>
                              )}
                            </div>

                            {/* Go to Exam Start Trigger Button */}
                            <div className="flex items-center gap-2.5 w-full md:w-auto mt-4 md:mt-0 pt-4 md:pt-0 border-t md:border-none border-slate-100">
                              {hasTaken && (
                                <button 
                                  onClick={() => navigate(`/student/result/${exam.id}`)}
                                  className="flex-1 md:flex-initial px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-black uppercase tracking-wider rounded-xl transition-all"
                                >
                                  Solutions
                                </button>
                              )}
                              <button 
                                onClick={() => handleStartAttempt(exam)}
                                className="flex-1 md:flex-initial px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black uppercase tracking-widest rounded-xl transition-all shadow-md shadow-indigo-600/10 hover:shadow-indigo-600/35"
                              >
                                Go to Exam
                              </button>
                            </div>
                          </div>
                        );
                      })
                    }
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {currentTab === 'results' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm relative overflow-hidden">
              <div className="absolute top-0 right-0 p-8 hidden sm:block opacity-20 pointer-events-none">
                <Medal className="w-48 h-48 text-indigo-300" />
              </div>
              <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
                <div>
                  <h3 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
                    My Exam Results
                  </h3>
                  <p className="text-xs font-bold uppercase tracking-widest text-slate-400 mt-1">Review your historical accuracy and submissions.</p>
                </div>
                {/* Search */}
                <div className="relative w-full sm:w-64 max-w-sm">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    placeholder="Search by exam name, subject..."
                    value={resultsSearchQuery}
                    onChange={e => setResultsSearchQuery(e.target.value)}
                    className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 hover:border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none text-slate-800 font-semibold text-xs transition-colors"
                  />
                </div>
              </div>

              {/* Enhanced Performance Analytics Tracking Section for My Results Tab */}
              {userResults.length > 0 && (
                <div className="mb-10 p-6 bg-slate-50 rounded-2xl border border-slate-200">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                    <div>
                      <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                        <Target className="w-5 h-5 text-indigo-500" />
                        Accuracy Flow Tracking
                      </h3>
                      <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-widest mt-0.5">Your journey over recent exams</p>
                    </div>
                    <div className="flex items-center gap-4 bg-white px-4 py-2 rounded-xl border border-slate-200 shadow-sm font-medium">
                      <div className="text-center">
                        <div className="text-2xl font-black text-indigo-600">{averageAccuracy}%</div>
                        <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Avg Accuracy</div>
                      </div>
                      <div className="w-px h-8 bg-slate-200"></div>
                      <div className="text-center">
                        <div className="text-2xl font-black text-slate-800">{userResults.length}</div>
                        <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Exams Taken</div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="h-44 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={performanceData} margin={{ top: 5, right: 5, left: -25, bottom: 0 }}>
                        <defs>
                          <linearGradient id="colorAccuracy2" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.3}/>
                            <stop offset="95%" stopColor="#4f46e5" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                        <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#64748b', fontWeight: 600 }} dy={10} />
                        <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#64748b', fontWeight: 600 }} />
                        <Tooltip 
                          contentStyle={{ borderRadius: '12px', border: '1px solid #e2e8f0', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', fontWeight: 'bold' }}
                          itemStyle={{ color: '#4f46e5' }}
                        />
                        <Area type="monotone" dataKey="accuracy" name="Accuracy %" stroke="#4f46e5" strokeWidth={3} fillOpacity={1} fill="url(#colorAccuracy2)" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              )}

              {filteredUserResults.length === 0 ? (
                <div className="py-16 text-center text-slate-500 font-semibold border-2 border-dashed border-slate-200 rounded-2xl bg-slate-50">
                  <Medal className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                  <p>No results found matching your criteria.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {filteredUserResults.map(result => {
                    const exam = exams.find(e => e.id === result.examId);
                    return (
                      <div key={result.id} className="bg-white border border-slate-200 border-b-[4px] border-b-slate-200 hover:border-indigo-400 hover:border-b-indigo-400 rounded-[20px] p-5 shadow-[0_4px_20px_rgb(0,0,0,0.04)] hover:shadow-[0_15px_30px_-5px_rgba(99,102,241,0.15)] transition-all duration-300 hover:-translate-y-1 flex flex-col justify-between">
                        <div>
                          <div className="flex items-start justify-between mb-2">
                             <div className="space-y-1 pr-4">
                                <h3 className="font-bold text-slate-900 text-sm line-clamp-2">{exam?.title || 'Unknown Exam'}</h3>
                                <div className="flex items-center gap-2 text-xs font-semibold text-slate-500">
                                   <Clock className="w-3.5 h-3.5" />
                                   {format(result.submittedAt, 'MMM d, h:mm a')}
                                </div>
                             </div>
                             <div className="flex-shrink-0 text-right">
                               <div className="text-lg font-black text-indigo-600">{result.score}/{result.totalQuestions}</div>
                               <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Score</div>
                             </div>
                          </div>
                        </div>
                        <div className="mt-4 pt-4 border-t border-slate-100 grid grid-cols-3 gap-2">
                          <div className="text-center bg-emerald-50 rounded-lg p-2">
                            <div className="text-sm font-black text-emerald-600">{result.correctAnswers}</div>
                            <div className="text-[9px] font-black uppercase text-slate-500 mt-0.5">Correct</div>
                          </div>
                          <div className="text-center bg-rose-50 rounded-lg p-2">
                               <div className="text-sm font-black text-rose-600">{result.wrongAnswers}</div>
                               <div className="text-[9px] font-black uppercase text-slate-500 mt-0.5">Wrong</div>
                          </div>
                          <div className="text-center bg-indigo-50 rounded-lg p-2">
                               <div className="text-sm font-black text-indigo-600">{result.accuracy}%</div>
                               <div className="text-[9px] font-black uppercase text-slate-500 mt-0.5">Accuracy</div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}

        {currentTab === 'leaderboard' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm relative overflow-hidden">
               <div className="absolute -top-10 -right-10 hidden sm:block opacity-10 pointer-events-none">
                <Trophy className="w-64 h-64 text-indigo-600" />
              </div>
              
              <div className="relative z-10 flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
                <div>
                   <h3 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-3">
                    Global Leaderboards
                  </h3>
                  <p className="text-xs font-bold uppercase tracking-widest text-slate-400 mt-1">Select an exam to view rankings</p>
                </div>
                
                <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
                    {/* Exam Selector */}
                    <div className="relative w-full sm:w-56">
                      <select
                        value={activeLeaderboardExamId}
                        onChange={(e) => setSelectedLeaderboardExamId(e.target.value)}
                        className="w-full pl-4 pr-10 py-2.5 bg-slate-50 border border-slate-200 hover:border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none text-slate-800 font-bold text-xs appearance-none transition-colors"
                      >
                        {eligibleLeaderboardExams.length === 0 && <option value="">No Active Exams</option>}
                        {eligibleLeaderboardExams.map(ex => (
                           <option key={ex.id} value={ex.id}>{ex.title}</option>
                        ))}
                      </select>
                      <ChevronDown className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                    </div>

                    {/* Search Search */}
                    <div className="relative w-full sm:w-56">
                      <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        placeholder="Search student name..."
                        value={leaderboardSearchQuery}
                        onChange={e => setLeaderboardSearchQuery(e.target.value)}
                        className="w-full pl-9 pr-4 py-2.5 bg-slate-50 border border-slate-200 hover:border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none text-slate-800 font-semibold text-xs transition-colors"
                      />
                    </div>
                </div>
              </div>

              {!activeLeaderboardExamId ? (
                <div className="py-16 text-center text-slate-500 font-semibold border-2 border-dashed border-slate-200 rounded-2xl bg-slate-50">
                  <Trophy className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                  <p>No exams available for leaderboard.</p>
                </div>
              ) : (
                <div className="space-y-4">
                   {/* Personal Rank Banner Context */}
                   {currentUserLeaderboardRank && (
                      <div className="flex items-center justify-between bg-indigo-50 border border-indigo-100 p-4 rounded-2xl mb-6 shadow-sm">
                         <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-indigo-600 text-white flex items-center justify-center font-black drop-shadow-md">
                               #{currentUserLeaderboardRank}
                            </div>
                            <div>
                               <div className="font-extrabold text-sm text-slate-900">Your Ranking Position</div>
                               <div className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest">{chosenLeaderboardExam?.title}</div>
                            </div>
                         </div>
                      </div>
                   )}

                   <div className="bg-white border border-slate-200 shadow-sm rounded-2xl overflow-hidden">
                      <div className="overflow-x-auto min-h-[300px]">
                        <table className="w-full text-left border-collapse">
                          <thead>
                            <tr className="bg-slate-50 border-b border-slate-200 text-xs text-slate-500 uppercase tracking-widest font-black">
                              <th className="py-4 pl-6 pr-4 font-black">Rank</th>
                              <th className="py-4 px-4 font-black">Student</th>
                              <th className="py-4 px-4 text-center font-black">Score</th>
                              <th className="py-4 px-4 text-center font-black">Accuracy</th>
                              <th className="py-4 px-6 text-right font-black">Time</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100 font-medium text-sm">
                            {filteredLeaderboardRows.length === 0 ? (
                               <tr>
                                  <td colSpan={5} className="py-12 text-center text-slate-500 bg-slate-50/50">
                                     <div className="flex flex-col items-center justify-center space-y-2">
                                        <Trophy className="w-8 h-8 text-slate-300" />
                                        <span className="font-semibold text-xs text-slate-400">No submissions found.</span>
                                     </div>
                                  </td>
                               </tr>
                            ) : (
                               filteredLeaderboardRows.map((row, idx) => {
                                 const student = users.find(u => u.id === row.userId);
                                 // Determine real rank purely by index in leaderboardRows (which is pre-sorted)
                                 const realRank = leaderboardRows.findIndex(r => r.userId === row.userId) + 1;
                                 const isCurrentUser = row.userId === currentUser?.id;

                                 return (
                                   <motion.tr 
                                     key={row.id} 
                                     initial={{ opacity: 0, scale: 0.95 }}
                                     animate={{ opacity: 1, scale: 1 }}
                                     transition={{ duration: 0.3 }}
                                     className={`transition-colors ${isCurrentUser ? 'bg-indigo-50/50 hover:bg-indigo-50/80' : 'hover:bg-slate-50'}`}>
                                      <td className="py-3 pl-6 pr-4 whitespace-nowrap">
                                        <div className="flex items-center gap-2">
                                            {realRank === 1 && <span className="text-xl">🥇</span>}
                                            {realRank === 2 && <span className="text-xl">🥈</span>}
                                            {realRank === 3 && <span className="text-xl">🥉</span>}
                                            <span className={`font-black ${realRank <= 3 ? 'text-slate-900 border border-slate-200 px-2.5 py-1 rounded-full text-xs shadow-sm shadow-slate-200' : 'text-slate-500 pl-2 text-sm'}`}>
                                              {realRank > 3 ? `#${realRank}` : ``}
                                            </span>
                                        </div>
                                      </td>
                                      <td className="py-3 px-4">
                                         <div className="flex items-center gap-3">
                                            {student?.profile?.photoUrl ? (
                                               <img src={student.profile.photoUrl} alt="Avatar" className="w-8 h-8 rounded-full shadow-sm drop-shadow-sm object-cover" />
                                            ) : (
                                               <div className="w-8 h-8 rounded-full bg-slate-200 flex flex-shrink-0 items-center justify-center shadow-sm">
                                                  <User className="w-4 h-4 text-slate-400" />
                                               </div>
                                            )}
                                            <div>
                                               <div className="font-bold text-slate-900 line-clamp-1 group flex items-center gap-2">
                                                  {student?.name || 'Unknown Student'}
                                                  {isCurrentUser && <span className="px-1.5 py-0.5 bg-indigo-100 text-indigo-700 rounded text-[9px] uppercase font-black uppercase tracking-widest hidden sm:inline-block">You</span>}
                                               </div>
                                               <div className="text-[10px] text-slate-400 font-semibold tracking-wider uppercase truncate max-w-[120px] sm:max-w-xs block">{student?.profile?.collegeName || 'No college specified'}</div>
                                            </div>
                                         </div>
                                      </td>
                                      <td className="py-3 px-4 text-center">
                                         <span className="font-black text-indigo-600 bg-indigo-50 px-2 py-1 rounded text-sm drop-shadow-xs border border-indigo-100 min-w-[40px] inline-block">{row.score}</span>
                                      </td>
                                      <td className="py-3 px-4 text-center">
                                         <span className="font-bold text-slate-700">{row.accuracy}%</span>
                                      </td>
                                      <td className="py-3 px-6 text-right whitespace-nowrap">
                                         <span className="font-bold text-xs text-slate-500 hidden sm:inline-block">
                                            {row.timeTakenSeconds ? `${Math.floor(row.timeTakenSeconds / 60)}m ${row.timeTakenSeconds % 60}s` : '-'}
                                         </span>
                                         <span className="text-xs font-semibold text-slate-400 block sm:hidden">
                                           {format(row.submittedAt, 'MMM d, h:mm a')}
                                         </span>
                                      </td>
                                   </motion.tr>
                                 );
                               })
                            )}
                          </tbody>
                        </table>
                      </div>
                   </div>
                </div>
              )}

            </div>
          </div>
        )}

        {currentTab === 'routine' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm relative overflow-hidden">
              <div className="absolute top-0 right-0 p-8 hidden sm:block opacity-20 pointer-events-none">
                <Calendar className="w-48 h-48 text-indigo-300" />
              </div>
              <div className="relative z-10 mb-8">
                <h3 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">Course Routine</h3>
                <p className="text-xs font-bold uppercase tracking-widest text-slate-400 mt-1">Schedules for your enrolled courses</p>
              </div>

              <div className="grid grid-cols-1 gap-6 relative z-10">
                {enrolledCourseIds.length === 0 ? (
                  <div className="py-16 text-center text-slate-500 font-semibold border-2 border-dashed border-slate-200 rounded-2xl bg-slate-50">
                    <Calendar className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                    <p>You have not enrolled in any courses yet.</p>
                  </div>
                ) : (
                  courses.filter(c => enrolledCourseIds.includes(c.id)).map(course => (
                    <div key={course.id} className="bg-white border border-slate-200 border-b-[4px] border-b-slate-200 hover:border-indigo-400 hover:border-b-indigo-400 rounded-[20px] p-6 shadow-[0_4px_20px_rgb(0,0,0,0.04)] hover:shadow-[0_15px_30px_-5px_rgba(99,102,241,0.15)] transition-all duration-300 hover:-translate-y-1">
                      <h4 className="text-lg font-bold text-slate-800 mb-4">{course.title}</h4>
                      {(!course.routineImageUrl && !course.routineText) ? (
                        <p className="text-sm text-slate-500 italic">No routine published yet.</p>
                      ) : (
                        <div className="space-y-4">
                          {course.routineImageUrl && (
                            <img src={course.routineImageUrl} alt={`${course.title} Routine`} className="w-full max-w-2xl rounded-xl border border-slate-200 shadow-sm" />
                          )}
                          {course.routineText && (
                            <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 whitespace-pre-wrap text-sm text-slate-700 font-medium leading-relaxed">
                              {course.routineText}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}

        {currentTab === 'report' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm relative overflow-hidden">
               <div className="absolute top-0 right-0 p-8 hidden sm:block opacity-10 pointer-events-none">
                <AlertTriangle className="w-48 h-48 text-rose-500" />
              </div>
              <div className="relative z-10 max-w-xl">
                <h3 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">Report an Issue</h3>
                <p className="text-xs font-bold uppercase tracking-widest text-slate-400 mt-1 mb-8">Send a message directly to admin</p>

                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Subject</label>
                    <input type="text" placeholder="What is this about?" className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none font-medium text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Description</label>
                    <textarea rows={5} placeholder="Describe your issue in detail..." className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none font-medium text-sm resize-y" />
                  </div>
                  <button className="px-6 py-2.5 bg-indigo-600 text-white font-bold rounded-xl shadow-sm hover:bg-indigo-700 transition-colors w-full sm:w-auto">
                    Submit Report
                  </button>
                  <p className="text-[10px] text-slate-400 font-semibold mt-2">Note: This is a simulated action. No real email is sent.</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {currentTab === 'faq' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm relative overflow-hidden">
              <div className="absolute top-0 right-0 p-8 hidden sm:block opacity-10 pointer-events-none">
                <FileText className="w-48 h-48 text-indigo-600" />
              </div>
              <div className="relative z-10 mb-8">
                <h3 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">Frequently Asked Questions</h3>
                <p className="text-xs font-bold uppercase tracking-widest text-slate-400 mt-1">Get quick answers to common queries</p>
              </div>

              <div className="space-y-4 relative z-10">
                {(!faqs || faqs.length === 0) ? (
                  <div className="py-16 text-center text-slate-500 font-semibold border-2 border-dashed border-slate-200 rounded-2xl bg-slate-50">
                    <FileText className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                    <p>No FAQs available at the moment.</p>
                  </div>
                ) : (
                  faqs.map(faq => (
                    <div key={faq.id} className="bg-slate-50 border border-slate-200 rounded-2xl p-5 hover:border-indigo-300 transition-colors">
                      <h4 className="text-base font-bold text-slate-900 mb-2">{faq.question}</h4>
                      <p className="text-sm font-medium text-slate-600 whitespace-pre-wrap">{faq.answer}</p>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}

          </>
        )}
      </main>

      {/* Unified bKash / Nagad / Rocket Payment Modal */}
      {paymentTarget && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white max-w-sm w-full rounded-3xl overflow-hidden shadow-2xl relative animate-slideDown">
            <button 
              onClick={() => setPaymentTarget(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 p-2 rounded-full transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
            <div className="p-8 pb-5 border-b border-slate-100">
              <span className="px-2.5 py-0.5 bg-indigo-50 text-indigo-700 rounded text-[9px] font-black uppercase tracking-wider">Secure Checker Gateway</span>
              <h2 className="text-xl font-extrabold text-slate-900 mt-2">Get Admission Access</h2>
              <p className="text-slate-500 font-medium text-xs mt-0.5 leading-normal">
                Course/Exam: <strong className="text-slate-800">{paymentTarget.title}</strong>
              </p>
            </div>
            
            <div className="p-6 bg-slate-50 border-b border-slate-100">
              <div className="flex justify-between items-center bg-white p-4 rounded-xl border border-slate-200 shadow-sm mb-3">
                 <div>
                   <div className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest">Admission Fee</div>
                   <div className="text-base font-black text-slate-900">৳{paymentTarget.amount}</div>
                 </div>
                 <div className="text-right text-[10px] text-slate-400 font-bold">100% Secure</div>
              </div>

              {/* YouTube Tutorial Link Banner */}
              {paymentConfig?.youtubeUrl && (
                <a 
                  href={paymentConfig.youtubeUrl} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="mb-3.5 flex items-center gap-3 p-3 bg-red-600/10 hover:bg-red-600/15 border border-red-500/15 rounded-2xl transition-all duration-350 group cursor-pointer shadow-sm"
                >
                  <div className="w-9 h-9 rounded-xl bg-red-600 text-white flex items-center justify-center shadow-md shadow-red-600/20 group-hover:scale-105 active:scale-95 transition-all flex-shrink-0 animate-pulse">
                    <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                      <path d="M23.498 6.163a3.003 3.003 0 0 0-2.11-2.11C19.517 3.545 12 3.545 12 3.545s-7.517 0-9.388.507a3.003 3.003 0 0 0-2.11 2.11C0 8.033 0 12 0 12s0 3.967.502 5.837a3.003 3.003 0 0 0 2.11 2.11c1.871.507 9.388.507 9.388.507s7.517 0 9.388-.507a3.003 3.003 0 0 0 2.11-2.11C24 15.967 24 12 24 12s0-3.967-.502-5.837zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
                    </svg>
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-[9px] font-black text-rose-600 uppercase tracking-wider leading-none">Need Help? / পেমেন্ট নির্দেশিকা</div>
                    <div className="text-[10.5px] font-black text-slate-800 uppercase mt-1 leading-none group-hover:underline flex items-center gap-1">
                      <span>How to Pay? Watch Video</span>
                      <ArrowRight className="w-3 h-3 text-rose-600 group-hover:translate-x-0.5 transition-transform stroke-[2.5]" />
                    </div>
                  </div>
                </a>
              )}

              <div className="space-y-4">
                <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">
                    Select Gateway & Send Money
                </div>
                
                <div className="grid grid-cols-3 gap-1.5">
                  {(['bkash', 'nagad', 'rocket'] as const).map(method => (
                    <button
                      key={method}
                      type="button"
                      onClick={() => setPaymentMethod(method)}
                      className={`p-2 rounded-xl border flex flex-col items-center gap-1 transition-all ${
                        paymentMethod === method 
                          ? 'border-indigo-500 bg-indigo-50 text-indigo-700 shadow-inner scale-102 font-black font-display font-black' 
                          : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                       <div className="font-black text-[10px] uppercase">{method}</div>
                       <div className="text-[9px] font-mono font-bold text-slate-400">{paymentConfig[method]}</div>
                    </button>
                  ))}
                </div>

                {/* Highly readable copy panel */}
                <div className="bg-white border border-slate-200 rounded-2xl p-4 flex flex-col gap-2 shadow-sm relative overflow-hidden transition-all duration-300">
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] font-black uppercase tracking-wider text-slate-500 flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-indigo-600 animate-ping"></span>
                      Copy {paymentMethod} Number:
                    </span>
                    {copiedNumber === paymentConfig[paymentMethod] && (
                      <span className="text-[9px] font-black uppercase tracking-wider text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 animate-pulse">
                        Copied / কপি হয়েছে!
                      </span>
                    )}
                  </div>

                  <button
                    type="button"
                    onClick={() => handleCopyToClipboard(paymentConfig[paymentMethod])}
                    className="w-full flex items-center justify-between bg-slate-50 hover:bg-slate-100/80 border border-slate-200 hover:border-indigo-500 rounded-xl p-3 text-left transition-all active:scale-[0.99] group cursor-pointer"
                    title={`Click to copy ${paymentMethod} number`}
                  >
                    <div className="flex flex-col">
                      <span className="text-base font-mono font-black text-slate-900 group-hover:text-indigo-600 transition-colors tracking-wider">
                        {paymentConfig[paymentMethod] || '01XXXXXXXXX'}
                      </span>
                      <span className="text-[10px] font-extrabold text-slate-400 mt-1 uppercase tracking-widest">
                        Tap text inside to copy / কপি করতে এখানে চাপুন
                      </span>
                    </div>
                    <div className="w-8 h-8 rounded-lg bg-white text-indigo-600 flex items-center justify-center border border-slate-200 group-hover:bg-indigo-600 group-hover:text-white group-hover:border-transparent transition-all flex-shrink-0">
                      {copiedNumber === paymentConfig[paymentMethod] ? (
                        <Check className="w-4 h-4" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </div>
                  </button>
                </div>
              </div>
            </div>

            <form onSubmit={handlePaymentSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-[10px] font-black text-slate-500 mb-1.5 uppercase tracking-widest">Transaction ID (TrxID)</label>
                <input 
                  type="text" 
                  required
                  placeholder="e.g. BY10A492M0"
                  value={trxId} 
                  onChange={e => setTrxId(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none font-mono text-xs tracking-widest uppercase text-slate-950 font-bold"
                />
              </div>
              <button 
                type="submit"
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-2.5 rounded-xl text-xs font-black uppercase tracking-wider transition-all shadow-md"
              >
                Submit Payment Verification
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
