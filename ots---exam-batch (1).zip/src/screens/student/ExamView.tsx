import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useStore } from '../../store/useStore';
import { Clock, AlertCircle, ArrowLeft, ArrowRight, CheckCircle2 } from 'lucide-react';
import { cn } from '../../lib/utils';
import { SubmitConfirmationModal } from '../../components/SubmitConfirmationModal';
import { ExamInstructionsModal } from '../../components/ExamInstructionsModal';

export default function ExamView() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { exams, currentUser, submitExamOption, payments, results } = useStore();
  
  const exam = exams.find(e => e.id === id);
  
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [timeLeft, setTimeLeft] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSubmitModal, setShowSubmitModal] = useState(false);
  const [showInstructions, setShowInstructions] = useState(true);
  const [warningMessage, setWarningMessage] = useState<string | null>(null);
  const [timeAlert, setTimeAlert] = useState<{ message: string, color: string } | null>(null);
  const [alertsTriggered, setAlertsTriggered] = useState({ fiveMin: false, oneMin: false });
  const banglaLabels = ['ক', 'খ', 'গ', 'ঘ', 'ঙ'];
  const [tabCorrectionCount, setTabCorrectionCount] = useState(0);

  // Anti-cheating measures
  useEffect(() => {
    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault();
      setWarningMessage('Right-click is disabled during the exam.');
      setTimeout(() => setWarningMessage(null), 3000);
    };

    const handleCopyPaste = (e: ClipboardEvent) => {
      e.preventDefault();
      setWarningMessage('Copy and paste are disabled during the exam.');
      setTimeout(() => setWarningMessage(null), 3000);
    };

    const handleVisibilityChange = () => {
      if (document.hidden) {
        setWarningMessage('Warning: Changing tabs or minimizing is considered suspicious activity.');
        setTabCorrectionCount(prev => prev + 1);
        setTimeout(() => setWarningMessage(null), 5000);
      }
    };

    document.addEventListener('contextmenu', handleContextMenu);
    document.addEventListener('copy', handleCopyPaste);
    document.addEventListener('paste', handleCopyPaste);
    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      document.removeEventListener('contextmenu', handleContextMenu);
      document.removeEventListener('copy', handleCopyPaste);
      document.removeEventListener('paste', handleCopyPaste);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, []);

  useEffect(() => {
    if (!exam || !currentUser) return;
    
    // Check payment access
    if (exam.isPaid) {
      const existingPayment = payments.find(p => p.userId === currentUser.id && p.targetId === exam.id && p.targetType === 'exam');
      if (existingPayment?.status !== 'verified') {
        alert('You do not have access to this exam. Please complete the payment process first.');
        navigate('/student');
        return;
      }
    }

    // Check multiple attempts on live exams
    const isLiveNow = Date.now() <= exam.endTime;
    const hasAttempted = results.some(r => r.userId === currentUser.id && r.examId === exam.id && r.attemptType !== 'practice');
    if (isLiveNow && hasAttempted) {
      alert('You have already taken this live exam. Only one attempt is permitted.');
      navigate(`/student/result/${exam.id}`);
      return;
    }

    setTimeLeft(exam.durationMinutes * 60);
  }, [exam, currentUser, payments, results, navigate]);

  const playAlertSound = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();

      oscillator.connect(gainNode);
      gainNode.connect(audioCtx.destination);

      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(440, audioCtx.currentTime); // A4 note
      gainNode.gain.setValueAtTime(0, audioCtx.currentTime);
      gainNode.gain.linearRampToValueAtTime(0.2, audioCtx.currentTime + 0.1);
      gainNode.gain.linearRampToValueAtTime(0, audioCtx.currentTime + 0.5);

      oscillator.start();
      oscillator.stop(audioCtx.currentTime + 0.5);
    } catch (e) {
      console.warn('Audio alert not supported or blocked by browser policy', e);
    }
  };

  useEffect(() => {
    if (showInstructions) return;
    if (timeLeft <= 0 && exam && !isSubmitting) {
      handleSubmit();
      return;
    }

    // Time Alerts Logic
    if (timeLeft === 300 && !alertsTriggered.fiveMin) {
      setTimeAlert({ message: 'Only 5 Minutes Remaining!', color: 'bg-amber-500' });
      setAlertsTriggered(prev => ({ ...prev, fiveMin: true }));
      playAlertSound();
      setTimeout(() => setTimeAlert(null), 5000);
    } else if (timeLeft === 60 && !alertsTriggered.oneMin) {
      setTimeAlert({ message: 'Critical: Only 1 Minute Remaining!', color: 'bg-rose-600' });
      setAlertsTriggered(prev => ({ ...prev, oneMin: true }));
      playAlertSound();
      setTimeout(() => setTimeAlert(null), 5000);
    }

    const timer = setInterval(() => {
      setTimeLeft(prev => prev - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft, isSubmitting, showInstructions, alertsTriggered]);

  if (!exam || !currentUser) return <div>Loading...</div>;

  const currentQuestion = exam.questions[currentQuestionIndex];

  const handleSelectOption = (questionId: string, optionIndex: number) => {
    setAnswers(prev => ({
      ...prev,
      [questionId]: optionIndex
    }));
  };

  const handleSubmit = () => {
    setIsSubmitting(true);
    let correctMarks = 0;
    let wrongPenalty = 0;
    let correctCount = 0;
    let wrongCount = 0;
    
    exam.questions.forEach(q => {
      const qMarks = q.marks ?? 1;
      if (answers[q.id] !== undefined) {
        if (answers[q.id] === q.correctOptionIndex) {
          correctMarks += qMarks;
          correctCount += 1;
        } else {
          wrongCount += 1;
          if (exam.hasNegativeMarking && exam.negativeMarksPerWrongAnswer) {
            wrongPenalty += exam.negativeMarksPerWrongAnswer;
          }
        }
      }
    });

    const total = exam.questions.length;
    const score = Number(Math.max(0, correctMarks - wrongPenalty).toFixed(2));
    const timeTaken = (exam.durationMinutes * 60) - timeLeft;
    
    const isLiveNow = Date.now() <= exam.endTime;
    const result = {
      examId: exam.id,
      userId: currentUser.id,
      score: score,
      totalQuestions: total,
      correctAnswers: correctCount,
      wrongAnswers: wrongCount, 
      accuracy: total > 0 ? (correctCount / total) * 100 : 0,
      answers,
      timeTakenSeconds: timeTaken,
      tabCorrectionCount,
      attemptType: isLiveNow ? ('live' as const) : ('practice' as const)
    };

    submitExamOption(result);
    navigate(`/student/result/${exam.id}`);
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const allAnswered = Object.keys(answers).length === exam.questions.length;

  if (exam.questions.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4">
        <AlertCircle className="h-12 w-12 text-gray-400 mb-4" />
        <h2 className="text-xl font-bold text-gray-900 mb-2">No Questions Available</h2>
        <p className="text-gray-500 mb-6 text-center">This exam hasn't been set up properly yet.</p>
        <button onClick={() => navigate('/student')} className="bg-indigo-600 text-white px-6 py-2 rounded-lg">
          Go Back
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 md:bg-gray-100 relative select-none">
      {/* Warning Toast */}
      {warningMessage && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-rose-500 text-white px-6 py-3 rounded-xl shadow-lg font-bold flex items-center gap-3 animate-slideDown">
          <AlertCircle className="w-5 h-5" />
          {warningMessage}
        </div>
      )}

      {/* Time Alert Overlay */}
      {timeAlert && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-6 bg-black/20 backdrop-blur-[2px] pointer-events-none">
          <div className={cn(
            "px-10 py-8 rounded-[32px] text-white shadow-2xl flex flex-col items-center gap-4 animate-bounce-short",
            timeAlert.color
          )}>
            <Clock className="w-16 h-16 animate-pulse" />
            <h2 className="text-3xl font-black text-center tracking-tight leading-tight">
              {timeAlert.message}
            </h2>
          </div>
        </div>
      )}

      {/* Top Bar timer */}
      <div className="h-16 bg-white px-6 shadow-sm border-b border-slate-200 flex items-center justify-between sticky top-0 z-10">
        <div className="font-bold font-display text-slate-900 truncate pr-4 text-xl">{exam.title}</div>
        <div className={cn(
          "flex items-center gap-2 font-mono font-bold text-lg px-3 py-1.5 bg-slate-100 rounded-xl transition-all duration-300",
          timeLeft < 300 && "bg-amber-50 text-amber-600 animate-pulse ring-2 ring-amber-500/20",
          timeLeft < 60 && "bg-rose-50 text-rose-600 ring-rose-500/30 font-black",
          timeLeft < 30 && "animate-[pulse_0.5s_infinite]"
        )}>
          <Clock className="w-5 h-5 flex-shrink-0" />
          {formatTime(timeLeft)}
        </div>
      </div>

      {showInstructions && (
        <ExamInstructionsModal
          exam={exam}
          onStart={() => setShowInstructions(false)}
        />
      )}

      <div className="flex-1 max-w-3xl w-full mx-auto md:p-8 flex flex-col">
        {/* Question Area */}
        <div className="bg-white flex-1 md:flex-none md:rounded-3xl shadow-sm border-x border-b md:border border-slate-200 p-6 sm:p-10 flex flex-col">
          <div className="flex items-center justify-between mb-8 text-[11px] font-bold uppercase tracking-widest text-slate-400">
            <span>Question {currentQuestionIndex + 1} of {exam.questions.length}</span>
            {answers[currentQuestion.id] !== undefined && (
              <span className="flex items-center text-emerald-600 bg-emerald-50 px-2 py-1 rounded">
                <CheckCircle2 className="w-3.5 h-3.5 mr-1" /> Answered
              </span>
            )}
          </div>

          <h3 className="text-xl sm:text-2xl font-bold text-slate-900 mb-10 leading-snug">
            {currentQuestion.text}
          </h3>

          <div className="space-y-4 mt-auto md:mt-0">
            {currentQuestion.options.map((option, idx) => {
              const isSelected = answers[currentQuestion.id] === idx;
              return (
                <button
                  key={idx}
                  onClick={() => handleSelectOption(currentQuestion.id, idx)}
                  className={cn(
                    "w-full text-left p-5 rounded-2xl border-2 transition-all flex items-center group",
                    isSelected 
                      ? "border-indigo-600 bg-indigo-50 shadow-sm" 
                      : "border-slate-200 hover:border-indigo-300 hover:bg-slate-50"
                  )}
                >
                  <div className={cn(
                    "w-6 h-6 rounded-full border-2 mr-4 flex items-center justify-center transition-colors",
                    isSelected ? "border-indigo-600" : "border-slate-300 group-hover:border-indigo-400"
                  )}>
                    {isSelected && <div className="w-3 h-3 rounded-full bg-indigo-600" />}
                  </div>
                  <span className={cn(
                    "text-lg",
                    isSelected ? "text-indigo-900 font-bold" : "text-slate-700 font-medium"
                  )}>
                    {banglaLabels[idx]}) {option}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Navigation bottom bar */}
        <div className="mt-4 md:mt-8 bg-white md:rounded-2xl p-4 shadow-sm border-y md:border border-slate-200 flex items-center justify-between">
          <button
            onClick={() => setCurrentQuestionIndex(Math.max(0, currentQuestionIndex - 1))}
            disabled={currentQuestionIndex === 0}
            className="flex items-center gap-2 px-5 py-2.5 text-slate-600 disabled:opacity-50 hover:bg-slate-100 rounded-xl transition-colors font-bold text-sm"
          >
            <ArrowLeft className="w-4 h-4" /> Previous
          </button>
          
          <div className="hidden sm:flex items-center gap-1.5 overflow-x-auto px-4">
            {exam.questions.map((q, idx) => (
              <button
                key={q.id}
                onClick={() => setCurrentQuestionIndex(idx)}
                className={cn(
                  "w-10 h-10 rounded-xl flex items-center justify-center text-sm font-bold transition-colors",
                  currentQuestionIndex === idx ? "ring-2 ring-indigo-600 ring-offset-2" : "",
                  answers[q.id] !== undefined ? "bg-indigo-100 text-indigo-700" : "bg-rose-100 text-rose-600 hover:bg-rose-200"
                )}
              >
                {idx + 1}
              </button>
            ))}
          </div>

          {currentQuestionIndex === exam.questions.length - 1 ? (
            <button
              onClick={() => setShowSubmitModal(true)}
              className={cn(
                "flex items-center gap-2 px-8 py-2.5 rounded-xl font-bold transition-colors text-white text-sm shadow-md",
                allAnswered ? "bg-emerald-600 hover:bg-emerald-700 shadow-emerald-500/20" : "bg-indigo-600 hover:bg-indigo-700 shadow-indigo-500/20"
              )}
            >
              Submit 
              {!allAnswered && <span className="text-[10px] font-bold opacity-80 uppercase tracking-widest">({Object.keys(answers).length}/{exam.questions.length})</span>}
            </button>
          ) : (
            <button
              onClick={() => setCurrentQuestionIndex(Math.min(exam.questions.length - 1, currentQuestionIndex + 1))}
              className="flex items-center gap-2 px-5 py-2.5 bg-indigo-50 text-indigo-700 hover:bg-indigo-100 rounded-xl transition-colors font-bold text-sm"
            >
              Next <ArrowRight className="w-4 h-4" />
            </button>
          )}
        </div>
        <SubmitConfirmationModal
          isOpen={showSubmitModal}
          total={exam.questions.length}
          answered={Object.keys(answers).length}
          unanswered={exam.questions.length - Object.keys(answers).length}
          markedForReview={0}
          onCancel={() => setShowSubmitModal(false)}
          onConfirm={() => { setShowSubmitModal(false); handleSubmit(); }}
        />
      </div>
    </div>
  );
}
