import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useStore } from '../../store/useStore';
import { Trophy, CheckCircle, XCircle, Target, ArrowLeft, Home, Clock, AlertTriangle } from 'lucide-react';

export default function ResultView() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { exams, results, currentUser, users } = useStore();
  
  const exam = exams.find(e => e.id === id);
  // Get latest result for this exam & user
  const result = results.filter(r => r.examId === id && r.userId === currentUser?.id).pop();

  if (!exam || !result) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4">
        <h2 className="text-xl font-bold text-gray-900 mb-2 font-display">Result not found</h2>
        <button onClick={() => navigate('/student')} className="text-indigo-600 font-semibold text-sm">Go back to Dashboard</button>
      </div>
    );
  }

  // Auto Release & Processing Gate logic
  const isLiveWindow = Date.now() <= exam.endTime;
  const isPendingPublish = isLiveWindow && result.attemptType !== 'practice' && exam.publishType === 'manual' && exam.resultsPublished === false;

  const formatSeconds = (totalSeconds?: number) => {
    if (totalSeconds === undefined) return '-';
    const m = Math.floor(totalSeconds / 60);
    const s = totalSeconds % 60;
    return `${m}m ${s}s`;
  };

  // Safe checks & sorting for Leaderboards
  // Filter for live rankings (practice results do not compile to leaderboards)
  const examResults = results.filter(r => r.examId === exam.id && r.attemptType !== 'practice');
  
  // Associating user profiles
  const rankList = examResults.map(res => {
    const user = users.find(u => u.id === res.userId);
    return {
      ...res,
      userName: user ? user.name : 'Unknown Student',
      userEmail: user ? user.email : '',
    };
  });

  // Dynamic ranking priority:
  // 1. Highest Score
  // 2. Lowest Completion Time
  // 3. Earliest Submission Timestamp
  rankList.sort((a, b) => {
    if (b.score !== a.score) {
      return b.score - a.score;
    }
    const timeA = a.timeTakenSeconds ?? 999999;
    const timeB = b.timeTakenSeconds ?? 999999;
    if (timeA !== timeB) {
      return timeA - timeB;
    }
    return a.submittedAt - b.submittedAt;
  });

  const myRankIndex = rankList.findIndex(r => r.userId === currentUser?.id);
  const myRank = myRankIndex !== -1 ? myRankIndex + 1 : '-';

  if (isPendingPublish) {
    return (
      <div className="min-h-screen bg-slate-50 p-4 sm:p-8 flex flex-col items-center justify-center">
        <div className="w-full max-w-md bg-white rounded-3xl shadow-xl shadow-slate-200/50 border border-slate-200 overflow-hidden text-center p-8 sm:p-10">
          <div className="w-16 h-16 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center mx-auto mb-6 ring-8 ring-indigo-50">
            <Clock className="w-8 h-8 animate-pulse" />
          </div>
          <h1 className="text-2xl font-black text-slate-900 mb-3 tracking-tight font-display">Result Processing...</h1>
          <p className="text-xs font-semibold text-indigo-600 mb-4 uppercase tracking-widest bg-indigo-50 py-1.5 px-3 rounded-lg w-fit mx-auto">ফলাফল প্রক্রিয়াকরণ চলছে</p>
          <p className="text-slate-500 text-sm leading-relaxed mb-6 font-medium">
            This live exam uses a manual results release procedure. The supervisor is currently reviewing other submissions and checking anti-cheat logs.
            <br/><br/>
            Your answers have been securely saved. Your score, correct breakdown, and leaderboard ranks will be instantly made public once published.
          </p>
          <button 
            onClick={() => navigate('/student')}
            className="w-full bg-indigo-600 hover:bg-indigo-750 text-white font-bold py-3 px-6 rounded-xl transition-colors shadow-lg shadow-indigo-200 text-xs uppercase tracking-wider"
          >
            Back to Dashboard
          </button>
        </div>
      </div>
    );
  }

  const isPass = result.accuracy >= 40; // 40% pass mark

  return (
    <div className="min-h-screen bg-slate-50 p-4 sm:p-8 flex flex-col items-center pb-24">
      <div className="w-full max-w-2xl bg-white rounded-3xl shadow-xl shadow-slate-200/50 border border-slate-200 overflow-hidden mt-4">
        {/* Top Banner */}
        <div className={`p-8 sm:p-12 text-center text-white relative overflow-hidden ${isPass ? 'bg-gradient-to-r from-emerald-500 to-emerald-600' : 'bg-gradient-to-r from-rose-500 to-rose-600'}`}>
          <div className="absolute -right-12 -top-12 w-64 h-64 bg-white/10 rounded-full blur-3xl pointer-events-none"></div>
          <div className="relative z-10 flex justify-center mb-6">
            <div className="bg-white/20 p-5 rounded-2xl backdrop-blur-md border border-white/20 shadow-inner">
              <Trophy className="w-12 h-12 text-white" />
            </div>
          </div>
          <h1 className="relative z-10 text-4xl sm:text-5xl font-display font-black mb-2 tracking-tight">
            {isPass ? 'Pass / Successful!' : 'Needs Improvement'}
          </h1>
          <p className="relative z-10 text-white/90 font-medium text-sm">Completed: {exam.title}</p>
          {result.attemptType === 'practice' ? (
            <span className="relative z-10 inline-block mt-3 px-3 py-1 bg-amber-500/30 text-white text-[10px] font-black uppercase tracking-widest rounded-full">
              Practice Attempt
            </span>
          ) : (
            <span className="relative z-10 inline-block mt-3 px-3 py-1 bg-indigo-500/30 text-white text-[10px] font-black uppercase tracking-widest rounded-full">
              Live Mock Score
            </span>
          )}
        </div>

        {/* Stats Grid */}
        <div className="p-8 sm:p-10 space-y-6">
          <div className="grid grid-cols-2 gap-4 sm:gap-6">
            <div className="bg-slate-50 p-6 rounded-2xl flex flex-col items-center justify-center text-center border border-slate-100 sm:col-span-2">
              <span className="text-[10px] uppercase tracking-widest font-bold text-slate-400 mb-2 flex items-center gap-1.5">
                <Target className="w-3.5 h-3.5" /> Total Achieved Score
              </span>
              <span className="text-4xl font-black text-slate-900">
                {Number.isInteger(result.score) ? result.score : result.score.toFixed(2)} 
                <span className="text-xl text-slate-400 font-bold">
                  / {exam.questions.reduce((acc, q) => acc + (q.marks ?? 1), 0)} pts
                </span>
              </span>
              {exam.hasNegativeMarking && result.wrongAnswers > 0 && (
                <div className="mt-3 text-[10px] font-bold text-rose-500 bg-rose-50 px-3 py-1 rounded-lg">
                  -{result.wrongAnswers * (exam.negativeMarksPerWrongAnswer || 0)} penalty points deducted
                </div>
              )}
            </div>
            
            <div className="bg-slate-50 p-6 rounded-2xl flex flex-col items-center justify-center text-center border border-slate-100">
              <span className="text-[10px] uppercase tracking-widest font-bold text-slate-400 mb-2">Accuracy %</span>
              <span className="text-3xl font-black text-slate-900">
                {Math.round(result.accuracy)}%
              </span>
            </div>

            <div className="bg-slate-50 p-6 rounded-2xl flex flex-col items-center justify-center text-center border border-slate-100">
              <span className="text-[10px] uppercase tracking-widest font-bold text-slate-400 mb-2">Time Taken</span>
              <span className="text-3xl font-black text-slate-900">
                {formatSeconds(result.timeTakenSeconds)}
              </span>
            </div>
            
            <div className="bg-emerald-55/10 p-6 rounded-2xl flex flex-col items-center justify-center text-center border border-emerald-100/50">
              <span className="text-[10px] uppercase tracking-widest font-bold text-emerald-600 mb-2 flex items-center gap-1.5">
                <CheckCircle className="w-3.5 h-3.5" /> Correct Answered
              </span>
              <span className="text-3xl font-black text-emerald-600">
                {result.correctAnswers} / {result.totalQuestions}
              </span>
            </div>
            
            <div className="bg-rose-55/10 p-6 rounded-2xl flex flex-col items-center justify-center text-center border border-rose-100/50">
              <span className="text-[10px] uppercase tracking-widest font-bold text-rose-600 mb-2 flex items-center gap-1.5">
                <XCircle className="w-3.5 h-3.5" /> Incorrect Count
              </span>
              <span className="text-3xl font-black text-rose-600">
                {result.wrongAnswers}
              </span>
            </div>
          </div>

          {/* Anti-Cheat Activity Alerts */}
          {result.tabCorrectionCount && result.tabCorrectionCount > 0 ? (
            <div className="bg-amber-50 text-amber-800 p-4 rounded-2xl border border-amber-200 text-xs font-semibold leading-relaxed flex items-start gap-2.5">
               <AlertTriangle className="w-4.5 h-4.5 text-amber-600 flex-shrink-0 mt-0.5" />
               <span>Warning: You triggered a window defocus (switched tabs / minimized window) <strong>{result.tabCorrectionCount} times</strong> mid-exam. This session has been flagged for audit review.</span>
            </div>
          ) : null}

          {/* Leaderboard Position Badge */}
          {exam.examType !== 'practice' && (
            <div className="bg-gradient-to-r from-indigo-50 to-indigo-100/50 p-5 rounded-2xl border border-indigo-100 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-indigo-600 font-bold uppercase tracking-widest">Scoreboard Rank</span>
                <h4 className="text-sm font-semibold text-slate-700 mt-1">Global Standing Position</h4>
              </div>
              <div className="text-right">
                <span className="text-3xl font-black text-indigo-700">Rank #{myRank}</span>
                <p className="text-[10px] text-slate-400 font-bold mt-0.5">{rankList.length} total participants</p>
              </div>
            </div>
          )}

          {/* Core Controls */}
          <div className="flex flex-col sm:flex-row gap-4 pt-4">
            <button 
              onClick={() => navigate('/student')}
              className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-3.5 rounded-xl transition-colors flex items-center justify-center gap-2"
            >
              <ArrowLeft className="w-5 h-5" /> Back to Student Panel
            </button>
            <button 
              onClick={() => navigate('/student')} 
              className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3.5 rounded-xl transition-colors flex items-center justify-center gap-2 shadow-lg shadow-indigo-200"
            >
              <Home className="w-5 h-5" /> Back to Home
            </button>
          </div>
        </div>

        {/* Dynamic Leaderboard for Live Exams */}
        {exam.examType !== 'practice' && (
          <div className="border-t border-slate-100 bg-slate-50/20 p-8 sm:p-10">
            <div className="flex items-center gap-2 mb-6">
              <Trophy className="w-5 h-5 text-indigo-600" />
              <h3 className="text-lg font-bold text-slate-800 tracking-tight font-display">Automatic Score Leaderboard</h3>
            </div>
            
            <div className="space-y-3.5 max-h-96 overflow-y-auto pr-2">
              {rankList.map((res, i) => {
                const isMe = res.userId === currentUser?.id;
                const rNum = i + 1;
                return (
                  <div 
                    key={res.id} 
                    className={`flex items-center justify-between p-4 rounded-2xl border transition-all ${isMe ? 'bg-indigo-50/80 border-indigo-200 ring-2 ring-indigo-500/10' : 'bg-white border-slate-200 shadow-sm'}`}
                  >
                    <div className="flex items-center gap-3">
                      <span className={`w-8 h-8 rounded-full flex items-center justify-center font-black text-xs ${rNum === 1 ? 'bg-amber-100 text-amber-700' : rNum === 2 ? 'bg-slate-200 text-slate-700' : rNum === 3 ? 'bg-amber-50 text-amber-600 font-bold' : 'text-slate-400'}`}>
                        #{rNum}
                      </span>
                      <div>
                        <div className={`text-sm font-extrabold ${isMe ? 'text-indigo-900' : 'text-slate-800'}`}>
                          {res.userName} {isMe && <span className="text-[9px] bg-indigo-600 text-white px-2 py-0.5 rounded ml-1.5 font-black uppercase">YOU</span>}
                        </div>
                        <div className="text-[10px] font-bold text-slate-400 mt-0.5 uppercase tracking-wider flex items-center gap-1.5">
                          <span>{formatSeconds(res.timeTakenSeconds)} taken</span>
                          <span>•</span>
                          <span>{res.correctAnswers} Correct</span>
                          {res.tabCorrectionCount && res.tabCorrectionCount > 0 ? (
                            <>
                              <span>•</span>
                              <span className="text-rose-500">Defocus x{res.tabCorrectionCount}</span>
                            </>
                          ) : null}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-base font-black text-slate-900">{res.score} pts</div>
                      <div className="text-[9px] text-slate-400 font-bold mt-0.5 uppercase tracking-widest">{new Date(res.submittedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Detailed Answer Key & Correction Reviews */}
        <div className="p-8 sm:p-10 border-t border-slate-250 bg-slate-50/50">
          <h3 className="text-lg font-bold text-slate-800 mb-6 flex items-center gap-2 font-display">
            <CheckCircle className="w-5 h-5 text-emerald-500" /> Exam Question Review
          </h3>
          <div className="space-y-6">
            {exam.questions.map((q, qIdx) => {
              const myAnswer = result.answers[q.id];
              const isCorrect = myAnswer === q.correctOptionIndex;
              const hasAnswered = myAnswer !== undefined;
              const qMarks = q.marks ?? 1;

              return (
                <div key={q.id} className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-sm relative overflow-hidden">
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest">Q{qIdx + 1} • {qMarks} Mark{qMarks > 1 ? 's' : ''}</span>
                    {hasAnswered ? (
                      isCorrect ? (
                        <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 border border-emerald-150 px-2.5 py-1 rounded-full flex items-center gap-1 uppercase tracking-wide">
                          <CheckCircle className="w-3.5 h-3.5" /> Correct
                        </span>
                      ) : (
                        <span className="text-[10px] font-bold text-rose-600 bg-rose-50 border border-rose-150 px-2.5 py-1 rounded-full flex items-center gap-1 uppercase tracking-wide">
                          <XCircle className="w-3.5 h-3.5" /> Incorrect
                        </span>
                      )
                    ) : (
                      <span className="text-[10px] font-bold text-amber-600 bg-amber-50 border border-amber-150 px-2.5 py-1 rounded-full uppercase tracking-wide">
                        Unanswered
                      </span>
                    )}
                  </div>
                  
                  <p className="text-base font-bold text-slate-800 mb-4">{q.text}</p>
                  
                  <div className="space-y-2.5">
                    {q.options.map((opt, oIdx) => {
                      const isSelected = myAnswer === oIdx;
                      const isCorrectOption = q.correctOptionIndex === oIdx;
                      
                      let optStyle = "border-slate-200 text-slate-700 bg-slate-50";
                      if (isSelected) {
                        optStyle = isCorrectOption 
                          ? "border-emerald-500 bg-emerald-50 text-emerald-900 font-bold" 
                          : "border-rose-500 bg-rose-50 text-rose-900 font-bold";
                      } else if (isCorrectOption) {
                        optStyle = "border-emerald-300 bg-emerald-50/50 text-emerald-800 font-semibold";
                      }
                      
                      return (
                        <div key={oIdx} className={`px-4 py-2.5 rounded-xl border text-sm flex items-center justify-between ${optStyle}`}>
                          <span>{opt}</span>
                          <span className="text-[9px] font-bold uppercase tracking-widest opacity-80">
                            {isCorrectOption ? "Correct Option" : isSelected ? "Your Option" : ""}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                  
                  {/* Analysis analysis */}
                  <div className="mt-4 pt-3.5 border-t border-slate-100 text-xs text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-xl border border-dashed border-slate-200">
                    <span className="font-extrabold text-indigo-600 uppercase tracking-widest text-[9px] block mb-1">Answer Analysis:</span>
                    Index {q.correctOptionIndex + 1} is verified as the mathematically/conceptually correct solution for this problem.
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
