import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../../store/useStore';
import { ArrowLeft, Edit2, Check, Download, Camera, Loader2, Save } from 'lucide-react';

import html2pdf from 'html2pdf.js';

import NotificationCenter from '../../components/NotificationCenter';

export default function StudentProfile() {
  const navigate = useNavigate();
  const { currentUser, updateProfile } = useStore();
  const [isEditing, setIsEditing] = useState<string | null>(null);
  const [formData, setFormData] = useState<any>({ ...currentUser?.profile, name: currentUser?.name });
  
  const [isSaving, setIsSaving] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);

  if (!currentUser) return null;

  const handleDownload = async () => {
    setIsDownloading(true);
    const element = document.getElementById('cv-template');
    if (!element) {
      setIsDownloading(false);
      return;
    }
    
    // Make sure the element is physically reachable by html2canvas
    const originalStyle = element.getAttribute('style');
    element.style.display = 'block';
    element.style.position = 'fixed';
    element.style.left = '0';
    element.style.top = '0';
    element.style.zIndex = '-9999';

    // Wait for the browser to render the DOM changes
    await new Promise(resolve => setTimeout(resolve, 150));

    const opt = {
      margin:       0.5,
      filename:     'student-profile.pdf',
      image:        { type: 'jpeg' as const, quality: 0.98 },
      html2canvas:  { scale: 2, useCORS: true, logging: false },
      jsPDF:        { unit: 'in', format: 'a4', orientation: 'portrait' as const }
    };

    try {
      await html2pdf().set(opt).from(element).save();
    } finally {
      if (originalStyle) {
        element.setAttribute('style', originalStyle);
      } else {
        element.style.display = 'none';
      }
      setIsDownloading(false);
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    // Simulate API delay
    await new Promise(r => setTimeout(r, 500));
    updateProfile(currentUser.id, formData);
    setIsSaving(false);
    setIsEditing(null);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, photoUrl: reader.result as string }));
        setIsEditing('photo');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleChange = (field: string, value: string) => {
    // Handle nested fields like presentAddress.division
    if (field.includes('.')) {
      const [parent, child] = field.split('.');
      setFormData((prev: any) => ({
        ...prev,
        [parent]: {
          ...(prev[parent] || {}),
          [child]: value
        }
      }));
    } else {
      setFormData((prev: any) => ({ ...prev, [field]: value }));
    }
  };

  const renderField = (label: string, field: string, type = 'text', section: string) => {
    const isCurrentFieldEditing = isEditing === section;
    const value = field.includes('.') 
      ? formData[field.split('.')[0]]?.[field.split('.')[1]] 
      : formData[field] || (field === 'name' ? currentUser.name : field === 'email' ? currentUser.email : '');
      
    const isReadOnly = field === 'email';

    return (
      <div className="bg-[#1f2937] p-4 rounded-xl border border-slate-700/50 mb-3 group relative">
        <label className="block text-[11px] font-bold text-slate-400 mb-1">{label}</label>
        {isCurrentFieldEditing && !isReadOnly ? (
          <input 
            type={type}
            value={value || ''}
            onChange={(e) => handleChange(field, e.target.value)}
            className="w-full bg-slate-800 text-slate-100 rounded-lg px-3 py-2 outline-none focus:ring-1 focus:ring-indigo-500 border border-slate-700"
            placeholder={`Enter ${label}`}
          />
        ) : (
          <div className="text-sm font-medium text-slate-200">
            {value || '-'}
          </div>
        )}
        {!isCurrentFieldEditing && !isReadOnly && (
          <button 
            type="button"
            onClick={() => setIsEditing(section)}
            className="absolute top-4 right-4 text-slate-500 opacity-50 group-hover:opacity-100 transition-opacity hover:text-white"
          >
            <Edit2 className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
    );
  };

  const renderSectionHeader = (title: string, sectionKey: string) => (
    <div className="flex items-center justify-between mb-4 mt-8">
      <h3 className="text-lg font-bold text-white tracking-tight">{title}</h3>
      {isEditing === sectionKey ? (
        <div className="flex items-center gap-2">
          <button 
             onClick={() => {
               setFormData({ ...currentUser?.profile, name: currentUser?.name });
               setIsEditing(null);
             }}
             className="px-3 py-1.5 text-xs font-bold text-slate-400 hover:text-white hover:bg-slate-700 rounded-lg transition-colors"
          >
             Cancel
          </button>
          <button 
             onClick={handleSave}
             disabled={isSaving}
             className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors shadow-lg shadow-indigo-500/20"
          >
             {isSaving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
             Save
          </button>
        </div>
      ) : (
        <button 
          onClick={() => setIsEditing(sectionKey)}
          className="text-xs font-bold text-indigo-400 hover:text-indigo-300 uppercase tracking-widest"
        >
          Edit
        </button>
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-[#0f172a] text-slate-200 pb-20">
      {/* Header */}
      <header className="h-16 border-b border-slate-800 px-4 sm:px-8 flex items-center justify-between sticky top-0 bg-[#0f172a]/80 backdrop-blur-md z-20">
         <div className="flex items-center gap-4">
           <button 
             onClick={() => navigate('/student')}
             className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
           >
             <ArrowLeft className="w-5 h-5" />
           </button>
           <div className="flex items-center gap-2">
             <img 
               src="https://i.postimg.cc/h40vHdRJ/IMG-20260217-WA0010.jpg" 
               alt="OTS Logo" 
               referrerPolicy="no-referrer"
               className="w-7 h-7 object-cover rounded-lg border border-slate-700 shadow-sm"
             />
             <h1 className="text-sm font-black text-white font-display uppercase tracking-wider">OTS Profile</h1>
           </div>
         </div>
         <div className="flex items-center gap-4">
           <NotificationCenter />
           <button 
             onClick={handleDownload}
             disabled={isDownloading}
             className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2 rounded-lg text-xs font-bold transition-colors disabled:opacity-70"
           >
              {isDownloading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
              <span className="hidden sm:inline">{isDownloading ? 'Generating...' : 'Download Profile'}</span>
           </button>
         </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 py-8">
         {/* Profile Picture */}
         <div className="flex flex-col items-center mb-10 relative">
            <div className="w-28 h-28 rounded-full border-4 border-slate-800 bg-slate-800 overflow-hidden relative group">
               {formData.photoUrl ? (
                 <img src={formData.photoUrl} alt="Profile" className="w-full h-full object-cover" />
               ) : (
                 <div className="w-full h-full flex items-center justify-center text-slate-500">
                    <Camera className="w-8 h-8 opacity-50" />
                 </div>
               )}
               
               <label className="absolute inset-0 bg-black/50 flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer">
                  <Camera className="w-6 h-6 text-white mb-1" />
                  <span className="text-[10px] font-bold text-white">Upload</span>
                  <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
               </label>
            </div>
            
            {isEditing === 'photo' && (
              <div className="mt-4 flex gap-2">
                <button 
                  onClick={() => {
                    setFormData({ ...currentUser?.profile, name: currentUser?.name });
                    setIsEditing(null);
                  }}
                  className="px-4 py-2 text-xs font-bold text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors border border-slate-700"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleSave}
                  disabled={isSaving}
                  className="flex items-center gap-2 px-6 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors shadow-lg shadow-indigo-500/20"
                >
                  {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                  Save Photo
                </button>
              </div>
            )}
            
            <h2 className="text-2xl font-bold font-display text-white mt-4">{currentUser.name}</h2>
            <div className="text-xs font-bold uppercase tracking-[0.2em] text-indigo-400 mt-1">STUDENT</div>
         </div>

         {/* Sections */}
         <div className="space-y-6">
            
            {/* Login Information */}
            <section>
              {renderSectionHeader("Login Information", "login")}
              {renderField("Email", "email", "email", "login")}
              {renderField("Mobile", "mobile", "tel", "login")}
              {renderField("Emergency Contact", "emergencyContact", "tel", "login")}
            </section>

            {/* Personal Information */}
            <section>
              {renderSectionHeader("Personal Information", "personal")}
              {renderField("Name", "name", "text", "personal")}
              {renderField("Date of Birth", "dateOfBirth", "date", "personal")}
              {renderField("Religion", "religion", "text", "personal")}
              {renderField("Gender", "gender", "text", "personal")}
              {renderField("Blood Group", "bloodGroup", "text", "personal")}
              {renderField("Group", "group", "text", "personal")}
            </section>

            {/* College Information */}
            <section>
              {renderSectionHeader("College Information", "college")}
              {renderField("College Name", "collegeName", "text", "college")}
              {renderField("College Address", "collegeAddress", "text", "college")}
              {renderField("College Session", "collegeSession", "text", "college")}
              {renderField("University Chance", "universityChance", "text", "college")}
            </section>

            {/* Father's Information */}
            <section>
              {renderSectionHeader("Father's Information", "father")}
              {renderField("Father's Name", "fatherName", "text", "father")}
              {renderField("NID", "fatherNid", "text", "father")}
              {renderField("Profession", "fatherProfession", "text", "father")}
              {renderField("Profession Type", "fatherProfessionType", "text", "father")}
              {renderField("Yearly Income", "fatherYearlyIncome", "text", "father")}
            </section>

            {/* Mother's Information */}
            <section>
              {renderSectionHeader("Mother's Information", "mother")}
              {renderField("Mother's Name", "motherName", "text", "mother")}
              {renderField("NID", "motherNid", "text", "mother")}
              {renderField("Profession", "motherProfession", "text", "mother")}
              {renderField("Profession Type", "motherProfessionType", "text", "mother")}
              {renderField("Yearly Income", "motherYearlyIncome", "text", "mother")}
            </section>

            {/* Additional Information */}
            <section>
              {renderSectionHeader("Additional Information", "additional")}
              {renderField("Previous School Name", "previousSchoolName", "text", "additional")}
              {renderField("Disability", "disability", "text", "additional")}
              {renderField("Guardian Mobile", "guardianMobile", "tel", "additional")}
            </section>

            <hr className="border-slate-800 my-8" />
            
            {/* Present Address */}
            <section>
              {renderSectionHeader("Present Address", "presentAddress")}
              <div className="grid grid-cols-2 gap-3">
                {renderField("Division", "presentAddress.division", "text", "presentAddress")}
                {renderField("District", "presentAddress.district", "text", "presentAddress")}
                {renderField("Upazila", "presentAddress.upazila", "text", "presentAddress")}
                {renderField("Union", "presentAddress.union", "text", "presentAddress")}
                {renderField("Post Office", "presentAddress.postOffice", "text", "presentAddress")}
                {renderField("Village", "presentAddress.village", "text", "presentAddress")}
                {renderField("House", "presentAddress.house", "text", "presentAddress")}
              </div>
            </section>

            {/* Permanent Address */}
            <section>
              {renderSectionHeader("Permanent Address", "permanentAddress")}
              <div className="grid grid-cols-2 gap-3">
                {renderField("Division", "permanentAddress.division", "text", "permanentAddress")}
                {renderField("District", "permanentAddress.district", "text", "permanentAddress")}
                {renderField("Upazila", "permanentAddress.upazila", "text", "permanentAddress")}
                {renderField("Union", "permanentAddress.union", "text", "permanentAddress")}
                {renderField("Post Office", "permanentAddress.postOffice", "text", "permanentAddress")}
                {renderField("Village", "permanentAddress.village", "text", "permanentAddress")}
                {renderField("House", "permanentAddress.house", "text", "permanentAddress")}
              </div>
            </section>

            <hr className="border-slate-800 my-8" />

            {/* JSC Information */}
            <section>
              {renderSectionHeader("JSC Information", "jsc")}
              <div className="grid grid-cols-2 gap-3">
                 {renderField("Roll No", "jscInfo.rollNo", "text", "jsc")}
                 {renderField("Reg No", "jscInfo.regNo", "text", "jsc")}
                 {renderField("Board", "jscInfo.board", "text", "jsc")}
                 {renderField("GPA", "jscInfo.gpa", "text", "jsc")}
                 {renderField("Year", "jscInfo.year", "text", "jsc")}
              </div>
            </section>

            {/* SSC Information */}
            <section>
              {renderSectionHeader("SSC Information", "ssc")}
              <div className="grid grid-cols-2 gap-3">
                 {renderField("Roll No", "sscInfo.rollNo", "text", "ssc")}
                 {renderField("Reg No", "sscInfo.regNo", "text", "ssc")}
                 {renderField("Board", "sscInfo.board", "text", "ssc")}
                 {renderField("GPA", "sscInfo.gpa", "text", "ssc")}
                 {renderField("Year", "sscInfo.year", "text", "ssc")}
              </div>
            </section>

            {/* HSC Information */}
            <section>
              {renderSectionHeader("HSC Information", "hsc")}
              <div className="grid grid-cols-2 gap-3">
                 {renderField("Roll No", "hscInfo.rollNo", "text", "hsc")}
                 {renderField("Reg No", "hscInfo.regNo", "text", "hsc")}
                 {renderField("Board", "hscInfo.board", "text", "hsc")}
                 {renderField("GPA", "hscInfo.gpa", "text", "hsc")}
                 {renderField("Year", "hscInfo.year", "text", "hsc")}
              </div>
            </section>

            {/* Notifications & Notices Section */}
            <hr className="border-slate-800 my-8" />
            
            <section className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold text-white tracking-tight">Recent Activity</h3>
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">History</span>
              </div>
              
              <div className="grid gap-4">
                 {useStore.getState().notifications.filter(n => n.userId === currentUser.id).length === 0 ? (
                   <div className="bg-slate-800/50 p-8 rounded-2xl border border-slate-700/50 text-center">
                     <p className="text-sm font-bold text-slate-500">No recent notifications</p>
                   </div>
                 ) : (
                   useStore.getState().notifications
                     .filter(n => n.userId === currentUser.id)
                     .slice(0, 10)
                     .map(notif => (
                       <div key={notif.id} className="bg-slate-800/40 p-4 rounded-xl border border-slate-700/50 flex items-start gap-3">
                         <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center flex-shrink-0">
                           <Loader2 className="w-4 h-4 text-indigo-400" />
                         </div>
                         <div>
                           <p className="text-sm font-black text-slate-200">{notif.title}</p>
                           <p className="text-xs text-slate-400 mt-0.5">{notif.message}</p>
                           <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mt-1.5">
                             {new Date(notif.createdAt).toLocaleDateString()} at {new Date(notif.createdAt).toLocaleTimeString()}
                           </p>
                         </div>
                       </div>
                     ))
                 )}
              </div>

              {/* Course Notices */}
              <div className="flex items-center justify-between mt-10">
                <h3 className="text-xl font-bold text-white tracking-tight">Course Notices</h3>
                <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest">Official</span>
              </div>

              <div className="grid gap-4">
                {useStore.getState().courses
                  .filter(c => currentUser.enrolledCourses?.includes(c.id))
                  .flatMap(c => (c.notices || []).map(n => ({ ...n, courseTitle: c.title })))
                  .sort((a, b) => b.createdAt - a.createdAt)
                  .length === 0 ? (
                    <div className="bg-slate-800/50 p-8 rounded-2xl border border-slate-700/50 text-center">
                      <p className="text-sm font-bold text-slate-500">No official notices from your courses</p>
                    </div>
                  ) : (
                    useStore.getState().courses
                      .filter(c => currentUser.enrolledCourses?.includes(c.id))
                      .flatMap(c => (c.notices || []).map(n => ({ ...n, courseTitle: c.title })))
                      .sort((a, b) => b.createdAt - a.createdAt)
                      .slice(0, 10)
                      .map(notice => (
                        <div key={notice.id} className="bg-indigo-900/20 p-5 rounded-2xl border border-indigo-500/20">
                          <div className="flex items-center justify-between mb-2">
                             <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">{notice.courseTitle}</span>
                             <span className="text-[9px] font-bold text-slate-500">{new Date(notice.createdAt).toDateString()}</span>
                          </div>
                          <h4 className="text-base font-black text-white leading-tight">{notice.title}</h4>
                          <p className="text-sm text-slate-400 mt-2 leading-relaxed">{notice.message}</p>
                        </div>
                      ))
                  )}
              </div>
            </section>

         </div>
      </main>

      {/* Hidden CV PDF Template */}
      <div 
        id="cv-template" 
        className="p-8 font-sans w-[800px] absolute"
        style={{ left: '-9999px', top: '-9999px', display: 'none', backgroundColor: '#ffffff', color: '#1e293b' }}
      >
        <div className="flex flex-col items-center mb-4">
          <img 
            src="https://i.postimg.cc/SKvbRKSk/Picsart-25-04-11-14-24-23-146.png" 
            alt="Logo" 
            className="w-40 mb-1" 
            crossOrigin="anonymous" 
          />
          <p className="text-[10px]" style={{ color: '#64748b' }}>Generated on: {new Date().toLocaleString()}</p>
        </div>
        
        <hr className="mb-6" style={{ borderColor: '#cbd5e1' }} />

        <div className="flex items-start gap-4 mb-8">
          {formData.photoUrl || currentUser.profile?.photoUrl ? (
            <img 
              src={formData.photoUrl || currentUser.profile?.photoUrl} 
              alt="Profile" 
              className="w-24 h-24 object-cover border" 
              style={{ borderColor: '#e2e8f0' }}
              crossOrigin="anonymous" 
            />
          ) : (
            <div className="w-24 h-24 flex items-center justify-center text-[10px] font-bold border" style={{ backgroundColor: '#f1f5f9', color: '#94a3b8', borderColor: '#e2e8f0' }}>
              No Photo
            </div>
          )}
          <div className="flex flex-col">
            <h1 className="text-xl font-bold tracking-tight" style={{ color: '#1e293b' }}>{currentUser.name}</h1>
            <p className="text-[11px] mt-1" style={{ color: '#475569' }}>Email: {currentUser.email}</p>
            <p className="text-[11px] mt-0.5" style={{ color: '#475569' }}>Phone: {formData.mobile || 'N/A'}</p>
            <p className="text-[11px] mt-0.5" style={{ color: '#475569' }}>Gender: {formData.gender || 'N/A'}</p>
            <p className="text-[11px] mt-0.5" style={{ color: '#475569' }}>Blood Group: {formData.bloodGroup || 'N/A'}</p>
          </div>
        </div>

        {/* PERSONAL INFORMATION */}
        <div className="mb-6 border-b pb-4" style={{ borderColor: '#e2e8f0' }}>
          <h2 className="text-[11px] font-bold uppercase border-b pb-1 mb-3 inline-block pr-6" style={{ color: '#1e293b', borderColor: '#1e293b' }}>Personal Information</h2>
          <div className="grid grid-cols-2 gap-y-2 text-[11px]">
             <div className="flex"><span className="font-bold w-24">Date of Birth:</span> <span style={{ color: '#475569' }}>{formData.dateOfBirth || 'N/A'}</span></div>
             <div className="flex"><span className="font-bold w-28">Religion:</span> <span style={{ color: '#475569' }}>{formData.religion || 'N/A'}</span></div>
             <div className="flex"><span className="font-bold w-24">Group:</span> <span style={{ color: '#475569' }}>{formData.group || 'N/A'}</span></div>
             <div className="flex"><span className="font-bold w-28">Emergency Contact:</span> <span style={{ color: '#475569' }}>{formData.emergencyContact || 'N/A'}</span></div>
             <div className="flex"><span className="font-bold w-24">Disability:</span> <span style={{ color: '#475569' }}>{formData.disability || 'No'}</span></div>
          </div>
        </div>

        {/* ACADEMIC INFORMATION */}
        <div className="mb-6 border-b pb-4" style={{ borderColor: '#e2e8f0' }}>
          <h2 className="text-[11px] font-bold uppercase border-b pb-1 mb-3 inline-block pr-6" style={{ color: '#1e293b', borderColor: '#1e293b' }}>Academic Information</h2>
          {formData.collegeName || formData.sscInfo?.rollNo || formData.hscInfo?.rollNo ? (
            <div className="text-[11px]" style={{ color: '#475569' }}>
               {formData.collegeName && <p><strong>College:</strong> {formData.collegeName} ({formData.collegeSession || ''})</p>}
               {formData.sscInfo?.rollNo && <p><strong>SSC:</strong> Roll {formData.sscInfo.rollNo}, {formData.sscInfo.board} Board ({formData.sscInfo.gpa})</p>}
               {formData.hscInfo?.rollNo && <p><strong>HSC:</strong> Roll {formData.hscInfo.rollNo}, {formData.hscInfo.board} Board ({formData.hscInfo.gpa})</p>}
            </div>
          ) : (
            <p className="text-[11px] font-medium" style={{ color: '#64748b' }}>No academic records available</p>
          )}
        </div>

        {/* UNIVERSITY INFORMATION */}
        <div className="mb-6 border-b pb-4" style={{ borderColor: '#e2e8f0' }}>
          <h2 className="text-[11px] font-bold uppercase border-b pb-1 mb-3 inline-block pr-6" style={{ color: '#1e293b', borderColor: '#1e293b' }}>University Information</h2>
          <div className="grid grid-cols-2 gap-y-2 text-[11px]">
             <div className="flex"><span className="font-bold w-24">Name:</span> <span style={{ color: '#475569' }}>{formData.universityChance || 'N/A'}</span></div>
             <div className="flex"><span className="font-bold w-24">Subject:</span> <span style={{ color: '#475569' }}>N/A</span></div>
             <div className="flex"><span className="font-bold w-24">Session:</span> <span style={{ color: '#475569' }}>N/A</span></div>
             <div className="flex"><span className="font-bold w-24">Position:</span> <span style={{ color: '#475569' }}>N/A</span></div>
             <div className="flex"><span className="font-bold w-24">Roll No:</span> <span style={{ color: '#475569' }}>N/A</span></div>
          </div>
        </div>

        {/* FAMILY INFORMATION */}
        <div className="mb-6 border-b pb-4" style={{ borderColor: '#e2e8f0' }}>
          <h2 className="text-[11px] font-bold uppercase border-b pb-1 mb-3 inline-block pr-6" style={{ color: '#1e293b', borderColor: '#1e293b' }}>Family Information</h2>
          <div className="grid grid-cols-2 gap-y-2 text-[11px]">
             <div className="flex"><span className="font-bold w-28">Father's Name:</span> <span style={{ color: '#475569' }}>{formData.fatherName || 'N/A'}</span></div>
             <div className="flex"><span className="font-bold w-28">Mother's Name:</span> <span style={{ color: '#475569' }}>{formData.motherName || 'N/A'}</span></div>
             <div className="flex"><span className="font-bold w-28">Guardian Mobile:</span> <span style={{ color: '#475569' }}>{formData.guardianMobile || 'N/A'}</span></div>
          </div>
        </div>

        <div className="mt-20 text-center text-[9px]" style={{ color: '#94a3b8' }}>
          This document has been digitally generated and authenticated. No physical signature is required.
        </div>
      </div>
    </div>
  );
}
