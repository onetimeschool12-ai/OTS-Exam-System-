import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../store/useStore';
import { BookOpen, GraduationCap, ArrowRight } from 'lucide-react';
import { cn } from '../lib/utils';

export default function Landing() {
  const navigate = useNavigate();
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  
  const [error, setError] = useState('');
  const { login, register, currentUser } = useStore();

  React.useEffect(() => {
    if (currentUser?.role === 'user') {
      navigate('/student');
    } else if (currentUser?.role === 'admin') {
      navigate('/admin');
    }
  }, [currentUser, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (isLogin) {
      // In this prototype, we simulate password validation by just logging in
      const result = await login(email, password, 'user');
      if (!result.success) {
        setError(result.message || 'Login failed');
      }
    } else {
      const result = await register(name, email, password);
      if (!result.success) {
        setError(result.message || 'Registration failed');
      }
    }
  };

  return (
    <div className="min-h-screen bg-white flex flex-col md:flex-row font-sans">
      {/* Visual Side */}
      <div className="hidden md:flex flex-1 bg-indigo-900 p-12 flex-col justify-between text-white relative overflow-hidden bg-grid-pattern">
        <div className="relative z-10">
          <div className="flex items-center gap-3 text-2xl font-display font-bold mb-12 tracking-tight text-white hover:opacity-95 transition-all">
            <img 
              src="https://i.postimg.cc/h40vHdRJ/IMG-20260217-WA0010.jpg" 
              alt="OTS Logo" 
              referrerPolicy="no-referrer"
              className="w-12 h-12 object-cover rounded-xl border-2 border-indigo-700 shadow-md"
            />
            <div className="flex flex-col">
              <span className="leading-none text-xl font-extrabold text-white">OTS EXAM BATCH</span>
              <span className="text-[9px] uppercase tracking-widest text-indigo-300 font-bold mt-1">Smart Learning Platform</span>
            </div>
          </div>
          <h1 className="text-5xl lg:text-6xl font-display font-bold leading-tight mb-6">
            Master your potential with smart online exams.
          </h1>
          <p className="text-indigo-200 text-lg max-w-md font-medium leading-relaxed">
            Join thousands of students competing in Class-wise exams, real-time analytics, and comprehensive leaderboards. Learning made measurable.
          </p>
        </div>
        
        {/* Abstract graphics */}
        <div className="absolute -bottom-32 -right-32 w-96 h-96 bg-indigo-600 rounded-full blur-3xl opacity-50 pointer-events-none" />
        <div className="absolute top-20 right-20 w-64 h-64 bg-indigo-500 rounded-full blur-3xl opacity-20 pointer-events-none" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-grid-pattern opacity-20 pointer-events-none mix-blend-overlay"></div>
      </div>

      {/* Auth Side */}
      <div className="flex-1 flex flex-col items-center justify-center p-8 bg-slate-50 relative">
        <div className="absolute inset-0 bg-grid-pattern opacity-50 pointer-events-none mix-blend-multiply"></div>
        <div className="w-full max-w-md relative z-10">
          {/* Mobile Header */}
          <div className="flex md:hidden items-center justify-center gap-3 text-xl font-display font-bold mb-10 text-indigo-950 tracking-tight">
            <img 
              src="https://i.postimg.cc/h40vHdRJ/IMG-20260217-WA0010.jpg" 
              alt="OTS Logo" 
              referrerPolicy="no-referrer"
              className="w-10 h-10 object-cover rounded-xl border border-slate-200 shadow-sm"
            />
            <div className="flex flex-col text-left">
              <span className="leading-none text-base font-extrabold text-slate-900">OTS EXAM BATCH</span>
              <span className="text-[8px] uppercase tracking-widest text-slate-400 font-bold mt-1">Smart Learning Platform</span>
            </div>
          </div>

          <div className="bg-white p-8 sm:p-10 rounded-3xl shadow-xl shadow-slate-200/50 border border-slate-100">
            <h2 className="text-3xl font-display font-bold mb-2 text-slate-900 tracking-tight">
              {isLogin ? 'Welcome back' : 'Create an account'}
            </h2>
            <p className="text-slate-500 mb-6 text-sm font-medium">
              {isLogin ? 'Enter your details to access your dashboard' : 'Sign up to start taking exams'}
            </p>

            {error && (
              <div className="bg-rose-50 text-rose-600 p-3 rounded-xl text-sm mb-6 border border-rose-100 font-semibold">
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              {!isLogin && (
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-1 uppercase tracking-wider text-[10px]">Full Name</label>
                  <input 
                    type="text" 
                    required 
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-4 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent outline-none transition-all font-medium"
                    placeholder="John Doe"
                  />
                </div>
              )}
              
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-1 uppercase tracking-wider text-[10px]">Email address</label>
                <input 
                  type="email" 
                  required 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-4 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent outline-none transition-all font-medium"
                  placeholder="student@example.com"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-700 mb-1 uppercase tracking-wider text-[10px]">Password</label>
                <input 
                  type="password" 
                  required 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-4 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent outline-none transition-all font-medium"
                  placeholder="••••••••"
                />
              </div>

              <button 
                type="submit"
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 rounded-xl transition-colors flex items-center justify-center gap-2 mt-6 shadow-lg shadow-indigo-200"
              >
                {isLogin ? 'Sign In' : 'Register'}
                <ArrowRight className="h-4 w-4" />
              </button>
            </form>

            <div className="mt-6 text-center">
              <button 
                onClick={() => setIsLogin(!isLogin)}
                className="text-indigo-600 hover:text-indigo-700 text-sm font-medium"
              >
                {isLogin ? "Don't have an account? Sign up" : "Already have an account? Sign in"}
              </button>
            </div>
          </div>
          
          {/* OTS Helpline Integrations */}
          <div className="mt-6 bg-white/80 border border-slate-200 rounded-3xl p-5 shadow-sm text-center">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3">OTS Help & Support</p>
            <div className="flex flex-wrap items-center justify-center gap-4 text-xs font-semibold">
              <a 
                href="https://www.facebook.com/share/18j8TYZ1SE/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 text-[#1877F2] hover:underline"
              >
                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M22 12c0-5.52-4.48-10-10-10S2 6.48 2 12c0 4.84 3.44 8.87 8 9.8V15H8v-3h2V9.5C10 7.57 11.57 6 13.5 6H16v3h-2c-.55 0-1 .45-1 1v2h3v3h-3v6.95c4.56-.93 8-4.96 8-9.75z"/></svg>
                <span>FB Page</span>
              </a>

              <span className="text-slate-350">•</span>

              <a 
                href="https://wa.me/8801912428298" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 text-[#128C7E] hover:underline"
              >
                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.06 5.348 5.397.01 12.008.01c3.202.001 6.212 1.246 8.477 3.513 2.266 2.268 3.507 5.28 3.505 8.484-.004 6.657-5.34 11.997-11.953 11.997-2.005-.001-3.973-.502-5.713-1.455L0 24zm6.79-11.362c.071-.117.265-.188.494-.301.23-.115 1.353-.667 1.56-.745.206-.077.356-.115.507.114.151.23.585.742.716.892.132.148.263.167.493.051.23-.115.97-.358 1.848-1.144.682-.609 1.143-1.361 1.277-1.59.134-.23.015-.354-.1-.469-.103-.105-.23-.269-.346-.403-.114-.135-.152-.23-.23-.385-.078-.153-.039-.289-.019-.404.019-.115.152-.385.206-.52.054-.131.107-.227.051-.341-.056-.114-.507-1.22-.693-1.67-.181-.437-.367-.378-.507-.385-.131-.007-.281-.007-.432-.007-.151 0-.397.057-.604.288-.206.23-.79.771-.79 1.879s.804 2.173.917 2.327c.113.153 1.58 2.413 3.829 3.385.535.232.953.371 1.277.474.538.17 1.027.146 1.414.089.431-.064 1.353-.553 1.543-1.085.19-.533.19-1.01.134-1.104-.055-.095-.205-.15-.436-.264z"/></svg>
                <span>WhatsApp</span>
              </a>

              <span className="text-slate-350">•</span>

              <a 
                href="https://youtube.com/@onetimeschool-ots-31?si=Nv0XKhnRzqMXF2YU" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 text-[#FF0000] hover:underline"
              >
                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M23.498 6.163a3.003 3.003 0 0 0-2.11-2.11C19.517 3.545 12 3.545 12 3.545s-7.517 0-9.388.507a3.003 3.003 0 0 0-2.11 2.11C0 8.033 0 12 0 12s0 3.967.502 5.837a3.003 3.003 0 0 0 2.11 2.11c1.871.507 9.388.507 9.388.507s7.517 0 9.388-.507a3.003 3.003 0 0 0 2.11-2.11C24 15.967 24 12 24 12s0-3.967-.502-5.837zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>
                <span>YouTube</span>
              </a>
            </div>
          </div>
          
          <div className="mt-6 text-center">
             <button 
               onClick={() => navigate('/admin-login')}
               className="text-slate-400 hover:text-slate-600 text-xs font-bold uppercase tracking-widest"
             >
               Admin Access
             </button>
          </div>
        </div>
      </div>
    </div>
  );
}
