import React from 'react';
import { useStore } from '../../store/useStore';
import { Users, FileText, Activity } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function AdminDashboard() {
  const { users, exams, results } = useStore();
  
  const studentCount = users.filter(u => u.role === 'user').length;
  const activeExams = exams.filter(e => e.status === 'published' && e.endTime > Date.now()).length;
  const totalSubmissions = results.length;

  const stats = [
    { label: 'Total Students', value: studentCount, icon: Users, color: 'text-blue-600', bg: 'bg-blue-50' },
    { label: 'Active Exams', value: activeExams, icon: Activity, color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { label: 'Total Submissions', value: totalSubmissions, icon: FileText, color: 'text-orange-600', bg: 'bg-orange-50' },
  ];

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-display font-bold text-slate-900 tracking-tight">Dashboard Overview</h1>
          <p className="text-slate-500 text-sm mt-1 font-medium">Platform statistics and recent activity</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
        {stats.map((stat, idx) => (
          <div key={idx} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4 hover:border-indigo-200 transition-colors">
            <div className={`w-14 h-14 ${stat.bg} rounded-xl flex items-center justify-center`}>
              <stat.icon className={`h-7 w-7 ${stat.color}`} />
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{stat.label}</span>
              <span className="text-2xl font-black text-slate-900">{stat.value}</span>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="px-6 py-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <h2 className="text-base font-bold text-slate-900">Recent Exam Submissions</h2>
          <Link to="/admin/leaderboard" className="text-xs font-bold text-indigo-600 hover:text-indigo-700 tracking-wide uppercase">View All</Link>
        </div>
        <div className="divide-y divide-slate-100">
          {results.slice(-5).reverse().map(result => {
             const user = users.find(u => u.id === result.userId);
             const exam = exams.find(e => e.id === result.examId);
             if (!user || !exam) return null;
             
             return (
               <div key={result.id} className="px-6 py-4 flex items-center justify-between hover:bg-slate-50 transition-colors">
                 <div>
                   <div className="font-bold text-slate-900 text-sm">{user.name}</div>
                   <div className="text-[11px] font-semibold tracking-wide text-slate-500 uppercase mt-0.5">{exam.title}</div>
                 </div>
                 <div className="text-right flex flex-col items-end">
                   <div className="font-black text-indigo-600 text-lg leading-none">{Math.round(result.accuracy)}%</div>
                   <div className="text-[10px] uppercase font-bold tracking-widest text-slate-400 mt-1">{result.score} of {result.totalQuestions}</div>
                 </div>
               </div>
             );
          })}
          {results.length === 0 && (
             <div className="px-6 py-8 text-center text-slate-500 font-medium">
               No submissions yet.
             </div>
          )}
        </div>
      </div>
    </div>
  );
}
