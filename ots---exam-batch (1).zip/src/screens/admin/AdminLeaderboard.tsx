import React, { useState } from 'react';
import { useStore } from '../../store/useStore';
import { Trophy, Medal, Search, Download, Users } from 'lucide-react';

export default function AdminLeaderboard() {
  const { results, users, exams } = useStore();
  const [selectedExamId, setSelectedExamId] = useState<string>(exams[0]?.id || '');

  const examResults = React.useMemo(() => {
    const filtered = results.filter(r => r.examId === selectedExamId);
    
    // Group by userId and pick the best result for each student
    const bestResultsMap = new Map<string, typeof results[0]>();
    
    filtered.forEach(res => {
      const existing = bestResultsMap.get(res.userId);
      // We prioritize higher score, then higher accuracy
      if (!existing || 
          res.score > existing.score || 
          (res.score === existing.score && res.accuracy > existing.accuracy)) {
        bestResultsMap.set(res.userId, res);
      }
    });

    return Array.from(bestResultsMap.values())
      .sort((a, b) => b.score - a.score || b.accuracy - a.accuracy);
  }, [results, selectedExamId]);

  const handleExportCSV = () => {
    if (!selectedExamId || examResults.length === 0) return;
    
    // Create CSV header
    const headers = ['Rank', 'Name', 'Email', 'Score', 'Total Questions', 'Accuracy %', 'Correct', 'Wrong'];
    
    // Create CSV rows
    const rows = examResults.map((res, idx) => {
      const student = users.find(u => u.id === res.userId);
      return [
        idx + 1,
        `"${student?.name || 'Unknown'}"`,
        `"${student?.email || ''}"`,
        res.score,
        res.totalQuestions,
        Math.round(res.accuracy),
        res.correctAnswers,
        res.wrongAnswers
      ].join(',');
    });
    
    // Combine and trigger download
    const csvContent = [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    
    const exam = exams.find(e => e.id === selectedExamId);
    link.setAttribute('download', `${exam?.title.replace(/\s+/g, '_') || 'leaderboard'}_results.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div>
      <div className="flex sm:items-center justify-between flex-col sm:flex-row gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-display font-bold text-slate-900 tracking-tight">Tournament Leaderboard</h1>
          <p className="text-slate-500 text-sm mt-1 font-medium">Rankings based on exam performance</p>
        </div>
        <div className="flex items-center gap-3">
          {examResults.length > 0 && selectedExamId && (
            <button
              onClick={handleExportCSV}
              className="flex items-center justify-center gap-2 px-4 py-2.5 bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 hover:text-indigo-600 font-bold text-sm rounded-xl transition-all shadow-sm"
            >
              <Download className="w-4 h-4" /> 
              <span className="hidden sm:inline">Export CSV</span>
            </button>
          )}
          <select 
            value={selectedExamId}
            onChange={(e) => setSelectedExamId(e.target.value)}
            className="bg-white border border-slate-200 text-slate-900 font-bold text-sm rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent block w-full sm:w-auto p-2.5 outline-none shadow-sm transition-all"
          >
            <option value="" disabled>Select Exam</option>
            {exams.map(e => <option key={e.id} value={e.id}>{e.title}</option>)}
          </select>
        </div>
      </div>

      {!selectedExamId ? (
        <div className="bg-white p-12 text-center rounded-2xl shadow-sm border border-slate-200">
          <Trophy className="w-12 h-12 text-slate-300 mx-auto mb-4" />
          <p className="text-slate-500 font-medium">Please select an exam to view the leaderboard.</p>
        </div>
      ) : examResults.length === 0 ? (
        <div className="bg-white p-12 text-center rounded-2xl shadow-sm border border-slate-200">
             <Trophy className="w-12 h-12 text-slate-300 mx-auto mb-4" />
             <p className="text-slate-500 font-medium">No submissions yet for this exam.</p>
        </div>
      ) : (
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-[10px] uppercase tracking-widest font-bold text-slate-500">
                  <th className="py-4 px-6 w-16 text-center">Rank</th>
                  <th className="py-4 px-6">Student</th>
                  <th className="py-4 px-6 text-center">Score</th>
                  <th className="py-4 px-6 text-center">Accuracy</th>
                  <th className="py-4 px-6 text-right">Correct/Wrong</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium">
                {examResults.map((result, index) => {
                  const student = users.find(u => u.id === result.userId);
                  if (!student) return null;
                  
                  return (
                    <tr key={result.id} className="hover:bg-slate-50/50 transition-colors">
                      <td className="py-4 px-6 text-center">
                        {index === 0 ? <Medal className="w-6 h-6 text-yellow-500 mx-auto" /> :
                         index === 1 ? <Medal className="w-6 h-6 text-slate-400 mx-auto" /> :
                         index === 2 ? <Medal className="w-6 h-6 text-amber-600 mx-auto" /> :
                         <span className="text-slate-400 font-bold">{index + 1}</span>}
                      </td>
                      <td className="py-4 px-6">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-slate-100 flex-shrink-0 overflow-hidden border border-slate-200">
                             {student.profile?.photoUrl ? (
                               <img src={student.profile.photoUrl} alt="" className="w-full h-full object-cover" />
                             ) : (
                               <div className="w-full h-full flex items-center justify-center text-slate-400">
                                 <Users className="w-5 h-5 opacity-50" />
                               </div>
                             )}
                          </div>
                          <div>
                            <div className="text-slate-900 font-bold">{student.name}</div>
                            <div className="text-xs font-semibold text-slate-500 mt-0.5">{student.email}</div>
                          </div>
                        </div>
                      </td>
                      <td className="py-4 px-6 text-center">
                        <span className="text-xl font-black text-slate-900">{result.score}</span>
                        <span className="text-xs font-bold text-slate-400">/{result.totalQuestions}</span>
                      </td>
                      <td className="py-4 px-6 text-center">
                        <div className="inline-flex items-center justify-center px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-50 text-indigo-700 tracking-widest">
                          {Math.round(result.accuracy)}%
                        </div>
                      </td>
                      <td className="py-4 px-6 text-right text-sm">
                        <span className="text-emerald-600 font-bold">{result.correctAnswers}</span>
                        <span className="text-slate-300 mx-1 font-black">/</span>
                        <span className="text-rose-500 font-bold">{result.wrongAnswers}</span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
