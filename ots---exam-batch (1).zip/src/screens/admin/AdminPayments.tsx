import React, { useState } from 'react';
import { useStore } from '../../store/useStore';
import { Check, X, Search, Settings, CreditCard } from 'lucide-react';
import { format } from 'date-fns';

export default function AdminPayments() {
  const { payments, exams, events, courses, users, paymentConfig, updatePaymentConfig, updatePaymentStatus, enrollInCourse, joinEvent } = useStore();
  const [activeTab, setActiveTab] = useState<'pending' | 'history' | 'settings'>('pending');
  const [pendingAction, setPendingAction] = useState<{ id: string, type: 'verify' | 'reject' } | null>(null);

  const [config, setConfig] = useState(paymentConfig);
  const [isSaved, setIsSaved] = useState(false);

  React.useEffect(() => {
    if (paymentConfig) {
      setConfig(paymentConfig);
    }
  }, [paymentConfig]);

  const pendingPayments = payments.filter(p => p.status === 'pending');
  const historyPayments = payments.filter(p => p.status !== 'pending');

  const handleSaveSettings = () => {
    updatePaymentConfig(config);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  const getTargetName = (type: 'exam' | 'event' | 'course', id: string) => {
    if (type === 'exam') return exams.find(e => e.id === id)?.title || 'Unknown Exam';
    if (type === 'event') return events.find(e => e.id === id)?.title || 'Unknown Event';
    return courses.find(c => c.id === id)?.title || 'Unknown Course';
  };

  const getUserName = (id: string) => {
    const user = users.find(u => u.id === id);
    return user ? `${user.name} (${user.email})` : 'Unknown User';
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-display font-bold text-slate-900 tracking-tight">Payment Management</h1>
        <p className="text-slate-500 text-sm mt-1 font-medium">Verify student transactions and configure payment methods</p>
      </div>

      <div className="flex gap-4 mb-6 border-b border-slate-200">
        <button 
          onClick={() => setActiveTab('pending')}
          className={`pb-4 px-2 text-sm font-bold uppercase tracking-wider transition-colors border-b-2 ${activeTab === 'pending' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-500 hover:text-slate-900'}`}
        >
          Pending Verifications
          {pendingPayments.length > 0 && (
            <span className="ml-2 bg-rose-500 text-white text-[10px] px-2 py-0.5 rounded-full">{pendingPayments.length}</span>
          )}
        </button>
        <button 
          onClick={() => setActiveTab('history')}
          className={`pb-4 px-2 text-sm font-bold uppercase tracking-wider transition-colors border-b-2 ${activeTab === 'history' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-500 hover:text-slate-900'}`}
        >
          Payment History
        </button>
        <button 
          onClick={() => setActiveTab('settings')}
          className={`pb-4 px-2 text-sm font-bold uppercase tracking-wider transition-colors border-b-2 ${activeTab === 'settings' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-500 hover:text-slate-900'}`}
        >
          Settings
        </button>
      </div>

      {activeTab === 'settings' && (
        <div className="bg-white p-6 sm:p-8 rounded-3xl shadow-sm border border-slate-200 max-w-2xl">
          <h2 className="text-lg font-bold text-slate-900 mb-6 flex items-center gap-2">
            <Settings className="w-5 h-5 text-indigo-500" /> Payment Methods Config
          </h2>
          <div className="space-y-5">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">bKash Personal Number</label>
              <input type="text" value={config.bkash} onChange={e => setConfig({...config, bkash: e.target.value})} className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none font-medium" />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Nagad Personal Number</label>
              <input type="text" value={config.nagad} onChange={e => setConfig({...config, nagad: e.target.value})} className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none font-medium" />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Rocket Personal Number</label>
              <input type="text" value={config.rocket} onChange={e => setConfig({...config, rocket: e.target.value})} className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none font-medium" />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">YouTube Payment Video Link / পেমেন্ট টিউটোরিয়াল ভিডিও</label>
              <input 
                type="text" 
                value={config.youtubeUrl || ''} 
                onChange={e => setConfig({...config, youtubeUrl: e.target.value})} 
                placeholder="e.g. https://www.youtube.com/watch?v=XXXXXX" 
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none font-medium text-xs font-mono" 
              />
              <p className="text-[10px] text-slate-450 font-bold mt-1.5 uppercase tracking-wide">
                This YouTube guide link will be shown in the checkout modal so students know how to complete the payment.
              </p>
            </div>
            <button onClick={handleSaveSettings} className={`w-full sm:w-auto px-6 py-2.5 rounded-xl font-bold uppercase tracking-wider transition-all shadow-sm ${isSaved ? 'bg-emerald-500 hover:bg-emerald-600 text-white shadow-emerald-500/25' : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-indigo-600/25'}`}>
              {isSaved ? 'SAVED SUCCESSFULLY' : 'SAVE CHANGES'}
            </button>
          </div>
        </div>
      )}

      {(activeTab === 'pending' || activeTab === 'history') && (
        <div className="bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-50 border-b border-slate-200 text-[10px] uppercase tracking-widest font-bold text-slate-500">
                <tr>
                  <th className="py-4 px-6">Date</th>
                  <th className="py-4 px-6">Student</th>
                  <th className="py-4 px-6">Target (Exam/Event)</th>
                  <th className="py-4 px-6">Amount & Method</th>
                  <th className="py-4 px-6">Trx ID</th>
                  <th className="py-4 px-6 text-center">Status/Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {(activeTab === 'pending' ? pendingPayments : historyPayments).map(payment => (
                  <tr key={payment.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="py-4 px-6">
                      <div className="text-xs font-semibold text-slate-700">
                        {format(payment.createdAt, 'MMM d, yyyy h:mm a')}
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <div className="text-sm font-bold text-slate-900">{getUserName(payment.userId)}</div>
                    </td>
                    <td className="py-4 px-6">
                      <span className="inline-block px-2 text-[10px] uppercase font-bold tracking-widest bg-slate-100 text-slate-600 rounded-sm mb-1">{payment.targetType}</span>
                      <div className="text-sm font-semibold text-slate-800">{getTargetName(payment.targetType, payment.targetId)}</div>
                    </td>
                    <td className="py-4 px-6">
                      <div className="text-sm font-bold text-slate-900">৳ {payment.amount}</div>
                      <div className="text-xs font-medium text-slate-500 capitalize">{payment.method}</div>
                    </td>
                    <td className="py-4 px-6">
                      <div className="font-mono text-xs font-bold bg-slate-100 px-2 py-1 rounded inline-block text-slate-700">
                        {payment.trxId}
                      </div>
                    </td>
                    <td className="py-4 px-6 text-center">
                      {payment.status === 'pending' ? (
                        <div className="flex items-center justify-center gap-2">
                          {pendingAction?.id === payment.id ? (
                            <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 px-1.5 py-1 rounded-xl animate-in fade-in zoom-in-95 duration-200">
                              <span className="text-[9px] font-black text-slate-700 uppercase px-0.5">
                                {pendingAction.type === 'verify' ? 'Verify?' : 'Reject?'}
                              </span>
                              <button 
                                onClick={() => {
                                  const status = pendingAction.type === 'verify' ? 'verified' : 'rejected';
                                  updatePaymentStatus(payment.id, status);
                                  if (status === 'verified') {
                                      if (payment.targetType === 'course') {
                                          enrollInCourse(payment.userId, payment.targetId);
                                      } else if (payment.targetType === 'event') {
                                          joinEvent(payment.userId, payment.targetId);
                                      }
                                  }
                                  setPendingAction(null);
                                }}
                                className={`px-2 py-0.5 text-white rounded text-[9px] font-black uppercase tracking-wider transition-all ${
                                  pendingAction.type === 'verify' ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-rose-600 hover:bg-rose-700'
                                }`}
                              >
                                Yes
                              </button>
                              <button 
                                onClick={() => setPendingAction(null)}
                                className="px-2 py-0.5 bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 rounded text-[9px] font-black uppercase tracking-wider transition-all"
                              >
                                No
                              </button>
                            </div>
                          ) : (
                            <>
                              <button 
                                onClick={() => setPendingAction({ id: payment.id, type: 'verify' })}
                                className="bg-emerald-100 text-emerald-700 hover:bg-emerald-200 p-2 rounded-lg transition-colors group relative"
                                title="Verify"
                              >
                                <Check className="w-4 h-4" />
                              </button>
                              <button 
                                onClick={() => setPendingAction({ id: payment.id, type: 'reject' })}
                                className="bg-rose-100 text-rose-700 hover:bg-rose-200 p-2 rounded-lg transition-colors"
                                title="Reject"
                              >
                                <X className="w-4 h-4" />
                              </button>
                            </>
                          )}
                        </div>
                      ) : (
                        <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
                          payment.status === 'verified' ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'
                        }`}>
                          {payment.status}
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
                {(activeTab === 'pending' ? pendingPayments : historyPayments).length === 0 && (
                  <tr>
                    <td colSpan={6} className="py-12 text-center text-slate-500 font-medium">
                      No payments found in this category.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
