import React, { useState } from 'react';
import { useStore } from '../../store/useStore';
import { Plus, Trash2, Tags, ArrowRight, FolderPlus, Compass } from 'lucide-react';

export default function AdminCategories() {
  const { categories, createCategory, deleteCategory, addSubCategory, deleteSubCategory, courses } = useStore();
  const [newCategoryName, setNewCategoryName] = useState('');
  const [activeCategoryId, setActiveCategoryId] = useState<string | null>(null);
  const [newSubCategoryNames, setNewSubCategoryNames] = useState<Record<string, string>>({});
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const handleCreateCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCategoryName.trim()) return;
    createCategory(newCategoryName.trim());
    setNewCategoryName('');
  };

  const handleAddSubCategory = (categoryId: string, e: React.FormEvent) => {
    e.preventDefault();
    const subName = newSubCategoryNames[categoryId]?.trim();
    if (!subName) return;
    addSubCategory(categoryId, subName);
    setNewSubCategoryNames({
      ...newSubCategoryNames,
      [categoryId]: ''
    });
  };

  // Helper to count courses in category / sub-category
  const getCoursesCount = (catName: string, subName?: string) => {
    if (!courses) return 0;
    return courses.filter(c => {
      const matchCat = c.category === catName;
      if (subName) {
        return matchCat && (c.subCategory === subName || (!c.subCategory && c.title.toLowerCase().includes(subName.toLowerCase())));
      }
      return matchCat;
    }).length;
  };

  const safeCategories = categories || [];

  return (
    <div className="max-w-6xl mx-auto">
      {/* Page Header */}
      <div className="flex sm:items-center justify-between flex-col sm:flex-row gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-display font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Tags className="text-indigo-600 w-8 h-8" /> Customize Categories
          </h1>
          <p className="text-slate-500 text-sm mt-1 font-medium">Add, rename, or structure your course admission batches and learning sub-categories</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Create Category */}
        <div className="space-y-6 lg:col-span-1">
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
            <h2 className="text-lg font-bold text-slate-900 mb-1 flex items-center gap-2">
              <FolderPlus className="w-5 h-5 text-indigo-500" /> New Category Batch
            </h2>
            <p className="text-xs text-slate-500 mb-5 font-medium">Add general batches like "Admission 26", "HSC", or "SSC"</p>
            
            <form onSubmit={handleCreateCategory} className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Category Name</label>
                <input 
                  type="text" 
                  required 
                  placeholder="e.g. Admission 25, HSC" 
                  value={newCategoryName} 
                  onChange={e => setNewCategoryName(e.target.value)} 
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none font-semibold text-sm transition-shadow placeholder:text-slate-400" 
                />
              </div>
              <button 
                type="submit" 
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded-xl text-xs font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/20"
              >
                <Plus className="w-4 h-4" /> Add Category
              </button>
            </form>
          </div>

          {/* Guidelines info */}
          <div className="bg-indigo-50/50 p-6 rounded-3xl border border-indigo-100/50">
            <h3 className="text-sm font-bold text-indigo-950 flex items-center gap-1.5 mb-2">
              <Compass className="w-4 h-4 text-indigo-600" /> How they filter
            </h3>
            <p className="text-xs text-indigo-900 leading-relaxed font-medium">
              Adding sub-categories here creates beautiful selective chips for your student portal!
            </p>
            <p className="text-xs text-indigo-850 hover:underline cursor-pointer mt-2 font-bold flex items-center gap-1">
              View Student Portal <ArrowRight className="w-3.5 h-3.5" />
            </p>
          </div>
        </div>

        {/* Right Columns: Categories List & Sub-categories Detail */}
        <div className="lg:col-span-2 space-y-6">
          {safeCategories.length === 0 ? (
            <div className="bg-white p-12 rounded-3xl border border-dashed border-slate-200 text-center">
              <p className="text-slate-500 font-medium">No custom admission categories created yet.</p>
            </div>
          ) : (
            <div className="space-y-6">
              {safeCategories.map(category => {
                const isExpanded = activeCategoryId === category.id;
                return (
                  <div key={category.id} className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden hover:border-slate-350 transition-colors">
                    {/* Header */}
                    <div className="p-6 flex items-center justify-between bg-slate-50/50 border-b border-slate-100">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-extrabold text-slate-900 text-lg font-display">{category.name}</span>
                          <span className="bg-indigo-100 text-indigo-700 font-bold text-[10px] px-2 py-0.5 rounded-full uppercase tracking-wider">
                            {category.subCategories?.length || 0} Sub-categories
                          </span>
                        </div>
                        <p className="text-xs text-slate-400 font-semibold mt-1">
                          Applied to {getCoursesCount(category.name)} active courses
                        </p>
                      </div>
                      
                      <div className="flex gap-2 items-center">
                        <button 
                          onClick={() => setActiveCategoryId(isExpanded ? null : category.id)}
                          className="px-4 py-2 bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 rounded-xl text-xs font-bold uppercase tracking-wider transition-all"
                        >
                          {isExpanded ? 'Hide Details' : 'Manage Subs'}
                        </button>
                        
                        {confirmDeleteId === category.id ? (
                          <div className="flex items-center gap-1.5 bg-rose-50 border border-rose-150 px-2.5 py-1.5 rounded-xl animate-in fade-in zoom-in-95 duration-200">
                            <span className="text-[10px] font-black text-rose-800 uppercase px-1">Confirm?</span>
                            <button 
                              onClick={() => {
                                deleteCategory(category.id);
                                setConfirmDeleteId(null);
                              }}
                              className="px-3 py-1 bg-rose-600 hover:bg-rose-705 text-white rounded-lg text-[10px] font-black uppercase tracking-wider transition-all"
                            >
                              Yes
                            </button>
                            <button 
                              onClick={() => setConfirmDeleteId(null)}
                              className="px-3 py-1 bg-white hover:bg-slate-100 border border-slate-200 text-slate-705 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all"
                            >
                              No
                            </button>
                          </div>
                        ) : (
                          <button 
                            onClick={() => setConfirmDeleteId(category.id)}
                            className="p-2 bg-rose-50 hover:bg-rose-100 border border-rose-100 text-rose-600 rounded-xl transition-colors"
                            title="Delete Category"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Sub-categories segment */}
                    {isExpanded && (
                      <div className="p-6 bg-white space-y-5">
                        {/* Sub-categories chips list */}
                        <div>
                          <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-widest mb-3">Active Sub-Categories (Segments)</label>
                          <div className="flex flex-wrap gap-2">
                            {(!category.subCategories || category.subCategories.length === 0) ? (
                              <span className="text-xs text-slate-400 font-medium italic">No sub-categories added yet under {category.name}. Add one below!</span>
                            ) : (
                              category.subCategories.map(sub => (
                                <div key={sub} className="bg-slate-50 hover:bg-slate-100 border border-slate-200/60 pl-3 pr-2 py-1.5 rounded-xl flex items-center gap-2 text-xs font-semibold text-slate-600 transition-colors">
                                  <span>{sub}</span>
                                  <span className="text-[10px] text-slate-400 font-bold bg-white px-1.5 py-0.5 rounded">
                                    {getCoursesCount(category.name, sub)}
                                  </span>
                                  <button 
                                    onClick={() => deleteSubCategory(category.id, sub)}
                                    className="text-slate-400 hover:text-rose-600 p-0.5 rounded transition-colors"
                                  >
                                    <XIcon className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              ))
                            )}
                          </div>
                        </div>

                        <hr className="border-slate-100" />

                        {/* Add sub-category inline form */}
                        <form onSubmit={(e) => handleAddSubCategory(category.id, e)} className="flex items-center gap-3 max-w-md">
                          <input 
                            type="text" 
                            required 
                            placeholder={`New sub-category for ${category.name}`}
                            value={newSubCategoryNames[category.id] || ''} 
                            onChange={e => setNewSubCategoryNames({
                              ...newSubCategoryNames,
                              [category.id]: e.target.value
                            })} 
                            className="flex-1 px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none font-semibold text-xs transition-shadow" 
                          />
                          <button 
                            type="submit" 
                            className="bg-slate-900 hover:bg-black text-white px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-2"
                          >
                            <Plus className="w-3.5 h-3.5" /> Add Sub
                          </button>
                        </form>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// Simple internal X icon to replace general lucide-react dependencies
function XIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" {...props}>
      <path d="M18 6 6 18" />
      <path d="m6 6 12 12" />
    </svg>
  );
}
