import React, { useState } from 'react';
import { useStore } from '../../store/useStore';
import { Plus, Trash2, Edit2, Play, Users, BookOpen, X, Send, Bell } from 'lucide-react';
import { format } from 'date-fns';
import { Course, CourseNotice } from '../../types';

export default function AdminCourses() {
  const { courses, createCourse, updateCourse, deleteCourse, createCourseNotice, users, categories } = useStore();
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingCourse, setEditingCourse] = useState<Course | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const [isNoticeModalOpen, setIsNoticeModalOpen] = useState(false);
  const [targetCourseId, setTargetCourseId] = useState<string | null>(null);
  const [noticeForm, setNoticeForm] = useState({ title: '', message: '' });

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: '',
    subCategory: '',
    bannerUrl: '',
    isPaid: false,
    feeAmount: 0,
    discountAmount: 0,
    isPromoted: false,
    routineText: '',
    routineImageUrl: '',
  });

  const handleOpenForm = (course?: Course) => {
    if (course) {
      setEditingCourse(course);
      setFormData({
        title: course.title,
        description: course.description,
        category: course.category,
        subCategory: course.subCategory || '',
        bannerUrl: course.bannerUrl || '',
        isPaid: course.isPaid || false,
        feeAmount: course.feeAmount || 0,
        discountAmount: course.discountAmount || 0,
        isPromoted: course.isPromoted || false,
        routineText: course.routineText || '',
        routineImageUrl: course.routineImageUrl || '',
      });
    } else {
      setEditingCourse(null);
      setFormData({
        title: '',
        description: '',
        category: '',
        subCategory: '',
        bannerUrl: '',
        isPaid: false,
        feeAmount: 0,
        discountAmount: 0,
        isPromoted: false,
        routineText: '',
        routineImageUrl: '',
      });
    }
    setIsFormOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingCourse) {
      updateCourse(editingCourse.id, formData);
    } else {
      createCourse(formData as any);
    }
    setIsFormOpen(false);
  };

  const getEnrolledUsersCount = (courseId: string) => {
    return users.filter(u => u.enrolledCourses?.includes(courseId)).length;
  };

  return (
    <div>
      <div className="flex sm:items-center justify-between flex-col sm:flex-row gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-display font-bold text-slate-900 tracking-tight">Manage Courses</h1>
          <p className="text-slate-500 text-sm mt-1 font-medium">Create and organize study courses</p>
        </div>
        <button 
          onClick={() => handleOpenForm()}
          className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-xl text-sm font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/20"
        >
          <Plus className="w-4 h-4" /> New Course
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {courses.map(course => (
          <div key={course.id} className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm hover:shadow-md transition-shadow group flex flex-col">
             <div className="h-32 bg-slate-100 relative">
               {course.bannerUrl ? (
                 <img src={course.bannerUrl} alt={course.title} className="w-full h-full object-cover" />
               ) : (
                 <div className="absolute inset-0 bg-indigo-50 flex items-center justify-center">
                    <BookOpen className="w-10 h-10 text-indigo-300" />
                 </div>
               )}
               <div className="absolute top-3 right-3 bg-white/90 backdrop-blur px-2 py-1 rounded-lg text-[10px] font-bold uppercase tracking-widest text-slate-700 flex items-center gap-1">
                 <Users className="w-3 h-3" /> {getEnrolledUsersCount(course.id)} Enrolled
               </div>
               {course.isPaid && (
                  <div className="absolute top-3 left-3 bg-amber-400 text-amber-950 px-2 py-1 rounded-lg text-[10px] font-bold uppercase tracking-widest">
                    Paid
                  </div>
               )}
             </div>
             
             <div className="p-6 flex-1 flex flex-col">
               <div className="text-[10px] font-bold uppercase tracking-widest text-indigo-500 mb-2">
                 {course.category || 'General'}{course.subCategory ? ` / ${course.subCategory}` : ''}
               </div>
               <h3 className="text-lg font-bold text-slate-900 mb-2 font-display">{course.title}</h3>
               <p className="text-sm text-slate-500 font-medium mb-4 line-clamp-2 flex-1">{course.description}</p>
               
               <div className="flex gap-2 mt-auto pt-4 border-t border-slate-100">
                 <button 
                   onClick={() => handleOpenForm(course)}
                   className="flex-1 bg-slate-50 hover:bg-slate-100 text-slate-700 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition-colors flex items-center justify-center gap-1 border border-slate-200"
                 >
                   <Edit2 className="w-3.5 h-3.5" /> Edit
                 </button>
                 <button 
                    onClick={() => {
                        setTargetCourseId(course.id);
                        setIsNoticeModalOpen(true);
                        setNoticeForm({ title: '', message: '' });
                    }}
                    className="flex-none bg-indigo-50 hover:bg-indigo-100 text-indigo-600 px-3.5 py-2 rounded-xl text-xs font-bold transition-colors border border-indigo-100 flex items-center justify-center"
                    title="Send Notice"
                  >
                    <Send className="w-3.5 h-3.5" />
                  </button>
                 {confirmDeleteId === course.id ? (
                   <div className="flex items-center gap-1 bg-rose-50 border border-rose-100 px-1.5 py-1 rounded-xl animate-in fade-in zoom-in-95 duration-200">
                     <span className="text-[9px] font-black text-rose-800 uppercase px-0.5">Confirm?</span>
                     <button 
                       onClick={() => {
                         deleteCourse(course.id);
                         setConfirmDeleteId(null);
                       }}
                       className="px-2 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-[9px] font-black uppercase tracking-wider transition-all"
                     >
                       Yes
                     </button>
                     <button 
                       onClick={() => setConfirmDeleteId(null)}
                       className="px-2 py-1 bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 rounded-lg text-[9px] font-black uppercase tracking-wider transition-all"
                     >
                       No
                     </button>
                   </div>
                 ) : (
                   <button 
                     onClick={() => setConfirmDeleteId(course.id)}
                     className="flex-none bg-rose-50 hover:bg-rose-100 text-rose-600 px-4 py-2 rounded-xl text-xs font-bold transition-colors border border-rose-100"
                   >
                     <Trash2 className="w-3.5 h-3.5" />
                   </button>
                 )}
               </div>
             </div>
          </div>
        ))}
      </div>

      {isFormOpen && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white max-w-xl w-full rounded-3xl overflow-hidden shadow-2xl relative animate-slideDown max-h-[90vh] flex flex-col">
            <button 
              onClick={() => setIsFormOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 p-2 rounded-full transition-colors z-10"
            >
              <X className="w-4 h-4" />
            </button>
            <div className="p-8 pb-6 border-b border-slate-100 flex-none">
              <h2 className="text-2xl font-display font-bold text-slate-900 mb-1">{editingCourse ? 'Edit Course' : 'Create Course'}</h2>
            </div>
            
            <div className="p-8 overflow-y-auto flex-1">
              <form id="courseForm" onSubmit={handleSubmit} className="space-y-5">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Course Title</label>
                  <input type="text" required value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none font-medium" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Description</label>
                  <textarea required rows={3} value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none font-medium resize-none"></textarea>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider font-semibold">Category (Batch)</label>
                    <select 
                      required
                      value={formData.category} 
                      onChange={e => {
                        const newCat = e.target.value;
                        setFormData({
                          ...formData,
                          category: newCat,
                          subCategory: ''
                        });
                      }} 
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none text-sm font-semibold"
                    >
                      <option value="">-- Select Category --</option>
                      {(categories || []).map(cat => (
                        <option key={cat.id} value={cat.name}>{cat.name}</option>
                      ))}
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider font-semibold">Sub-Category (Segment)</label>
                    <select 
                      value={formData.subCategory || ''} 
                      onChange={e => setFormData({...formData, subCategory: e.target.value})} 
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none text-sm font-semibold"
                    >
                      <option value="">-- None / General --</option>
                      {((categories || []).find(cat => cat.name === formData.category)?.subCategories || []).map(sub => (
                        <option key={sub} value={sub}>{sub}</option>
                      ))}
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Banner Image URL (Optional)</label>
                  <input type="url" value={formData.bannerUrl} onChange={e => setFormData({...formData, bannerUrl: e.target.value})} className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none font-medium" />
                </div>

                <div className="pt-2 border-t border-slate-100">
                   <h4 className="text-sm font-bold text-slate-800 mb-4">Course Routine Information</h4>
                   <div className="space-y-4">
                     <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Routine Image URL (Optional)</label>
                        <input type="url" value={formData.routineImageUrl || ''} onChange={e => setFormData({...formData, routineImageUrl: e.target.value})} placeholder="https://..." className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none font-medium" />
                     </div>
                     <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Routine Text / Schedule</label>
                        <textarea rows={4} value={formData.routineText || ''} onChange={e => setFormData({...formData, routineText: e.target.value})} placeholder="e.g. Saturday 10:00 AM - Physics..." className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none font-medium resize-y" />
                     </div>
                   </div>
                </div>
                
                <div className="bg-indigo-50/50 p-4 rounded-2xl border border-indigo-100 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <input 
                      type="checkbox" 
                      id="isPromoted"
                      checked={formData.isPromoted} 
                      onChange={e => setFormData({ ...formData, isPromoted: e.target.checked })}
                      className="w-4 h-4 text-indigo-600 rounded border-gray-300 focus:ring-indigo-500 cursor-pointer"
                    />
                    <div className="flex flex-col">
                      <label htmlFor="isPromoted" className="text-xs font-bold text-indigo-950 uppercase tracking-wider cursor-pointer">Promote to top slider</label>
                      <span className="text-[10px] text-slate-500 font-medium">Highlight this course at the top slider of Student Portal</span>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-4">
                  <div className="flex items-center gap-3">
                    <input 
                      type="checkbox" 
                      id="isPaid"
                      checked={formData.isPaid} 
                      onChange={e => setFormData({ ...formData, isPaid: e.target.checked })}
                      className="w-4 h-4 text-indigo-600 rounded border-gray-300 focus:ring-indigo-500"
                    />
                    <label htmlFor="isPaid" className="text-sm font-bold text-slate-700 uppercase tracking-wider">Require Payment</label>
                  </div>
                  
                  {formData.isPaid && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Fee (৳)</label>
                        <input type="number" required={formData.isPaid} value={formData.feeAmount || ''} onChange={e => setFormData({...formData, feeAmount: parseInt(e.target.value) || 0})} className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none font-medium" />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Discount (৳)</label>
                        <input type="number" value={formData.discountAmount || ''} onChange={e => setFormData({...formData, discountAmount: parseInt(e.target.value) || 0})} className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none font-medium" />
                      </div>
                    </div>
                  )}
                </div>
              </form>
            </div>
            <div className="p-6 border-t border-slate-100 flex-none bg-slate-50">
               <button form="courseForm" type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-3.5 rounded-xl font-bold uppercase tracking-wider transition-all shadow-lg shadow-indigo-600/20">
                 Save Course
               </button>
            </div>
          </div>
        </div>
      )}

      <NoticeModal 
        isOpen={isNoticeModalOpen}
        onClose={() => setIsNoticeModalOpen(false)}
        courseName={courses.find(c => c.id === targetCourseId)?.title || ''}
        noticeForm={noticeForm}
        setNoticeForm={setNoticeForm}
        onSubmit={() => {
          if (targetCourseId) {
            createCourseNotice(targetCourseId, noticeForm);
            setIsNoticeModalOpen(false);
          }
        }}
      />
    </div>
  );
}

function NoticeModal({ isOpen, onClose, onSubmit, courseName, noticeForm, setNoticeForm }: any) {
  if (!isOpen) return null;
  
  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-[60] flex items-center justify-center p-4">
      <div className="bg-white max-w-lg w-full rounded-3xl overflow-hidden shadow-2xl relative animate-slideDown">
        <button onClick={onClose} className="absolute top-4 right-4 text-slate-400 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 p-2 rounded-full transition-colors"><X className="w-4 h-4" /></button>
        <div className="p-8 pb-6 border-b border-slate-100">
           <div className="w-12 h-12 bg-indigo-50 rounded-2xl flex items-center justify-center mb-4">
              <Bell className="w-6 h-6 text-indigo-600" />
           </div>
           <h2 className="text-2xl font-display font-bold text-slate-900">Send New Notice</h2>
           <p className="text-sm font-medium text-slate-500 mt-1">To students enrolled in: <span className="text-indigo-600 font-bold">{courseName}</span></p>
        </div>
        <form onSubmit={(e) => { e.preventDefault(); onSubmit(); }} className="p-8 space-y-5">
           <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Notice Title</label>
              <input 
                type="text" 
                required 
                value={noticeForm.title} 
                onChange={e => setNoticeForm({ ...noticeForm, title: e.target.value })} 
                placeholder="e.g. Schedule Change, Exam Alert..."
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none font-medium" 
              />
           </div>
           <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Notice Content</label>
              <textarea 
                required 
                rows={4} 
                value={noticeForm.message} 
                onChange={e => setNoticeForm({ ...noticeForm, message: e.target.value })} 
                placeholder="Details of your notice..."
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none font-medium resize-none shadow-inner"
              ></textarea>
           </div>
           <div className="pt-2">
              <button type="submit" className="w-full bg-slate-900 hover:bg-black text-white py-4 rounded-xl font-black uppercase tracking-widest transition-all shadow-xl shadow-slate-900/10 flex items-center justify-center gap-2">
                 <Send className="w-4 h-4" />
                 Send Notice to Students
              </button>
           </div>
        </form>
      </div>
    </div>
  );
}
