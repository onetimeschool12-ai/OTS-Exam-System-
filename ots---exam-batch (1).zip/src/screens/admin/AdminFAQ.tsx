import React, { useState } from 'react';
import { useStore } from '../../store/useStore';
import { Plus, Trash2, Edit2, Save, X } from 'lucide-react';
import { FAQ } from '../../types';

export default function AdminFAQ() {
  const { faqs, createFAQ, updateFAQ, deleteFAQ } = useStore();
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');

  const [editQuestion, setEditQuestion] = useState('');
  const [editAnswer, setEditAnswer] = useState('');

  const handleAdd = () => {
    if (question.trim() && answer.trim()) {
      createFAQ(question.trim(), answer.trim());
      setQuestion('');
      setAnswer('');
      setIsAdding(false);
    }
  };

  const startEdit = (faq: FAQ) => {
    setEditingId(faq.id);
    setEditQuestion(faq.question);
    setEditAnswer(faq.answer);
  };

  const handleSaveEdit = (id: string) => {
    if (editQuestion.trim() && editAnswer.trim()) {
      updateFAQ(id, { question: editQuestion.trim(), answer: editAnswer.trim() });
      setEditingId(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-black text-slate-800">FAQ Management</h2>
          <p className="text-sm font-semibold text-slate-500 mt-1">Manage frequently asked questions completely.</p>
        </div>
        {!isAdding && (
          <button
            onClick={() => setIsAdding(true)}
            className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-xl text-sm font-bold shadow-sm shadow-indigo-600/20 hover:bg-indigo-700 transition-colors"
          >
            <Plus className="w-4 h-4" />
            Add FAQ
          </button>
        )}
      </div>

      {isAdding && (
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200">
          <h3 className="text-lg font-bold text-slate-900 mb-4">New FAQ</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Question</label>
              <input
                type="text"
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder="e.g. How to access my exam?"
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none font-semibold text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Answer</label>
              <textarea
                value={answer}
                onChange={(e) => setAnswer(e.target.value)}
                rows={4}
                placeholder="Enter detailed answer..."
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none font-semibold text-sm resize-y"
              />
            </div>
            <div className="flex gap-3 justify-end pt-2">
              <button
                onClick={() => setIsAdding(false)}
                className="px-4 py-2 shadow-sm border border-slate-200 bg-white text-slate-700 rounded-xl text-sm font-bold hover:bg-slate-50"
              >
                Cancel
              </button>
              <button
                onClick={handleAdd}
                disabled={!question.trim() || !answer.trim()}
                className="px-4 py-2 bg-indigo-600 shadow-sm shadow-indigo-600/20 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-xl text-sm font-bold hover:bg-indigo-700"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="space-y-4">
        {faqs?.length === 0 ? (
          <div className="p-12 text-center text-slate-500 font-semibold bg-white rounded-3xl border border-slate-200 shadow-sm border-dashed">
            No FAQs added yet.
          </div>
        ) : (
          faqs?.map(faq => (
            <div key={faq.id} className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200 transition-all hover:border-slate-300">
              {editingId === faq.id ? (
                <div className="space-y-4">
                  <div>
                    <label className="block text-[10px] uppercase tracking-widest font-bold text-slate-400 mb-1">Edit Question</label>
                    <input
                      type="text"
                      value={editQuestion}
                      onChange={(e) => setEditQuestion(e.target.value)}
                      className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none font-semibold text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] uppercase tracking-widest font-bold text-slate-400 mb-1">Edit Answer</label>
                    <textarea
                      value={editAnswer}
                      onChange={(e) => setEditAnswer(e.target.value)}
                      rows={4}
                      className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none font-semibold text-sm"
                    />
                  </div>
                  <div className="flex gap-2 justify-end pt-2">
                    <button
                      onClick={() => setEditingId(null)}
                      className="p-2 border border-slate-200 bg-white text-slate-500 rounded-lg shrink-0 hover:bg-slate-50"
                    >
                      <X className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleSaveEdit(faq.id)}
                      disabled={!editQuestion.trim() || !editAnswer.trim()}
                      className="px-4 py-2 bg-emerald-600 disabled:opacity-50 text-white rounded-lg text-sm font-bold hover:bg-emerald-700 flex items-center gap-2"
                    >
                      <Save className="w-4 h-4" />
                      Save Changes
                    </button>
                  </div>
                </div>
              ) : (
                <div>
                  <div className="flex items-start justify-between gap-4">
                    <h3 className="text-base font-bold text-slate-800">{faq.question}</h3>
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => startEdit(faq)}
                        className="p-1.5 text-slate-400 hover:text-indigo-600 transition-colors"
                        title="Edit FAQ"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => {
                          if (confirm('Are you sure you want to delete this FAQ?')) {
                            deleteFAQ(faq.id);
                          }
                        }}
                        className="p-1.5 text-slate-400 hover:text-rose-600 transition-colors"
                        title="Delete FAQ"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                  <div className="mt-2 text-sm text-slate-500 leading-relaxed font-medium whitespace-pre-wrap">
                    {faq.answer}
                  </div>
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
