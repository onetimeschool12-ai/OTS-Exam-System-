import React, { useState } from 'react';
import { useStore } from '../../store/useStore';
import { Plus, Edit2, Trash2, Clock, Users } from 'lucide-react';
import { Link } from 'react-router-dom';
import { format } from 'date-fns';

export default function AdminExams() {
  const { exams, deleteExam, updateExam } = useStore();
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  return (
    <div>
      <div className="flex sm:items-center justify-between flex-col sm:flex-row gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-display font-bold text-slate-900 tracking-tight">Manage Exams</h1>
          <p className="text-slate-500 text-sm mt-1 font-medium">Create, edit, and organize online tests</p>
        </div>
        <Link 
          to="/admin/exams/new" 
          className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-xl text-sm font-bold transition-colors flex items-center justify-center gap-2 shadow-md shadow-indigo-200"
        >
          <Plus className="w-4 h-4" /> Create Exam
        </Link>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-[10px] uppercase tracking-widest font-bold text-slate-500">
                <th className="py-4 px-6">Title & Subject</th>
                <th className="py-4 px-6">Schedule</th>
                <th className="py-4 px-6">Questions</th>
                <th className="py-4 px-6">Status</th>
                <th className="py-4 px-6 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {exams.map(exam => {
                const isActive = Date.now() >= exam.startTime && Date.now() <= exam.endTime;
                
                return (
                  <tr key={exam.id} className="hover:bg-slate-50/50 transition-colors group">
                    <td className="py-4 px-6">
                      <div className="font-bold text-slate-900 text-sm mb-1">{exam.title}</div>
                      <div className="text-[10px] font-bold text-indigo-600 uppercase tracking-wider">
                        {exam.category}{exam.subCategory ? ` / ${exam.subCategory}` : ''} • {exam.subject}
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-700">
                        <Clock className="w-3.5 h-3.5 text-slate-400" /> 
                        {format(exam.startTime, 'MMM d, h:mm a')}
                      </div>
                      <div className="text-[10px] font-bold text-slate-400 mt-1 uppercase tracking-widest">{exam.durationMinutes} mins</div>
                    </td>
                    <td className="py-4 px-6 text-sm font-medium text-slate-700">
                      {exam.questions.length} <span className="text-slate-400">Qs</span>
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex flex-col gap-1 items-start">
                        {isActive ? (
                          <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-rose-50 text-rose-600 uppercase tracking-widest mb-1">
                            Live
                          </span>
                        ) : (
                          <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-600 uppercase tracking-widest mb-1">
                            {exam.status === 'draft' ? 'Draft' : 'Scheduled'}
                          </span>
                        )}
                        <span className={`inline-flex items-center px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider ${exam.examType === 'practice' ? 'bg-amber-50 text-amber-600 border border-amber-100' : 'bg-indigo-50 text-indigo-600 border border-indigo-100'}`}>
                          {exam.examType === 'practice' ? 'Practice' : 'Live Exam'}
                        </span>
                        {exam.examType !== 'practice' && (
                          <span className={`text-[9px] font-bold mt-1 uppercase tracking-wider ${exam.resultsPublished !== false ? 'text-emerald-600' : 'text-slate-400'}`}>
                            {exam.resultsPublished !== false ? '● Results Live' : '○ Results Held'}
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="py-4 px-6 text-right">
                      <div className="flex items-center justify-end gap-2">
                        {exam.examType !== 'practice' && exam.publishType === 'manual' && (
                          <button 
                            onClick={() => {
                              updateExam(exam.id, { resultsPublished: !exam.resultsPublished });
                            }}
                            title={exam.resultsPublished ? "Hold Leaderboard" : "Release Leaderboard"}
                            className={`px-3 py-1.5 rounded-lg transition-colors border text-[10px] font-bold uppercase tracking-widest ${exam.resultsPublished !== false ? 'text-amber-700 bg-amber-50 hover:bg-amber-100 border-amber-200' : 'text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border-emerald-200'}`}
                          >
                            {exam.resultsPublished !== false ? 'Hold' : 'Release'}
                          </button>
                        )}
                        <button 
                          onClick={() => {
                             updateExam(exam.id, { status: exam.status === 'draft' ? 'published' : 'draft' });
                          }}
                          title={exam.status === 'draft' ? "Publish Exam" : "Move to Draft"}
                          className={`p-2 rounded-lg transition-colors border ${exam.status === 'draft' ? 'text-indigo-600 bg-indigo-50 hover:bg-indigo-100 border-indigo-100' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-100 border-transparent'}`}
                        >
                          <span className="text-[10px] font-bold uppercase tracking-widest">{exam.status === 'draft' ? 'Publish' : 'Unpublish'}</span>
                        </button>
                        <Link 
                          to={`/admin/exams/${exam.id}/edit`}
                          className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors border border-transparent hover:border-indigo-100"
                        >
                          <Edit2 className="w-4 h-4" />
                        </Link>
                        {confirmDeleteId === exam.id ? (
                          <div className="flex items-center gap-1.5 bg-rose-50 border border-rose-100 px-2 py-1 rounded-lg animate-in fade-in zoom-in-95 duration-200">
                            <span className="text-[9px] font-black text-rose-800 uppercase px-1">Confirm?</span>
                            <button 
                              onClick={() => {
                                deleteExam(exam.id);
                                setConfirmDeleteId(null);
                              }}
                              className="px-2 py-0.5 bg-rose-600 hover:bg-rose-700 text-white rounded text-[9px] font-black uppercase tracking-wider transition-all"
                            >
                              Yes
                            </button>
                            <button 
                              onClick={() => setConfirmDeleteId(null)}
                              className="px-2 py-0.5 bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 rounded text-[9px] font-black uppercase tracking-wider transition-all"
                            >
                              No
                            </button>
                          </div>
                        ) : (
                          <button 
                            onClick={() => setConfirmDeleteId(exam.id)}
                            className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors border border-transparent hover:border-rose-100"
                            title="Delete Exam"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
              {exams.length === 0 && (
                <tr>
                  <td colSpan={5} className="py-12 text-center text-slate-500 font-medium">
                    No exams found. Click "Create Exam" to get started.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
