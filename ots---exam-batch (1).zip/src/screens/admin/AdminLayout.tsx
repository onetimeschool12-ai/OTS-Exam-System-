import React from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { LayoutDashboard, FileText, Users, Trophy, LogOut, GraduationCap, Menu, X, Calendar, BookOpen, Tags, HelpCircle } from 'lucide-react';
import { useStore } from '../../store/useStore';

export default function AdminLayout() {
  const navigate = useNavigate();
  const logout = useStore(state => state.logout);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const navItems = [
    { to: '/admin', end: true, icon: LayoutDashboard, label: 'Dashboard' },
    { to: '/admin/courses', icon: BookOpen, label: 'Manage Courses' },
    { to: '/admin/categories', icon: Tags, label: 'Manage Categories' },
    { to: '/admin/exams', icon: FileText, label: 'Manage Exams' },
    { to: '/admin/events', icon: Calendar, label: 'Manage Events' },
    { to: '/admin/users', icon: Users, label: 'Users' },
    { to: '/admin/payments', icon: Trophy, label: 'Payments' },
    { to: '/admin/leaderboard', icon: Trophy, label: 'Leaderboard' },
    { to: '/admin/faqs', icon: HelpCircle, label: 'Manage FAQs' },
  ];

  const SidebarContent = () => (
    <>
      <div className="p-6 flex flex-col h-full bg-white">
        <div className="flex items-center gap-3 mb-10">
          <img 
            src="https://i.postimg.cc/h40vHdRJ/IMG-20260217-WA0010.jpg" 
            alt="OTS Logo" 
            referrerPolicy="no-referrer"
            className="w-10 h-10 object-cover rounded-xl border border-slate-100 shadow-sm"
          />
          <div className="flex flex-col">
            <span className="font-bold text-lg leading-tight tracking-tight text-slate-900 font-display">OTS EXAM</span>
            <span className="text-[10px] text-slate-400 font-semibold tracking-widest uppercase">Admin Panel</span>
          </div>
        </div>
        
        <nav className="flex-1 space-y-2">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              onClick={() => setIsMobileMenuOpen(false)}
              className={({ isActive }) => 
                `flex items-center gap-3 px-3 py-3 rounded-xl text-sm font-semibold transition-colors ${
                  isActive 
                    ? 'bg-indigo-50 text-indigo-700' 
                    : 'text-slate-500 hover:bg-slate-100'
                }`
              }
            >
              <item.icon className="h-5 w-5" />
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="mt-auto p-4 bg-slate-900 rounded-2xl text-white">
          <p className="text-[10px] text-slate-400 uppercase font-bold tracking-widest mb-1">Admin Zone</p>
          <p className="text-xs mb-3 text-slate-300 font-medium">Restricted access</p>
          <button
            onClick={handleLogout}
            className="w-full py-2 bg-rose-500 hover:bg-rose-600 border border-rose-600 rounded-lg text-xs font-bold transition-colors flex justify-center items-center gap-2"
          >
            <LogOut className="h-4 w-4" /> Sign Out
          </button>
        </div>
      </div>
    </>
  );

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-64 bg-white border-r border-slate-200 shrink-0 sticky top-0 h-screen">
        <SidebarContent />
      </aside>

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-40 bg-slate-900/80 backdrop-blur-sm md:hidden" onClick={() => setIsMobileMenuOpen(false)} />
      )}
      
      {/* Mobile Sidebar */}
      <aside className={`fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-2xl transform transition-transform duration-300 md:hidden ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <SidebarContent />
      </aside>

      <main className="flex-1 flex flex-col min-w-0 h-screen overflow-y-auto">
        <header className="bg-white border-b border-slate-200 px-6 py-4 flex items-center shrink-0 md:hidden sticky top-0 z-30">
          <button 
            onClick={() => setIsMobileMenuOpen(true)}
            className="text-slate-500 hover:text-slate-900 mr-4"
          >
            <Menu className="h-6 w-6" />
          </button>
          <div className="flex items-center gap-2">
            <img 
              src="https://i.postimg.cc/h40vHdRJ/IMG-20260217-WA0010.jpg" 
              alt="OTS Logo" 
              referrerPolicy="no-referrer"
              className="w-8 h-8 object-cover rounded-lg border border-slate-100 shadow-sm"
            />
            <div className="font-bold text-slate-900 text-base tracking-tight">OTS Admin</div>
          </div>
        </header>

        <div className="p-6 sm:p-10 flex-1">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
