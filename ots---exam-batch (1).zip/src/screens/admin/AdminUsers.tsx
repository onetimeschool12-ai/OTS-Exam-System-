import React, { useState } from 'react';
import { useStore } from '../../store/useStore';
import { Shield, Unlock } from 'lucide-react';
import { format } from 'date-fns';

export default function AdminUsers() {
  const { users, toggleUserStatus, currentUser, revokeCourseAccess, revokeEventAccess, deleteUser, courses, events } = useStore();
  const [confirmUserId, setConfirmUserId] = useState<string | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [expandedUserId, setExpandedUserId] = useState<string | null>(null);
  
  const students = users.filter(u => u.role === 'user');

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-display font-bold text-slate-900 tracking-tight">User Management</h1>
        <p className="text-slate-500 text-sm mt-1 font-medium">Control access and monitor registered students</p>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-[10px] uppercase tracking-widest font-bold text-slate-500">
                <th className="py-4 px-6">Name</th>
                <th className="py-4 px-6">Email</th>
                <th className="py-4 px-6">Status</th>
                <th className="py-4 px-6 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {students.map(user => (
                <React.Fragment key={user.id}>
                <tr className="hover:bg-slate-50/50 transition-colors group">
                  <td className="py-4 px-6 font-bold text-slate-900">{user.name}</td>
                  <td className="py-4 px-6 text-slate-600 text-sm font-medium">{user.email}</td>
                  <td className="py-4 px-6">
                    {user.status === 'active' ? (
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-600 uppercase tracking-widest">
                        Active
                      </span>
                    ) : (
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-rose-50 text-rose-600 uppercase tracking-widest">
                        Blocked
                      </span>
                    )}
                  </td>
                  <td className="py-4 px-6 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button 
                        onClick={() => setExpandedUserId(expandedUserId === user.id ? null : user.id)}
                        className="text-xs px-3 py-1.5 rounded-lg font-bold text-slate-600 hover:bg-slate-100 border border-transparent uppercase tracking-wider"
                      >
                        {expandedUserId === user.id ? 'Hide Access' : 'Manage Access'}
                      </button>
                      {user.id !== currentUser?.id && (
                        <>
                        {confirmUserId === user.id ? (
                          <div className="flex items-center gap-1 bg-rose-50 border border-rose-100 px-2 py-1 rounded-lg">
                            <span className="text-[9px] font-black text-rose-800 uppercase px-1">Confirm?</span>
                            <button 
                              onClick={() => {
                                toggleUserStatus(user.id);
                                setConfirmUserId(null);
                              }}
                              className="px-2 py-0.5 bg-rose-600 hover:bg-rose-700 text-white rounded text-[9px] font-black uppercase tracking-wider transition-all"
                            >
                              Yes
                            </button>
                            <button 
                              onClick={() => setConfirmUserId(null)}
                              className="px-2 py-0.5 bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 rounded text-[9px] font-black uppercase tracking-wider transition-all"
                            >
                              No
                            </button>
                          </div>
                        ) : (
                          <button 
                            onClick={() => setConfirmUserId(user.id)}
                            className={`text-xs px-3 py-1.5 rounded-lg font-bold transition-colors uppercase tracking-wider ${
                              user.status === 'active' 
                                ? 'text-rose-600 hover:bg-rose-50 border border-transparent hover:border-rose-100' 
                                : 'text-emerald-600 hover:bg-emerald-50 border border-transparent hover:border-emerald-100'
                            }`}
                          >
                            {user.status === 'active' ? 'Block Access' : 'Unblock Access'}
                          </button>
                        )}
                        {confirmDeleteId === user.id ? (
                          <div className="flex items-center gap-1 bg-red-100 border border-red-200 px-2 py-1 rounded-lg">
                            <span className="text-[9px] font-black text-red-900 uppercase px-1">Delete?</span>
                            <button 
                              onClick={() => {
                                deleteUser(user.id);
                                setConfirmDeleteId(null);
                              }}
                              className="px-2 py-0.5 bg-red-600 hover:bg-red-700 text-white rounded text-[9px] font-black uppercase tracking-wider transition-all"
                            >
                              Yes
                            </button>
                            <button 
                              onClick={() => setConfirmDeleteId(null)}
                              className="px-2 py-0.5 bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 rounded text-[9px] font-black uppercase tracking-wider transition-all"
                            >
                              No
                            </button>
                          </div>
                        ) : (
                          <button 
                            onClick={() => setConfirmDeleteId(user.id)}
                            className="text-[10px] px-2 py-1 rounded border border-red-200 text-red-600 font-black hover:bg-red-50 uppercase tracking-wider"
                          >
                            Delete User
                          </button>
                        )}
                        </>
                      )}
                    </div>
                  </td>
                </tr>
                {expandedUserId === user.id && (
                    <tr className="bg-slate-50/50">
                        <td colSpan={4} className="py-4 px-6">
                            <div className="text-xs font-bold text-slate-700 mb-2">Enrolled Courses:</div>
                            <div className="flex flex-wrap gap-2 mb-4">
                                {(user.enrolledCourses || []).map(cid => {
                                    const course = courses.find(c => c.id === cid);
                                    return course && (
                                        <div key={cid} className="flex items-center gap-2 bg-white px-2 py-1 rounded border border-slate-200">
                                            <span className="text-xs text-slate-600">{course.title}</span>
                                            <button onClick={() => revokeCourseAccess(user.id, cid)} className="text-[10px] text-rose-600 font-black">Revoke</button>
                                        </div>
                                    )
                                })}
                                {(user.enrolledCourses || []).length === 0 && <span className="text-xs text-slate-400">No courses.</span>}
                            </div>
                            <div className="text-xs font-bold text-slate-700 mb-2">Joined Events:</div>
                            <div className="flex flex-wrap gap-2">
                                {(user.joinedEvents || []).map(eid => {
                                    const event = events.find(e => e.id === eid);
                                    return event && (
                                        <div key={eid} className="flex items-center gap-2 bg-white px-2 py-1 rounded border border-slate-200">
                                            <span className="text-xs text-slate-600">{event.title}</span>
                                            <button onClick={() => revokeEventAccess(user.id, eid)} className="text-[10px] text-rose-600 font-black">Revoke</button>
                                        </div>
                                    )
                                })}
                                {(user.joinedEvents || []).length === 0 && <span className="text-xs text-slate-400">No events.</span>}
                            </div>
                        </td>
                    </tr>
                )}
                </React.Fragment>
              ))}
              {students.length === 0 && (
                <tr>
                  <td colSpan={4} className="py-12 text-center text-slate-500 font-medium">
                    No users found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
