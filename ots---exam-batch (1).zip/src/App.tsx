import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useStore } from './store/useStore';
import Landing from './screens/Landing';
import AdminLogin from './screens/AdminLogin';
import StudentDashboard from './screens/student/StudentDashboard';
import StudentProfile from './screens/student/StudentProfile';
import ExamView from './screens/student/ExamView';
import ResultView from './screens/student/ResultView';
import AdminLayout from './screens/admin/AdminLayout';
import AdminDashboard from './screens/admin/AdminDashboard';
import AdminExams from './screens/admin/AdminExams';
import AdminExamForm from './screens/admin/AdminExamForm';
import AdminUsers from './screens/admin/AdminUsers';
import AdminLeaderboard from './screens/admin/AdminLeaderboard';
import AdminEvents from './screens/admin/AdminEvents';
import AdminCourses from './screens/admin/AdminCourses';
import AdminCategories from './screens/admin/AdminCategories';
import AdminPayments from './screens/admin/AdminPayments';
import AdminFAQ from './screens/admin/AdminFAQ';

export default function App() {
  const currentUser = useStore(state => state.currentUser);
  const checkUpcomingExams = useStore(state => state.checkUpcomingExams);

  React.useEffect(() => {
    if (currentUser?.role === 'user') {
      // Check immediately
      checkUpcomingExams();
      
      // Check every 5 minutes
      const interval = setInterval(() => {
        checkUpcomingExams();
      }, 5 * 60 * 1000);

      return () => clearInterval(interval);
    }
  }, [currentUser, checkUpcomingExams]);

  return (
    <BrowserRouter>
      <div className="min-h-screen bg-slate-50 text-slate-800 font-sans selection:bg-indigo-100 selection:text-indigo-900">
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/admin-login" element={<AdminLogin />} />
          
          {/* Admin Routes */}
          <Route path="/admin/*" element={
            currentUser?.role === 'admin' ? (
              <AdminLayout />
            ) : (
              <Navigate to="/admin-login" />
            )
          }>
             <Route index element={<AdminDashboard />} />
             <Route path="exams" element={<AdminExams />} />
             <Route path="exams/new" element={<AdminExamForm />} />
             <Route path="exams/:id/edit" element={<AdminExamForm />} />
             <Route path="events" element={<AdminEvents />} />
             <Route path="users" element={<AdminUsers />} />
             <Route path="payments" element={<AdminPayments />} />
             <Route path="courses" element={<AdminCourses />} />
             <Route path="categories" element={<AdminCategories />} />
             <Route path="leaderboard" element={<AdminLeaderboard />} />
             <Route path="faqs" element={<AdminFAQ />} />
          </Route>

          {/* Student Routes */}
          <Route path="/student/*" element={
            currentUser?.role === 'user' ? (
              <Routes>
                 <Route index element={<StudentDashboard />} />
                 <Route path="profile" element={<StudentProfile />} />
                 <Route path="exam/:id" element={<ExamView />} />
                 <Route path="result/:id" element={<ResultView />} />
                 <Route path="*" element={<Navigate to="/student" />} />
              </Routes>
            ) : (
              <Navigate to="/" />
            )
          } />
          
        </Routes>
      </div>
    </BrowserRouter>
  );
}
