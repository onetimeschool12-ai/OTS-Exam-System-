export type Role = 'user' | 'admin';

export interface UserProfile {
  photoUrl?: string;
  mobile?: string;
  emergencyContact?: string;
  dateOfBirth?: string;
  religion?: string;
  gender?: string;
  bloodGroup?: string;
  group?: string; // Science, Arts, Commerce
  collegeName?: string;
  collegeAddress?: string;
  collegeSession?: string;
  universityChance?: string;
  fatherName?: string;
  fatherNid?: string;
  fatherProfession?: string;
  fatherProfessionType?: string;
  fatherYearlyIncome?: string;
  motherName?: string;
  motherNid?: string;
  motherProfession?: string;
  motherProfessionType?: string;
  motherYearlyIncome?: string;
  previousSchoolName?: string;
  disability?: string;
  guardianMobile?: string;
  presentAddress?: {
    division?: string;
    district?: string;
    upazila?: string;
    union?: string;
    postOffice?: string;
    village?: string;
    house?: string;
  };
  permanentAddress?: {
    division?: string;
    district?: string;
    upazila?: string;
    union?: string;
    postOffice?: string;
    village?: string;
    house?: string;
  };
  jscInfo?: {
    rollNo?: string;
    regNo?: string;
    board?: string;
    gpa?: string;
    year?: string;
  };
  sscInfo?: {
    rollNo?: string;
    regNo?: string;
    board?: string;
    gpa?: string;
    year?: string;
  };
  hscInfo?: {
    rollNo?: string;
    regNo?: string;
    board?: string;
    gpa?: string;
    year?: string;
  };
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  status: 'active' | 'blocked';
  createdAt: number;
  enrolledCourses?: string[];
  joinedEvents?: string[];
  profile?: UserProfile;
}

export interface Question {
  id: string;
  text: string;
  options: string[];
  correctOptionIndex: number;
  marks?: number;
}

export interface Exam {
  id: string;
  title: string;
  description: string;
  thumbnailUrl: string;
  subject: string;
  category: string;
  subCategory?: string;
  durationMinutes: number;
  startTime: number;
  endTime: number;
  questions: Question[];
  status: 'draft' | 'published' | 'completed';
  createdAt: number;
  // Payment fields
  isPaid?: boolean;
  feeAmount?: number;
  discountAmount?: number;
  // Access Control
  accessType?: 'public' | 'private' | 'course' | 'event';
  courseIds?: string[];
  eventIds?: string[];
  // Negative marking
  hasNegativeMarking?: boolean;
  negativeMarksPerWrongAnswer?: number;
  // Custom Instructions
  instructionsBn?: string;
  instructionsEn?: string;
  // Automatic leaderboards & types
  examType?: 'live' | 'practice';
  publishType?: 'instant' | 'manual';
  resultsPublished?: boolean;
}

export interface ExamResult {
  id: string;
  examId: string;
  userId: string;
  score: number;
  totalQuestions: number;
  correctAnswers: number;
  wrongAnswers: number;
  accuracy: number;
  submittedAt: number;
  answers: Record<string, number>; // questionId -> optionIndex
  timeTakenSeconds?: number;
  tabCorrectionCount?: number;
  attemptType?: 'live' | 'practice';
}

export interface AppEvent {
  id: string;
  title: string;
  description: string;
  date: number;
  location?: string;
  bannerUrl?: string;
  createdAt: number;
  // Payment fields
  isPaid?: boolean;
  feeAmount?: number;
  discountAmount?: number;
  isPromoted?: boolean;
}

export interface PaymentConfig {
  bkash: string;
  nagad: string;
  rocket: string;
  youtubeUrl?: string;
}

export interface PaymentRecord {
  id: string;
  userId: string;
  targetId: string;
  targetType: 'exam' | 'event' | 'course';
  amount: number;
  method: 'bkash' | 'nagad' | 'rocket';
  trxId: string;
  proofUrl?: string;
  status: 'pending' | 'verified' | 'rejected';
  createdAt: number;
  verifiedAt?: number;
}

export interface Category {
  id: string;
  name: string;
  subCategories: string[];
}

export interface Course {
  id: string;
  title: string;
  description: string;
  category: string;
  subCategory?: string;
  bannerUrl?: string;
  createdAt: number;
  isPaid?: boolean;
  feeAmount?: number;
  discountAmount?: number;
  isPromoted?: boolean;
  routineText?: string;
  routineImageUrl?: string;
  notices?: CourseNotice[];
}

export interface CourseNotice {
  id: string;
  title: string;
  message: string;
  createdAt: number;
}

export interface FAQ {
  id: string;
  question: string;
  answer: string;
  order?: number;
}

export interface AppNotification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'exam_upcoming' | 'course_notice' | 'course_exam' | 'system';
  targetId?: string; // e.g. examId or courseId
  isRead: boolean;
  createdAt: number;
}

export interface AppState {
  users: User[];
  exams: Exam[];
  events: AppEvent[];
  courses: Course[];
  results: ExamResult[];
  payments: PaymentRecord[];
  paymentConfig: PaymentConfig;
  currentUser: User | null;
  categories: Category[];
  faqs: FAQ[];
  notifications: AppNotification[];
}
