import React from 'react';
import { AlertTriangle, X } from 'lucide-react';

interface Props {
  isOpen: boolean;
  total: number;
  answered: number;
  unanswered: number;
  markedForReview: number;
  onCancel: () => void;
  onConfirm: () => void;
}

export function SubmitConfirmationModal({ isOpen, total, answered, unanswered, markedForReview, onCancel, onConfirm }: Props) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm" onClick={onCancel}></div>
      <div className="relative bg-white w-full max-w-sm rounded-3xl p-6 shadow-2xl border border-slate-100 animate-in fade-in zoom-in duration-300">
        <button className="absolute top-4 right-4 text-slate-400 hover:text-slate-600" onClick={onCancel}>
          <X className="w-5 h-5" />
        </button>
        <div className="flex flex-col items-center text-center">
            <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mb-4">
                <AlertTriangle className="w-8 h-8 text-amber-600" />
            </div>
            <h2 className="text-2xl font-black text-slate-900 mb-6">Are you sure?</h2>
            
            <div className="w-full space-y-3 mb-8">
                <div className="flex justify-between p-3 bg-slate-50 rounded-xl">
                    <span className="font-bold text-slate-600">Total Questions</span>
                    <span className="font-black text-slate-900">{total}</span>
                </div>
                <div className="flex justify-between p-3 bg-emerald-50 rounded-xl">
                    <span className="font-bold text-emerald-700">Answered</span>
                    <span className="font-black text-emerald-900">{answered}</span>
                </div>
                <div className="flex justify-between p-3 bg-rose-50 rounded-xl">
                    <span className="font-bold text-rose-700">Unanswered</span>
                    <span className="font-black text-rose-900">{unanswered}</span>
                </div>
                <div className="flex justify-between p-3 bg-indigo-50 rounded-xl">
                    <span className="font-bold text-indigo-700">Marked For Review</span>
                    <span className="font-black text-indigo-900">{markedForReview}</span>
                </div>
            </div>

            <div className="flex gap-3 w-full">
                <button onClick={onCancel} className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl font-bold transition-all uppercase tracking-wider text-xs">Cancel</button>
                <button onClick={onConfirm} className="flex-1 py-3 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-bold transition-all uppercase tracking-wider text-xs shadow-lg shadow-rose-600/20">Submit</button>
            </div>
        </div>
      </div>
    </div>
  );
}
