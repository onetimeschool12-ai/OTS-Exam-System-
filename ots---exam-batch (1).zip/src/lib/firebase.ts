import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyB7NIQrn7l6PWk-7HGjvZcO8aTGcKU1e44",
  authDomain: "ots---exam-system.firebaseapp.com",
  databaseURL: "https://ots---exam-system-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "ots---exam-system",
  storageBucket: "ots---exam-system.firebasestorage.app",
  messagingSenderId: "446665491206",
  appId: "1:446665491206:web:98630b2c8c5ee4bf641487",
  measurementId: "G-GBFPR25JH1"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const auth = getAuth(app);
