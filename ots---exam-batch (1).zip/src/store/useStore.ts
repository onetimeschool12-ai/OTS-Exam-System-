import { create } from 'zustand';
import { persist, createJSONStorage, StateStorage } from 'zustand/middleware';
import { get, set as idbSet, del } from 'idb-keyval';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth'; // Import functions
import { auth } from '../lib/firebase'; // Import auth
import { AppState, User, Exam, ExamResult, Question, AppEvent, PaymentRecord, PaymentConfig, Course, UserProfile, Category, FAQ, AppNotification, CourseNotice } from '../types';

const idbStorage: StateStorage = {
  getItem: async (name: string): Promise<string | null> => {
    const value = await get(name);
    if (!value) {
      const fallback = localStorage.getItem(name);
      if (fallback) {
        // Migrate it to IDB
        await idbSet(name, fallback);
        return fallback;
      }
    }
    return value || null;
  },
  setItem: async (name: string, value: string): Promise<void> => {
    await idbSet(name, value);
    try {
      localStorage.removeItem(name);
    } catch(e) {}
  },
  removeItem: async (name: string): Promise<void> => {
    await del(name);
  },
};

interface StoreActions {
  login: (email: string, password: string, role?: 'user' | 'admin') => Promise<{ success: boolean; message?: string }>;
  loginAdmin: (email: string) => void;
  logout: () => void;
  register: (name: string, email: string, password: string) => Promise<{ success: boolean; message?: string }>;
  
  // Admin Exam Actions
  createExam: (exam: Omit<Exam, 'id' | 'createdAt'>) => void;
  updateExam: (id: string, exam: Partial<Exam>) => void;
  deleteExam: (id: string) => void;
  
  // Events Actions
  createEvent: (event: Omit<AppEvent, 'id' | 'createdAt'>) => void;
  updateEvent: (id: string, event: Partial<AppEvent>) => void;
  deleteEvent: (id: string) => void;
  
  // Courses Actions
  createCourse: (course: Omit<Course, 'id' | 'createdAt'>) => void;
  updateCourse: (id: string, course: Partial<Course>) => void;
  deleteCourse: (id: string) => void;
  createCourseNotice: (courseId: string, notice: Omit<CourseNotice, 'id' | 'createdAt'>) => void;
  
  // Payment Actions
  updatePaymentConfig: (config: PaymentConfig) => void;
  submitPayment: (payment: Omit<PaymentRecord, 'id' | 'status' | 'createdAt'>) => void;
  updatePaymentStatus: (id: string, status: 'verified' | 'rejected') => void;
  
  // Categories Actions
  createCategory: (name: string) => void;
  deleteCategory: (id: string) => void;
  addSubCategory: (categoryId: string, subCategoryName: string) => void;
  deleteSubCategory: (categoryId: string, subCategoryName: string) => void;
  
  // FAQ Actions
  createFAQ: (question: string, answer: string, order?: number) => void;
  updateFAQ: (id: string, faq: Partial<FAQ>) => void;
  deleteFAQ: (id: string) => void;
  
  // User Actions
  submitExamOption: (result: Omit<ExamResult, 'id' | 'submittedAt'>) => void;
  toggleUserStatus: (userId: string) => void;
  enrollInCourse: (userId: string, courseId: string) => boolean;
  revokeCourseAccess: (userId: string, courseId: string) => void;
  joinEvent: (userId: string, eventId: string) => boolean;
  revokeEventAccess: (userId: string, eventId: string) => void;
  deleteUser: (userId: string) => void;
  updateProfile: (userId: string, profile: Partial<UserProfile>) => void;
  
  // Notification Actions
  addNotification: (notification: Omit<AppNotification, 'id' | 'isRead' | 'createdAt'>) => void;
  markNotificationAsRead: (id: string) => void;
  clearNotifications: () => void;
  checkUpcomingExams: () => void;
}

const mockExams: Exam[] = [
  {
    id: 'exam_1',
    title: 'Mid-term Mathematics Challenge',
    description: 'Comprehensive test covering Algebra and Geometry.',
    thumbnailUrl: 'https://images.unsplash.com/photo-1632559648939-f9c34fbc87a1?w=400&q=80',
    subject: 'Math',
    category: 'Class 10',
    durationMinutes: 30,
    startTime: Date.now() - 3600000, // 1 hour ago
    endTime: Date.now() + 86400000, // tomorrow
    status: 'published',
    createdAt: Date.now(),
    accessType: 'course',
    courseIds: ['course_acs_varsity'],
    questions: [
      {
        id: 'q1',
        text: 'What is 5 x 7?',
        options: ['12', '35', '45', '25'],
        correctOptionIndex: 1,
      },
      {
        id: 'q2',
        text: 'Solve for x: 2x + 5 = 15',
        options: ['5', '10', '15', '20'],
        correctOptionIndex: 0,
      }
    ]
  },
  {
    id: 'exam_2',
    title: 'Physics Fundamentals Quiz',
    description: 'Basic concepts of motion and force.',
    thumbnailUrl: 'https://images.unsplash.com/photo-1636466497217-26a8cbeaf0aa?w=400&q=80',
    subject: 'Physics',
    category: 'Class 9',
    durationMinutes: 45,
    startTime: Date.now() - 1800000, // 30 mins ago
    endTime: Date.now() + 172800000, 
    status: 'published',
    createdAt: Date.now(),
    accessType: 'course',
    courseIds: ['course_goalhackers'],
    questions: [
      {
        id: 'qp1',
        text: 'Which Newton law is the inertia law?',
        options: ['First Law', 'Second Law', 'Third Law', 'None'],
        correctOptionIndex: 0
      }
    ]
  },
  {
    id: 'exam_3',
    title: 'Engineering Physics & Mechanics Test',
    description: 'Advanced assessment for Olympiad level vector evaluation.',
    thumbnailUrl: 'https://images.unsplash.com/photo-1607988795691-3d0147b43231?w=400&q=80',
    subject: 'Physics',
    category: 'Engineering',
    durationMinutes: 20,
    startTime: Date.now() - 600000,
    endTime: Date.now() + 6400000,
    status: 'published',
    createdAt: Date.now(),
    accessType: 'event',
    eventIds: ['event_physics_camp'],
    questions: [
      {
        id: 'qep1',
        text: 'If vectors A and B are perpendicular, what is their dot product?',
        options: ['1', '0', '-1', 'Undefined'],
        correctOptionIndex: 1
      }
    ]
  }
];

const mockCategories: Category[] = [
  { id: 'cat_27', name: 'Admission 27', subCategories: ['Varsity', 'Medical', 'Engineering', 'English'] },
  { id: 'cat_26', name: 'Admission 26', subCategories: ['Varsity', 'Medical', 'Engineering', 'English'] },
  { id: 'cat_25', name: 'Admission 25', subCategories: ['Varsity', 'Medical', 'Engineering', 'English'] },
  { id: 'cat_ssc', name: 'SSC', subCategories: ['General Math', 'Higher Math', 'Physics', 'Chemistry', 'Biology'] },
  { id: 'cat_hsc', name: 'HSC', subCategories: ['Physics', 'Chemistry', 'Higher Math', 'Biology'] },
];

const mockCourses: Course[] = [
  {
    id: 'course_acs_varsity',
    title: 'ACS Varsity + GST Special Private Programme 2026',
    description: 'The ultimate prep program for Varsity and GST admissions containing specialized material, daily live practice sets, and detailed mocks.',
    category: 'Admission 26',
    subCategory: 'Varsity',
    bannerUrl: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=800&q=80',
    createdAt: Date.now() - 5 * 86400000,
    isPaid: true,
    feeAmount: 4000,
    discountAmount: 500
  },
  {
    id: 'course_goalhackers',
    title: 'GOALHACKERS 26 (Medi + Varsity + Engineering) English Special Private Programme',
    description: 'Complete syllabus coverage of college & admission-level English with core grammar hacks, instant practice sessions, and expert mocks.',
    category: 'Admission 26',
    subCategory: 'English',
    bannerUrl: 'https://images.unsplash.com/photo-1546410531-bb4caa6b424d?w=800&q=80',
    createdAt: Date.now() - 3 * 86400000,
    isPaid: true,
    feeAmount: 800,
    discountAmount: 0
  },
  {
    id: 'course_admission_25',
    title: 'Medical Admissions Special Batch 2025',
    description: 'High-intensity biology and chemistry focused preparation class for upcoming medical college admissions tests.',
    category: 'Admission 25',
    subCategory: 'Medical',
    bannerUrl: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&q=80',
    createdAt: Date.now() - 10 * 86400000,
    isPaid: true,
    feeAmount: 3500,
    discountAmount: 1000
  },
  {
    id: 'course_class10_math',
    title: 'SSC Board Exam-2026 General Mathematics Prep Batch',
    description: 'Targeted course for securing GPA 5 in general and higher mathematics with intensive boards question solvers.',
    category: 'Admission 27',
    subCategory: 'Varsity',
    bannerUrl: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=800&q=80',
    createdAt: Date.now() - 15 * 86400000,
    isPaid: false,
    feeAmount: 0,
    discountAmount: 0
  }
];

const mockEvents: AppEvent[] = [
  {
    id: 'event_physics_camp',
    title: 'OTS National Physics Olympiad Masterclass',
    description: 'Advanced concepts of mechanics, quantum basics, and analytical puzzle solvers for national Olympiad competitors.',
    date: Date.now() + 172800000, // 2 days in future
    location: 'OTS Interactive Zoom Live Room',
    bannerUrl: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=800&q=80',
    createdAt: Date.now() - 4 * 86400000,
    isPaid: false,
    feeAmount: 0
  },
  {
    id: 'event_hsc_hackathon',
    title: 'HSC - English Grammar Marathon with OTS Instructors',
    description: 'A 5-hour continuous grammar solving live run featuring shortcuts for preposition rules, modifiers, and narrative styles.',
    date: Date.now() + 345600000, // 4 days in future
    location: 'OTS Live Stream Studio',
    bannerUrl: 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?w=800&q=80',
    createdAt: Date.now() - 2 * 86400000,
    isPaid: true,
    feeAmount: 150,
    discountAmount: 50
  }
];

const mockUsers: User[] = [
  {
    id: 'admin_1',
    name: 'Admin',
    email: 'admin@ots.com',
    role: 'admin',
    status: 'active',
    createdAt: Date.now(),
  },
  {
    id: 'user_1',
    name: 'Student One',
    email: 'student@ots.com',
    role: 'user',
    status: 'active',
    createdAt: Date.now(),
  }
];

export const useStore = create<AppState & StoreActions>()(
  persist(
    (set, get) => ({
      users: mockUsers,
      exams: mockExams,
      events: mockEvents,
      courses: mockCourses,
      results: [],
      payments: [],
      paymentConfig: {
        bkash: '01XXXXXXXXX',
        nagad: '01XXXXXXXXX',
        rocket: '01XXXXXXXXX',
        youtubeUrl: '',
      },
      currentUser: null,
      categories: mockCategories,
      faqs: [],
      notifications: [],

      addNotification: (notification) => {
        const newNotification: AppNotification = {
          ...notification,
          id: `notif_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          isRead: false,
          createdAt: Date.now()
        };
        set({ notifications: [newNotification, ...get().notifications] });
      },

      markNotificationAsRead: (id) => {
        set({
          notifications: get().notifications.map(n => n.id === id ? { ...n, isRead: true } : n)
        });
      },

      clearNotifications: () => {
        const currentUserId = get().currentUser?.id;
        if (!currentUserId) return;
        set({
          notifications: get().notifications.filter(n => n.userId !== currentUserId)
        });
      },

      checkUpcomingExams: () => {
        const currentUser = get().currentUser;
        if (!currentUser || currentUser.role === 'admin') return;

        const now = Date.now();
        const thirtyMinsFromNow = now + 30 * 60 * 1000;
        const exams = get().exams;
        
        // Find exams starting in roughly 30 mins that we haven't notified about
        const upcomingExams = exams.filter(exam => {
          // Check if exam is live and starting soon
          const startsSoon = exam.startTime > now && exam.startTime <= thirtyMinsFromNow;
          if (!startsSoon) return false;

          // Check if user has access
          let hasAccess = false;
          if (exam.accessType === 'public') hasAccess = true;
          else if (exam.accessType === 'course' && exam.courseIds) {
            hasAccess = (currentUser.enrolledCourses || []).some(id => exam.courseIds?.includes(id));
          } else if (exam.accessType === 'event' && exam.eventIds) {
            hasAccess = (currentUser.joinedEvents || []).some(id => exam.eventIds?.includes(id));
          }

          if (!hasAccess) return false;

          // Check if already notified (avoid spam)
          const alreadyNotified = get().notifications.some(n => 
            n.userId === currentUser.id && 
            n.type === 'exam_upcoming' && 
            n.targetId === exam.id
          );

          return !alreadyNotified;
        });

        upcomingExams.forEach(exam => {
          get().addNotification({
            userId: currentUser.id,
            title: 'Upcoming Exam',
            message: `"${exam.title}" will start in less than 30 minutes. Be ready!`,
            type: 'exam_upcoming',
            targetId: exam.id
          });
        });
      },

      createFAQ: (question, answer, order) => {
        const faqs = get().faqs || [];
        const newFAQ: FAQ = {
          id: `faq_${Date.now()}`,
          question,
          answer,
          order: order || faqs.length
        };
        set({ faqs: [...faqs, newFAQ] });
      },

      updateFAQ: (id, faqUpdates) => {
        const faqs = get().faqs || [];
        set({
          faqs: faqs.map(f => (f.id === id ? { ...f, ...faqUpdates } : f))
        });
      },

      deleteFAQ: (id) => {
        const faqs = get().faqs || [];
        set({ faqs: faqs.filter(f => f.id !== id) });
      },

      createCategory: (name) => {
        const categories = get().categories || [];
        const newCat: Category = {
          id: `cat_${Date.now()}`,
          name,
          subCategories: []
        };
        set({ categories: [...categories, newCat] });
      },

      deleteCategory: (id) => {
        const categories = get().categories || [];
        set({ categories: categories.filter(c => c.id !== id) });
      },

      addSubCategory: (categoryId, subCategoryName) => {
        const categories = get().categories || [];
        set({
          categories: categories.map(c => 
            c.id === categoryId 
              ? { ...c, subCategories: Array.from(new Set([...c.subCategories, subCategoryName])) }
              : c
          )
        });
      },

      deleteSubCategory: (categoryId, subCategoryName) => {
        const categories = get().categories || [];
        set({
          categories: categories.map(c => 
            c.id === categoryId 
              ? { ...c, subCategories: c.subCategories.filter(s => s !== subCategoryName) }
              : c
          )
        });
      },

      login: async (email, password, role = 'user') => {
        try {
          const normalizedEmail = email.toLowerCase();
          await signInWithEmailAndPassword(auth, normalizedEmail, password);
          
          const users = get().users;
          const existing = users.find(u => u.email.toLowerCase() === normalizedEmail && u.role === role);
          
          if (existing) {
            if (existing.status === 'blocked') {
              return { success: false, message: 'Your account has been blocked by the admin.' };
            }
            set({ currentUser: existing });
            return { success: true };
          } else {
             return { success: false, message: 'User profile not found.' };
          }
        } catch (error: any) {
          return { success: false, message: error.message };
        }
      },

      loginAdmin: (email) => {
          const users = get().users;
          const admin = users.find(u => u.email === email && u.role === 'admin');
          if (admin) {
            set({ currentUser: admin });
          }
      },

      logout: () => {
        auth.signOut();
        set({ currentUser: null });
      },

      register: async (name, email, password) => {
        try {
          const normalizedEmail = email.toLowerCase();
          // Check if user already exists
          const existingUser = get().users.find(u => u.email.toLowerCase() === normalizedEmail);
          if (existingUser) {
              return { success: false, message: 'An account with this email already exists.' };
          }
          
          await createUserWithEmailAndPassword(auth, normalizedEmail, password);
          
          const newUser: User = {
            id: auth.currentUser?.uid || `user_${Date.now()}`,
            name,
            email: normalizedEmail,
            role: 'user',
            status: 'active',
            createdAt: Date.now(),
          };
          set({ users: [...get().users, newUser], currentUser: newUser });
          return { success: true };
        } catch (error: any) {
          return { success: false, message: error.message };
        }
      },

      createExam: (exam) => {
        const newExam: Exam = {
          ...exam,
          id: `exam_${Date.now()}`,
          createdAt: Date.now(),
        };
        const exams = [newExam, ...get().exams];
        set({ exams });

        // Notify enrolled students if it's assigned to courses
        if (newExam.accessType === 'course' && newExam.courseIds?.length) {
          const students = get().users.filter(u => 
            u.role === 'user' && 
            u.enrolledCourses?.some(cid => newExam.courseIds?.includes(cid))
          );

          students.forEach(student => {
            get().addNotification({
              userId: student.id,
              title: 'New Exam Added',
              message: `A new exam "${newExam.title}" has been added to your course.`,
              type: 'course_exam',
              targetId: newExam.id
            });
          });
        }
      },

      updateExam: (id, updated) => {
        set({
          exams: get().exams.map(e => e.id === id ? { ...e, ...updated } : e)
        });
      },

      deleteExam: (id) => {
        set({ exams: get().exams.filter(e => e.id !== id) });
      },

      createEvent: (event) => {
        const newEvent: AppEvent = {
          ...event,
          id: `event_${Date.now()}`,
          createdAt: Date.now(),
        };
        set({ events: [newEvent, ...get().events] });
      },

      updateEvent: (id, updated) => {
        set({
          events: get().events.map(e => e.id === id ? { ...e, ...updated } : e)
        });
      },

      deleteEvent: (id) => {
        set({ events: get().events.filter(e => e.id !== id) });
      },

      createCourse: (course) => {
        const newCourse: Course = {
          ...course,
          id: `course_${Date.now()}`,
          createdAt: Date.now(),
        };
        set({ courses: [newCourse, ...get().courses] });
      },

      updateCourse: (id, updated) => {
        set({
          courses: get().courses.map(c => c.id === id ? { ...c, ...updated } : c)
        });
      },

      deleteCourse: (id) => {
        set({ courses: get().courses.filter(c => c.id !== id) });
      },

      createCourseNotice: (courseId, noticeData) => {
        const newNotice: CourseNotice = {
          ...noticeData,
          id: `notice_${Date.now()}`,
          createdAt: Date.now()
        };

        const courses = get().courses.map(c => {
          if (c.id === courseId) {
            return {
              ...c,
              notices: [newNotice, ...(c.notices || [])]
            };
          }
          return c;
        });

        set({ courses });

        // Notify enrolled students
        const students = get().users.filter(u => 
          u.role === 'user' && 
          u.enrolledCourses?.includes(courseId)
        );

        const course = get().courses.find(c => c.id === courseId);

        students.forEach(student => {
          get().addNotification({
            userId: student.id,
            title: `New Notice: ${course?.title}`,
            message: newNotice.title,
            type: 'course_notice',
            targetId: courseId
          });
        });
      },

      updatePaymentConfig: (config) => set({ paymentConfig: config }),

      submitPayment: (payment) => {
        const newPayment: PaymentRecord = {
          ...payment,
          id: `pay_${Date.now()}`,
          status: 'pending',
          createdAt: Date.now(),
        };
        set({ payments: [newPayment, ...get().payments] });
      },

      updatePaymentStatus: (id, status) => {
        set({
          payments: get().payments.map(p => 
            p.id === id 
              ? { ...p, status, verifiedAt: status === 'verified' ? Date.now() : undefined }
              : p
          )
        });
      },

      submitExamOption: (result) => {
        const newResult: ExamResult = {
          ...result,
          id: `res_${Date.now()}`,
          submittedAt: Date.now()
        };
        set({ results: [...get().results, newResult] });
      },
      
      toggleUserStatus: (userId) => {
         set({
            users: get().users.map(u => {
                if (u.id === userId) {
                    return { ...u, status: u.status === 'active' ? 'blocked' : 'active' };
                }
                return u;
            })
         });
      },

      enrollInCourse: (userId, courseId) => {
        const payments = get().payments;
        const hasVerifiedPayment = payments.some(p => p.userId === userId && p.targetId === courseId && p.status === 'verified');
        const course = get().courses.find(c => c.id === courseId);
        
        if (course && course.isPaid && !hasVerifiedPayment) {
            return false;
        }

        set({
          users: get().users.map(u => {
            if (u.id === userId) {
              const enrolled = u.enrolledCourses || [];
              if (!enrolled.includes(courseId)) {
                return { ...u, enrolledCourses: [...enrolled, courseId] };
              }
              return u;
            }
            return u;
          }),
          currentUser: get().currentUser?.id === userId ? {
            ...get().currentUser!,
            enrolledCourses: (get().currentUser?.enrolledCourses || []).includes(courseId)
                ? get().currentUser!.enrolledCourses
                : [...(get().currentUser?.enrolledCourses || []), courseId]
          } : get().currentUser
        });
        return true;
      },

      revokeCourseAccess: (userId, courseId) => {
        set({
          users: get().users.map(u => {
            if (u.id === userId) {
              return { ...u, enrolledCourses: (u.enrolledCourses || []).filter(id => id !== courseId) };
            }
            return u;
          }),
          currentUser: get().currentUser?.id === userId ? {
            ...get().currentUser!,
            enrolledCourses: (get().currentUser?.enrolledCourses || []).filter(id => id !== courseId)
          } : get().currentUser
        });
      },

      joinEvent: (userId, eventId) => {
        const payments = get().payments;
        const hasVerifiedPayment = payments.some(p => p.userId === userId && p.targetId === eventId && p.status === 'verified');
        const event = get().events.find(e => e.id === eventId);
        
        if (event && event.isPaid && !hasVerifiedPayment) {
            return false;
        }

        set({
          users: get().users.map(u => {
            if (u.id === userId) {
              const joined = u.joinedEvents || [];
              if (!joined.includes(eventId)) {
                return { ...u, joinedEvents: [...joined, eventId] };
              }
              return u;
            }
            return u;
          }),
          currentUser: get().currentUser?.id === userId ? {
            ...get().currentUser!,
            joinedEvents: (get().currentUser?.joinedEvents || []).includes(eventId)
                ? get().currentUser!.joinedEvents
                : [...(get().currentUser?.joinedEvents || []), eventId]
          } : get().currentUser
        });
        return true;
      },

      revokeEventAccess: (userId, eventId) => {
        set({
          users: get().users.map(u => {
            if (u.id === userId) {
              return { ...u, joinedEvents: (u.joinedEvents || []).filter(id => id !== eventId) };
            }
            return u;
          }),
          currentUser: get().currentUser?.id === userId ? {
            ...get().currentUser!,
            joinedEvents: (get().currentUser?.joinedEvents || []).filter(id => id !== eventId)
          } : get().currentUser
        });
      },

      deleteUser: (userId) => {
        set({
          users: get().users.filter(u => u.id !== userId),
          currentUser: get().currentUser?.id === userId ? null : get().currentUser
        });
      },

      updateProfile: (userId, profileUpdate) => {
        const { name, ...restProfile } = profileUpdate as any;
        set({
          users: get().users.map(u => 
            u.id === userId 
              ? { 
                  ...u, 
                  ...(name !== undefined ? { name } : {}),
                  profile: { ...(u.profile || {}), ...restProfile } as any 
                } 
              : u
          ),
          currentUser: get().currentUser?.id === userId 
            ? { 
                ...get().currentUser!, 
                ...(name !== undefined ? { name } : {}),
                profile: { ...(get().currentUser!.profile || {}), ...restProfile } as any 
              }
            : get().currentUser
        });
      }
    }),
    {
      name: 'ots-exam-storage',
      storage: createJSONStorage(() => idbStorage),
    }
  )
);
