import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useStore } from '../../store/useStore';
import { Clock, AlertCircle, CheckCircle2, Bell } from 'lucide-react';
import { cn } from '../../lib/utils';
import { MathText } from '../../components/MathText';
import { SubmitConfirmationModal } from '../../components/SubmitConfirmationModal';
import { ExamInstructionsModal } from '../../components/ExamInstructionsModal';
import { doc, getDoc, setDoc, deleteDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';

export default function ExamView() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { exams, currentUser, submitExamOption, payments, results } = useStore();
  
  const exam = exams.find(e => e.id === id);
  
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [timeLeft, setTimeLeft] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSubmitModal, setShowSubmitModal] = useState(false);
  const [showInstructions, setShowInstructions] = useState(true);
  const [warningMessage, setWarningMessage] = useState<string | null>(null);
  const [timeAlert, setTimeAlert] = useState<{ message: string, color: string } | null>(null);
  const [alertsTriggered, setAlertsTriggered] = useState({ fiveMin: false, oneMin: false });
  const [tabCorrectionCount, setTabCorrectionCount] = useState(0);

  // Load saved state in initial setup
  useEffect(() => {
    let _mounted = true;
    if (exam && currentUser && !isSubmitting) {
      // First load from localStorage for instant feedback
      const savedState = localStorage.getItem(`exam_${exam.id}_${currentUser.id}`);
      if (savedState) {
        try {
          const parsed = JSON.parse(savedState);
          if (parsed && typeof parsed === 'object') {
            setAnswers(parsed);
          }
        } catch(e) {
          console.error("Could not parse saved exam state", e);
        }
      }

      // Then attempt to restore from Firebase if no local state or even just merge
      // but to keep it simple, if no local state or we want remote truth, fetch:
      const fetchDraftFromCloud = async () => {
        try {
          const docRef = doc(db, 'exam_drafts', `${exam.id}_${currentUser.id}`);
          const snap = await getDoc(docRef);
          if (snap.exists()) {
            const data = snap.data();
            if (data && data.answers && typeof data.answers === 'object' && _mounted) {
              setAnswers(prev => ({ ...data.answers, ...prev })); // Merge local to remote, local takes precedence initially
            }
          }
        } catch(err) {
          console.warn("Failed to sync exam draft from cloud:", err);
        }
      };
      
      fetchDraftFromCloud();
    }
    return () => { _mounted = false; };
  }, [exam, currentUser, isSubmitting]);

  // Save on change local & cloud
  useEffect(() => {
    if (exam && currentUser && Object.keys(answers).length > 0 && !isSubmitting) {
      // Fast save to LocalStorage
      localStorage.setItem(`exam_${exam.id}_${currentUser.id}`, JSON.stringify(answers));

      // Async debounced save to Firebase
      const timer = setTimeout(async () => {
        try {
          const docRef = doc(db, 'exam_drafts', `${exam.id}_${currentUser.id}`);
          await setDoc(docRef, { answers, savedAt: Date.now() }, { merge: true });
        } catch(err) {
          console.warn("Failed to save exam draft to cloud:", err);
        }
      }, 10000); // 10 sec debounce to handle 1000+ users efficiently

      return () => clearTimeout(timer);
    }
  }, [answers, exam, currentUser, isSubmitting]);

  // Anti-cheating measures
  useEffect(() => {
    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault();
      setWarningMessage('Right-click is disabled during the exam.');
      setTimeout(() => setWarningMessage(null), 3000);
    };

    const handleCopyPaste = (e: ClipboardEvent) => {
      e.preventDefault();
      setWarningMessage('Copy and paste are disabled during the exam.');
      setTimeout(() => setWarningMessage(null), 3000);
    };

    const handleVisibilityChange = () => {
      if (document.hidden) {
        setWarningMessage('Warning: Changing tabs or minimizing is considered suspicious activity.');
        setTabCorrectionCount(prev => prev + 1);
        setTimeout(() => setWarningMessage(null), 5000);
      }
    };

    document.addEventListener('contextmenu', handleContextMenu);
    document.addEventListener('copy', handleCopyPaste);
    document.addEventListener('paste', handleCopyPaste);
    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      document.removeEventListener('contextmenu', handleContextMenu);
      document.removeEventListener('copy', handleCopyPaste);
      document.removeEventListener('paste', handleCopyPaste);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, []);

  useEffect(() => {
    if (!exam || !currentUser) return;
    
    // Check payment access
    if (exam.isPaid) {
      const existingPayment = payments.find(p => p.userId === currentUser.id && p.targetId === exam.id && p.targetType === 'exam');
      if (existingPayment?.status !== 'verified') {
        alert('You do not have access to this exam. Please complete the payment process first.');
        navigate('/student');
        return;
      }
    }

    // Check multiple attempts on live exams
    const isLiveNow = Date.now() <= exam.endTime;
    const hasAttempted = results.some(r => r.userId === currentUser.id && r.examId === exam.id && r.attemptType !== 'practice');
    if (isLiveNow && hasAttempted) {
      alert('You have already taken this live exam. Only one attempt is permitted.');
      navigate(`/student/result/${exam.id}`);
      return;
    }

    const durationSeconds = exam.durationMinutes * 60;
    const startTimeKey = `exam_start_${exam.id}_${currentUser.id}`;
    let startTime = localStorage.getItem(startTimeKey);
    
    if (!startTime) {
      startTime = Date.now().toString();
      localStorage.setItem(startTimeKey, startTime);
      setTimeLeft(durationSeconds);
    } else {
      const elapsedSeconds = Math.floor((Date.now() - parseInt(startTime, 10)) / 1000);
      const remaining = durationSeconds - elapsedSeconds;
      setTimeLeft(remaining > 0 ? remaining : 0);
    }
  }, [exam, currentUser, payments, results, navigate]);

  const playAlertSound = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();

      oscillator.connect(gainNode);
      gainNode.connect(audioCtx.destination);

      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(440, audioCtx.currentTime); // A4 note
      gainNode.gain.setValueAtTime(0, audioCtx.currentTime);
      gainNode.gain.linearRampToValueAtTime(0.2, audioCtx.currentTime + 0.1);
      gainNode.gain.linearRampToValueAtTime(0, audioCtx.currentTime + 0.5);

      oscillator.start();
      oscillator.stop(audioCtx.currentTime + 0.5);
    } catch (e) {
      console.warn('Audio alert not supported or blocked by browser policy', e);
    }
  };

  useEffect(() => {
    if (showInstructions) return;
    if (timeLeft <= 0 && exam && !isSubmitting) {
      handleSubmit();
      return;
    }

    // Time Alerts Logic
    if (timeLeft === 300 && !alertsTriggered.fiveMin) {
      setTimeAlert({ message: 'Only 5 Minutes Remaining!', color: 'bg-amber-500' });
      setAlertsTriggered(prev => ({ ...prev, fiveMin: true }));
      playAlertSound();
      setTimeout(() => setTimeAlert(null), 5000);
    } else if (timeLeft === 60 && !alertsTriggered.oneMin) {
      setTimeAlert({ message: 'Critical: Only 1 Minute Remaining!', color: 'bg-rose-600' });
      setAlertsTriggered(prev => ({ ...prev, oneMin: true }));
      playAlertSound();
      setTimeout(() => setTimeAlert(null), 5000);
    }

    const timer = setInterval(() => {
      setTimeLeft(prev => prev - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft, isSubmitting, showInstructions, alertsTriggered]);

  if (!exam || !currentUser) return <div>Loading...</div>;

  const handleSelectOption = (questionId: string, optionIndex: number) => {
    if (answers[questionId] !== undefined) return;
    setAnswers(prev => ({
      ...prev,
      [questionId]: optionIndex
    }));
  };

  const handleSubmit = () => {
    setIsSubmitting(true);
    let correctMarks = 0;
    let wrongPenalty = 0;
    let correctCount = 0;
    let wrongCount = 0;
    
    exam.questions.forEach(q => {
      const qMarks = q.marks ?? 1;
      if (answers[q.id] !== undefined) {
        if (answers[q.id] === q.correctOptionIndex) {
          correctMarks += qMarks;
          correctCount += 1;
        } else {
          wrongCount += 1;
          if (exam.hasNegativeMarking && exam.negativeMarksPerWrongAnswer) {
            wrongPenalty += exam.negativeMarksPerWrongAnswer;
          }
        }
      }
    });

    const total = exam.questions.length;
    const score = Number(Math.max(0, correctMarks - wrongPenalty).toFixed(2));
    const timeTaken = (exam.durationMinutes * 60) - timeLeft;
    
    const isLiveNow = Date.now() <= exam.endTime;
    const result = {
      examId: exam.id,
      userId: currentUser.id,
      score: score,
      totalQuestions: total,
      correctAnswers: correctCount,
      wrongAnswers: wrongCount, 
      accuracy: total > 0 ? (correctCount / total) * 100 : 0,
      answers,
      timeTakenSeconds: timeTaken,
      tabCorrectionCount,
      attemptType: isLiveNow ? ('live' as const) : ('practice' as const)
    };

    submitExamOption(result);
    localStorage.removeItem(`exam_${exam.id}_${currentUser.id}`);
    localStorage.removeItem(`exam_start_${exam.id}_${currentUser.id}`);
    deleteDoc(doc(db, 'exam_drafts', `${exam.id}_${currentUser.id}`)).catch(e => console.warn(e));
    navigate(`/student/result/${exam.id}`);
  };

  const formatTimeDetailed = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    if (h > 0) {
      return `${h}H ${m.toString().padStart(2, '0')}M ${s.toString().padStart(2, '0')}S`;
    }
    return `${m.toString().padStart(2, '0')}M ${s.toString().padStart(2, '0')}S`;
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const allAnswered = Object.keys(answers).length === exam.questions.length;

  if (exam.questions.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4">
        <AlertCircle className="h-12 w-12 text-gray-400 mb-4" />
        <h2 className="text-xl font-bold text-gray-900 mb-2">No Questions Available</h2>
        <p className="text-gray-500 mb-6 text-center">This exam hasn't been set up properly yet.</p>
        <button onClick={() => navigate('/student')} className="bg-indigo-600 text-white px-6 py-2 rounded-lg">
          Go Back
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 md:bg-gray-100 relative select-none">
      {/* Warning Toast */}
      {warningMessage && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-rose-500 text-white px-6 py-3 rounded-xl shadow-lg font-bold flex items-center gap-3 animate-slideDown">
          <AlertCircle className="w-5 h-5" />
          {warningMessage}
        </div>
      )}

      {/* Time Alert Overlay */}
      {timeAlert && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-6 bg-black/20 backdrop-blur-[2px] pointer-events-none">
          <div className={cn(
            "px-10 py-8 rounded-[32px] text-white shadow-2xl flex flex-col items-center gap-4 animate-bounce-short",
            timeAlert.color
          )}>
            <Clock className="w-16 h-16 animate-pulse" />
            <h2 className="text-3xl font-black text-center tracking-tight leading-tight">
              {timeAlert.message}
            </h2>
          </div>
        </div>
      )}

      {/* Top Bar Navigation */}
      <div className="h-16 bg-white px-4 sm:px-6 shadow-sm border-b border-slate-200 flex items-center justify-between sticky top-0 z-[40]">
        <div className="flex items-center gap-3">
          <img 
            src="https://i.postimg.cc/h40vHdRJ/IMG-20260217-WA0010.jpg" 
            alt="OTS Logo" 
            referrerPolicy="no-referrer"
            className="w-8 h-8 sm:w-10 sm:h-10 object-cover rounded-lg border border-slate-100 shadow-sm flex-shrink-0"
          />
          <div className="font-black font-display text-slate-900 truncate pr-4 text-lg sm:text-xl tracking-tight leading-none uppercase">
            OTS Exam
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className="relative">
            <Bell className="w-5 h-5 sm:w-6 sm:h-6 text-slate-600" />
            <div className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-rose-500 rounded-full flex items-center justify-center text-[9px] font-bold text-white border-2 border-white">0</div>
          </div>
          <div className="h-8 w-8 sm:h-10 sm:w-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-700 font-bold overflow-hidden border border-slate-200">
            {currentUser?.name?.[0]?.toUpperCase() || 'U'}
          </div>
        </div>
      </div>

      {showInstructions && (
        <ExamInstructionsModal
          exam={exam}
          onStart={() => setShowInstructions(false)}
        />
      )}

      <div className="flex-1 max-w-4xl w-full mx-auto md:p-8 flex flex-col pb-32 pt-6 px-4">
        <h2 className="text-xl sm:text-2xl font-black text-slate-900 mb-6 text-center font-display">{exam.title}</h2>
        {/* Questions List */}
        {exam.questions.map((q, idx) => (
          <div key={q.id} className="bg-white md:rounded-3xl shadow-sm border border-slate-200 p-6 sm:p-8 mb-6 relative">
            <div className="flex gap-4">
              <div className="text-base sm:text-lg font-medium text-slate-900 pt-0.5 mt-0.5 shrink-0">
                {idx + 1}.
              </div>
              <div className="flex-1">
                <div className="flex justify-between items-start mb-6">
                  <div className="text-base sm:text-lg font-medium text-slate-900 leading-snug">
                    <MathText content={q.text} />
                    {q.imageUrl && (
                      <div className="mt-4 break-inside-avoid">
                        <img 
                          src={q.imageUrl} 
                          alt={`Question ${idx + 1} image`}
                          referrerPolicy="no-referrer"
                          className="max-w-full rounded-xl border border-slate-200 shadow-sm max-h-64 object-contain"
                        />
                      </div>
                    )}
                  </div>
                  <span className="text-sm font-medium text-slate-500 flex-shrink-0 ml-4 px-2.5 py-1 bg-slate-50 border border-slate-200 rounded-lg">
                    {q.marks ?? 1}
                  </span>
                </div>

                <div className="space-y-3">
                  {q.options.map((option, optIdx) => {
                    const isSelected = answers[q.id] === optIdx;
                    const hasAnswered = answers[q.id] !== undefined;
                    const labels = ['A', 'B', 'C', 'D', 'E'];
                    return (
                      <button
                        key={optIdx}
                        disabled={hasAnswered}
                        onClick={() => handleSelectOption(q.id, optIdx)}
                        className={cn(
                          "w-full text-left py-3 px-4 rounded-xl border-2 transition-all flex items-center group",
                          isSelected 
                            ? "border-indigo-600 bg-indigo-50 shadow-sm" 
                            : hasAnswered
                              ? "border-transparent opacity-50 cursor-not-allowed"
                              : "border-transparent hover:border-slate-200 hover:bg-slate-50 cursor-pointer"
                        )}
                      >
                        <div className={cn(
                          "w-8 h-8 rounded-full border mr-4 flex items-center justify-center transition-colors text-sm font-medium shrink-0",
                          isSelected 
                            ? "border-indigo-600 bg-indigo-600 text-white" 
                            : hasAnswered
                              ? "border-slate-200 text-slate-400"
                              : "border-slate-300 text-slate-600 group-hover:border-slate-400 group-hover:text-slate-800"
                        )}>
                          {labels[optIdx]}
                        </div>
                        <div className={cn(
                          "text-base flex-1 overflow-x-auto",
                          isSelected 
                            ? "text-indigo-900 font-medium" 
                            : hasAnswered
                              ? "text-slate-400 font-medium"
                              : "text-slate-700 font-medium"
                        )}>
                          <MathText content={option} />
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        ))}
        
        <button
          onClick={() => setShowSubmitModal(true)}
          className="w-full mt-4 bg-indigo-600 hover:bg-indigo-700 text-white shadow-xl shadow-indigo-500/20 px-8 py-5 rounded-2xl font-bold transition-all text-lg border-2 border-indigo-700"
        >
          Submit Exam
        </button>
      </div>

      {/* Sticky Bottom Context Bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.05)] z-40 p-4 flex justify-between items-center px-4 sm:px-8">
        <div className="bg-emerald-600 text-white px-4 py-2 sm:py-2.5 font-bold rounded-lg flex items-center justify-center text-sm sm:text-base">
          Submitted : {Object.keys(answers).length}
        </div>
        <div className={cn(
          "bg-emerald-600 text-white px-4 py-2 sm:py-2.5 font-bold rounded-lg flex items-center justify-center tracking-widest text-sm sm:text-base transition-colors",
          timeLeft < 300 && "bg-amber-600",
          timeLeft < 60 && "bg-rose-600"
        )}>
          {formatTimeDetailed(timeLeft)}
        </div>
      </div>

      <SubmitConfirmationModal
        isOpen={showSubmitModal}
        total={exam.questions.length}
        answered={Object.keys(answers).length}
        unanswered={exam.questions.length - Object.keys(answers).length}
        markedForReview={0}
        onCancel={() => setShowSubmitModal(false)}
        onConfirm={() => { setShowSubmitModal(false); handleSubmit(); }}
      />
    </div>
  );
}
