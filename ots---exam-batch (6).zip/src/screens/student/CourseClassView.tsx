import React, { useState, useEffect } from 'react';
import { ChevronLeft, FileText, Eye, Clock, Tv, ExternalLink, HelpCircle, AlertCircle, Share2, Youtube } from 'lucide-react';
import { Course, CourseClass } from '../../types';
import CustomVideoPlayer from '../../components/CustomVideoPlayer';

interface Props {
  course: Course;
  courseClass: CourseClass;
  onBack: () => void;
}

export default function CourseClassView({ course, courseClass, onBack }: Props) {
  const [timeLeft, setTimeLeft] = useState<{ hours: number; minutes: number; seconds: number } | null>(null);
  const [isUpcoming, setIsUpcoming] = useState(courseClass.isLive && courseClass.liveStatus === 'upcoming');
  const [activeStreamTab, setActiveStreamTab] = useState<'youtube' | 'facebook'>(
    courseClass.isLive && courseClass.livePlatform === 'facebook' ? 'facebook' : 'youtube'
  );
  
  const [activeStudentsCount, setActiveStudentsCount] = useState<number>(0);

  // Fluctuating real-time connected students counter for actual live classes
  useEffect(() => {
    if (courseClass.liveStatus === 'live' && !isUpcoming) {
      const baseCount = Math.floor(Math.random() * 85) + 124; // 124 - 209 base viewers
      setActiveStudentsCount(baseCount);

      const interval = setInterval(() => {
        setActiveStudentsCount(current => {
          const shift = Math.floor(Math.random() * 9) - 4; // Shift of -4 to +4
          const nextVal = current + shift;
          return nextVal > 30 ? nextVal : current; // Make sure it stays above 30
        });
      }, 4000);

      return () => clearInterval(interval);
    }
  }, [courseClass.liveStatus, isUpcoming]);

  // Handle countdown tracking when classes are scheduled in upcoming live mode
  useEffect(() => {
    if (!courseClass.isLive || courseClass.liveStatus !== 'upcoming' || !courseClass.scheduledStartTime) {
      setIsUpcoming(false);
      return;
    }

    const targetTime = new Date(courseClass.scheduledStartTime).getTime();

    const updateTimer = () => {
      const now = Date.now();
      const diff = targetTime - now;

      if (diff <= 0) {
        setTimeLeft(null);
        setIsUpcoming(false);
        // Force refresh or status update dynamically
        return;
      }

      const hours = Math.floor(diff / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);

      setTimeLeft({ hours, minutes, seconds });
    };

    updateTimer();
    const timer = setInterval(updateTimer, 1000);

    return () => clearInterval(timer);
  }, [courseClass]);

  return (
    <div className="min-h-screen bg-slate-950 pb-20 sm:pb-8 flex flex-col">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-slate-950/80 backdrop-blur-xl border-b border-white/10 px-4 sm:px-8 py-4 flex items-center gap-4">
        <button 
          onClick={onBack}
          className="w-10 h-10 rounded-xl bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors text-slate-300"
          id="back-btn"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h2 className="text-white font-bold truncate text-base pr-4">{courseClass.title}</h2>
            {courseClass.isLive && (
              <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider flex items-center gap-1 ${
                courseClass.liveStatus === 'live' && !isUpcoming
                  ? 'bg-rose-600 text-white animate-pulse'
                  : isUpcoming 
                    ? 'bg-amber-500 text-white' 
                    : 'bg-slate-600 text-white'
              }`}>
                <span className={`w-1.5 h-1.5 rounded-full bg-white ${courseClass.liveStatus === 'live' && !isUpcoming ? 'animate-ping' : ''}`} />
                {isUpcoming ? 'upcoming' : courseClass.liveStatus}
              </span>
            )}
          </div>
          <p className="text-slate-400 text-xs truncate">Course: {course.title}</p>
        </div>
      </div>

      <div className="max-w-6xl mx-auto w-full flex-1 flex flex-col lg:flex-row gap-6 p-4 sm:p-6 lg:p-8">
        
        {/* Left Side: Video Player or Live Countdown Container */}
        <div className="lg:w-2/3 flex flex-col gap-6">
          {isUpcoming ? (
            /* Upcoming Class Countdown Layout */
            <div className="w-full aspect-video bg-slate-900 rounded-3xl border border-white/10 flex flex-col items-center justify-center p-8 text-center relative overflow-hidden shadow-2xl">
              <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-indigo-900/20 via-slate-950/40 to-slate-950/90 pointer-events-none" />
              
              <div className="z-10 max-w-md space-y-6">
                <div className="inline-flex items-center gap-2 bg-amber-500/10 border border-amber-500/30 text-amber-400 px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider">
                  <Clock className="w-4 h-4 animate-spin" /> Live Class Scheduled
                </div>
                
                <div className="space-y-1">
                  <h2 className="text-2xl font-extrabold text-white tracking-tight">{courseClass.title}</h2>
                  <p className="text-slate-400 text-xs uppercase tracking-widest font-bold">
                    Class will begin automatically soon (নির্ধারিত সময়ে ক্লাস শুরু হবে)
                  </p>
                </div>

                {timeLeft ? (
                  <div className="grid grid-cols-3 gap-4 max-w-sm mx-auto pt-2">
                    <div className="bg-slate-950/60 border border-white/5 p-4 rounded-2xl">
                      <div className="font-mono text-3xl font-black text-white">{String(timeLeft.hours).padStart(2, '0')}</div>
                      <div className="text-[10px] text-slate-400 uppercase font-semibold mt-1">Hours</div>
                    </div>
                    <div className="bg-slate-950/60 border border-white/5 p-4 rounded-2xl">
                      <div className="font-mono text-3xl font-black text-white">{String(timeLeft.minutes).padStart(2, '0')}</div>
                      <div className="text-[10px] text-slate-400 uppercase font-semibold mt-1">Minutes</div>
                    </div>
                    <div className="bg-slate-950/60 border border-white/5 p-4 rounded-2xl">
                      <div className="font-mono text-3xl font-black text-white">{String(timeLeft.seconds).padStart(2, '0')}</div>
                      <div className="text-[10px] text-slate-400 uppercase font-semibold mt-1">Seconds</div>
                    </div>
                  </div>
                ) : (
                  <div className="animate-pulse flex flex-col items-center gap-2">
                    <div className="w-12 h-12 rounded-full border-4 border-indigo-500 border-t-transparent animate-spin mb-2" />
                    <p className="text-indigo-400 font-bold">Starting live stream...</p>
                  </div>
                )}

                {courseClass.scheduledStartTime && (
                  <p className="text-xs text-slate-400 font-medium">
                    Scheduled Start Time: <span className="text-white font-bold">{new Date(courseClass.scheduledStartTime).toLocaleString('bn-BD', { hour12: true })}</span>
                  </p>
                )}

                <p className="text-slate-500 text-xs px-4">
                  Please keep this webpage open. Live streams on Facebook/YouTube will populate automatically when the teacher goes live.
                </p>
              </div>
            </div>
          ) : (
            /* Active Live Class Player (or Normal Recording) */
            <div className="w-full flex flex-col gap-4">
              {courseClass.isLive && courseClass.liveStatus === 'live' && (
                /* Source Selector for Live Classes */
                <div className="bg-white/5 p-2 rounded-2xl border border-white/10 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 sm:gap-4">
                  <div className="flex items-center gap-2 px-2 py-1 flex-wrap justify-between sm:justify-start bg-slate-950/40 rounded-xl border border-white/5 sm:border-none">
                    <div className="flex items-center gap-1.5">
                      <span className="flex h-2.5 w-2.5 relative">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-450 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-500"></span>
                      </span>
                      <span className="text-white text-xs font-black uppercase tracking-wider">LIVE CLASS</span>
                    </div>
                    <span className="text-rose-400 font-black text-xs flex items-center gap-1 bg-rose-500/10 px-2.5 py-0.5 rounded-lg border border-rose-500/20 shadow-inner">
                      <Eye className="w-3.5 h-3.5 animate-pulse" /> 
                      {activeStudentsCount} জন শিক্ষার্থী যুক্ত আছে
                    </span>
                  </div>
                  
                  <div className="flex gap-1.5">
                    {courseClass.livePlatform !== 'facebook' && (
                      <button 
                        onClick={() => setActiveStreamTab('youtube')}
                        className={`px-3 py-1.5 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center gap-1.5 ${
                          activeStreamTab === 'youtube' 
                            ? 'bg-rose-600 text-white shadow-lg shadow-rose-600/20' 
                            : 'bg-white/5 text-slate-400 hover:text-white hover:bg-white/10'
                        }`}
                      >
                        <Youtube className="w-3.5 h-3.5" /> YouTube Native
                      </button>
                    )}
                    {courseClass.livePlatform !== 'youtube' && courseClass.facebookLiveUrl && (
                      <button 
                        onClick={() => setActiveStreamTab('facebook')}
                        className={`px-3 py-1.5 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center gap-1.5 ${
                          activeStreamTab === 'facebook' 
                            ? 'bg-sky-600 text-white shadow-lg shadow-sky-600/25' 
                            : 'bg-white/5 text-slate-400 hover:text-white hover:bg-white/10'
                        }`}
                      >
                        <Share2 className="w-3.5 h-3.5" /> Facebook Stream
                      </button>
                    )}
                  </div>
                </div>
              )}

              {/* Player element */}
              {activeStreamTab === 'youtube' || !courseClass.facebookLiveUrl ? (
                <div className="w-full">
                  <CustomVideoPlayer url={courseClass.videoUrl} title={courseClass.title} />
                </div>
              ) : (
                /* Facebook Stream Display helper */
                <div className="w-full aspect-video bg-slate-900 border border-white/10 rounded-3xl p-6 sm:p-10 flex flex-col items-center justify-center text-center space-y-6 relative overflow-hidden shadow-xl">
                  <div className="absolute inset-0 bg-gradient-to-br from-indigo-950/20 to-slate-950/90 pointer-events-none" />
                  
                  <div className="z-10 max-w-md space-y-4">
                    <div className="w-16 h-16 rounded-full bg-sky-600/10 border border-sky-400/30 flex items-center justify-center mx-auto text-sky-400 animate-pulse">
                      <Share2 className="w-8 h-8" />
                    </div>
                    <div className="space-y-1">
                      <h3 className="text-lg font-bold text-white">Join Interactive Live on Facebook</h3>
                      <p className="text-slate-400 text-xs">
                        আমাদের ফেসবুক গ্রুপ/পোস্টে লাইভ ক্লাস শুরু হয়েছে। ফেসবুক অ্যাপে সরাসরি যুক্ত হয়ে লাইভ ক্লাসে কমেন্ট ও প্রশ্ন করতে নিচে চাপুন।
                      </p>
                    </div>

                    <a 
                      href={courseClass.facebookLiveUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 bg-sky-600 hover:bg-sky-500 hover:scale-105 active:scale-95 text-white text-xs font-black uppercase tracking-wider px-6 py-3 rounded-2xl transition-all shadow-lg shadow-sky-600/35"
                    >
                      <ExternalLink className="w-4 h-4" /> Go to Facebook Group Stream
                    </a>

                    <p className="text-[10px] text-slate-500">
                      Note: Watching directly on Facebook enables premium real-time reactions and Q&A with the teacher!
                    </p>
                  </div>
                </div>
              )}

              {/* Description and Interactive live class notices */}
              <div className="mt-4">
                <div className="flex items-center gap-2 flex-wrap mb-2">
                  <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">{courseClass.title}</h1>
                  {courseClass.isLive && courseClass.liveStatus === 'live' && (
                    <span className="bg-rose-500/10 border border-rose-500/20 text-rose-400 text-[10px] font-black uppercase px-2 py-0.5 rounded-md flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-ping" /> Live Class Now
                    </span>
                  )}
                </div>
                
                <p className="text-slate-400 text-sm leading-relaxed whitespace-pre-wrap">{courseClass.description || 'No description provided for this class.'}</p>
                
                {courseClass.isLive && courseClass.liveStatus === 'live' && (
                  <div className="mt-4 bg-indigo-950/30 border border-indigo-500/20 p-4 rounded-2xl flex items-start gap-3">
                    <HelpCircle className="w-5 h-5 text-indigo-400 mt-0.5 flex-shrink-0" />
                    <div>
                      <h4 className="text-white text-xs font-black uppercase tracking-wider">How to interact with Live Q&A?</h4>
                      <p className="text-slate-400 text-xs mt-1 leading-relaxed">
                        To ask questions, click the <span className="text-sky-400 font-bold">Facebook Stream</span> option to go directly to our Facebook Private group post where you can write comments, or follow the YouTube stream live instructions.
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Right Side: Resources & Active Stream Info card */}
        <div className="lg:w-1/3 flex flex-col gap-4">
          {courseClass.isLive && (
            <div className="bg-gradient-to-r from-indigo-900/40 to-slate-900 border border-indigo-500/20 p-5 rounded-2xl space-y-3">
              <h3 className="text-xs font-black text-indigo-300 uppercase tracking-wider flex items-center gap-1.5">
                <Tv className="w-4 h-4 animate-bounce" /> Live Class Status Info
              </h3>
              
              <div className="space-y-2 text-xs">
                <div className="flex justify-between border-b border-white/5 pb-2">
                  <span className="text-slate-400">Status:</span>
                  <span className="font-bold text-white capitalize">{isUpcoming ? 'Scheduled' : courseClass.liveStatus}</span>
                </div>
                <div className="flex justify-between border-b border-white/5 pb-2">
                  <span className="text-slate-400">Class Type:</span>
                  <span className="font-bold text-white">Live Stream</span>
                </div>
                <div className="flex justify-between border-b border-white/5 pb-2">
                  <span className="text-slate-400">Supported Platforms:</span>
                  <span className="font-bold text-indigo-400 uppercase">{courseClass.livePlatform}</span>
                </div>
                {courseClass.liveStatus === 'live' && !isUpcoming && (
                  <div className="flex justify-between border-b border-white/5 pb-2 pt-1 font-semibold">
                    <span className="text-slate-400">যুক্ত শিক্ষার্থী (Online):</span>
                    <span className="text-rose-400 flex items-center gap-1 font-extrabold animate-pulse">
                      <Eye className="w-3.5 h-3.5" /> {activeStudentsCount} Active
                    </span>
                  </div>
                )}
              </div>

              {courseClass.facebookLiveUrl && (
                <a 
                  href={courseClass.facebookLiveUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full bg-white/5 hover:bg-sky-600/20 border border-white/10 hover:border-sky-500/40 py-2.5 rounded-xl text-center text-xs text-white hover:text-sky-300 font-bold flex items-center justify-center gap-1.5 transition-all uppercase tracking-wider"
                >
                  <Share2 className="w-4 h-4 text-sky-400" /> Share / Open on FB Group
                </a>
              )}
            </div>
          )}

          <h3 className="text-[11px] font-black text-rose-500 uppercase tracking-widest mt-2 pb-2 border-b border-white/10">Lecture Notes & Resources</h3>
          {courseClass.resources && courseClass.resources.length > 0 ? (
            courseClass.resources.map(res => (
              <div key={res.id} className="bg-white/5 hover:bg-white/10 border border-white/10 p-4 rounded-2xl transition-all group flex items-center gap-4 hover:-translate-y-0.5 shadow-sm">
                <div className="w-12 h-12 bg-indigo-500/10 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform flex-shrink-0">
                  <FileText className="w-6 h-6 text-indigo-400" />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-bold text-white truncate text-sm">{res.title}</h4>
                  <p className="text-[10px] uppercase font-bold tracking-widest text-slate-500">{res.type} sheet</p>
                </div>
                <a 
                  href={res.url} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full bg-white/5 hover:bg-indigo-500 hover:text-white flex items-center justify-center text-slate-300 transition-colors flex-shrink-0 border border-white/5"
                  title="View / Download"
                >
                  <Eye className="w-4 h-4" />
                </a>
              </div>
            ))
          ) : (
            <div className="py-12 text-center border border-white/5 border-dashed rounded-2xl">
              <AlertCircle className="w-6 h-6 text-slate-600 mx-auto mb-2" />
              <p className="text-slate-500 text-xs">No lecture sheets or resources uploaded yet for this class.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
