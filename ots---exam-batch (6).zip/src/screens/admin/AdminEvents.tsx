import React, { useState } from 'react';
import { useStore } from '../../store/useStore';
import { Plus, Trash2, Calendar as CalendarIcon, Clock, MapPin, Pencil, Users } from 'lucide-react';
import { format } from 'date-fns';
import { AppEvent } from '../../types';

export default function AdminEvents() {
  const { events, createEvent, updateEvent, deleteEvent, users } = useStore();
  const [showForm, setShowForm] = useState(false);
  const [editingEventId, setEditingEventId] = useState<string | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState('');
  const [location, setLocation] = useState('');
  const [bannerUrl, setBannerUrl] = useState('');
  const [fakeJoinCount, setFakeJoinCount] = useState<number>(0);
  const [isPaid, setIsPaid] = useState(false);
  const [feeAmount, setFeeAmount] = useState(0);
  const [discountAmount, setDiscountAmount] = useState(0);
  const [isPromoted, setIsPromoted] = useState(false);
  const [referralEnabled, setReferralEnabled] = useState(false);
  const [referralDiscount, setReferralDiscount] = useState(0);

  const formatLocalDateForInput = (timestamp: number) => {
    const d = new Date(timestamp);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const hours = String(d.getHours()).padStart(2, '0');
    const minutes = String(d.getMinutes()).padStart(2, '0');
    return `${year}-${month}-${day}T${hours}:${minutes}`;
  };

  const clearForm = () => {
    setTitle('');
    setDescription('');
    setDate('');
    setLocation('');
    setBannerUrl('');
    setFakeJoinCount(0);
    setIsPaid(false);
    setFeeAmount(0);
    setDiscountAmount(0);
    setIsPromoted(false);
    setReferralEnabled(false);
    setReferralDiscount(0);
    setEditingEventId(null);
    setShowForm(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !date) return;

    const eventData = {
      title,
      description,
      date: new Date(date).getTime(),
      location,
      bannerUrl,
      fakeJoinCount,
      isPaid,
      feeAmount: isPaid ? feeAmount : 0,
      discountAmount: isPaid ? discountAmount : 0,
      isPromoted,
      referralEnabled: isPaid ? referralEnabled : false,
      referralDiscount: isPaid && referralEnabled ? referralDiscount : 0,
    };

    if (editingEventId) {
      updateEvent(editingEventId, eventData);
    } else {
      createEvent(eventData);
    }

    clearForm();
  };

  const handleEditClick = (event: AppEvent) => {
    setEditingEventId(event.id);
    setTitle(event.title);
    setDescription(event.description || '');
    setDate(formatLocalDateForInput(event.date));
    setLocation(event.location || '');
    setBannerUrl(event.bannerUrl || '');
    setFakeJoinCount(event.fakeJoinCount || 0);
    setIsPaid(event.isPaid || false);
    setFeeAmount(event.feeAmount || 0);
    setDiscountAmount(event.discountAmount || 0);
    setIsPromoted(event.isPromoted || false);
    setReferralEnabled(event.referralEnabled || false);
    setReferralDiscount(event.referralDiscount || 0);
    setShowForm(true);
  };

  const getJoinedUsersCount = (eventId: string) => {
    return users.filter(u => u.joinedEvents?.includes(eventId)).length;
  };

  return (
    <div>
      <div className="flex sm:items-center justify-between flex-col sm:flex-row gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-display font-bold text-slate-900 tracking-tight">Manage Events</h1>
          <p className="text-slate-500 text-sm mt-1 font-medium">Create and organize school events</p>
        </div>
        <button 
          onClick={() => {
            if (showForm) {
              clearForm();
            } else {
              setShowForm(true);
            }
          }}
          className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-xl text-sm font-bold transition-colors flex items-center justify-center gap-2 shadow-md shadow-indigo-200"
        >
          {showForm ? 'Cancel' : <><Plus className="w-4 h-4" /> Add Event</>}
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="bg-white p-6 sm:p-8 rounded-3xl shadow-sm border border-slate-200 mb-8 animation-slideDown">
          <h2 className="text-[11px] uppercase tracking-widest font-bold text-slate-400 mb-6 flex items-center">
            {editingEventId ? 'Edit Event Details' : 'Event Details'}
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Title</label>
              <input 
                type="text" value={title} onChange={e => setTitle(e.target.value)}
                required
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent outline-none transition-all font-medium text-slate-900"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Date & Time</label>
              <input 
                type="datetime-local" value={date} onChange={e => setDate(e.target.value)}
                required
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent outline-none transition-all font-medium text-slate-900"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Location (Optional)</label>
              <input 
                type="text" value={location} onChange={e => setLocation(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent outline-none transition-all font-medium text-slate-900"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Banner Image URL (Optional)</label>
              <input 
                type="text" value={bannerUrl} onChange={e => setBannerUrl(e.target.value)} placeholder="https://..."
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent outline-none transition-all font-medium text-slate-900"
              />
              {bannerUrl && (
                <div className="mt-3 text-xs font-bold text-slate-500 uppercase tracking-widest flex gap-3 items-center">
                   Preview <img src={bannerUrl} alt="Preview" className="h-12 w-20 rounded-lg shadow-sm object-cover border border-slate-200" />
                 </div>
              )}
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Fake Joined Count (Offset)</label>
              <input 
                type="number" min="0" value={fakeJoinCount || ''} onChange={e => setFakeJoinCount(parseInt(e.target.value) || 0)} placeholder="Optional offset"
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent outline-none transition-all font-medium text-slate-900"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Description</label>
              <textarea 
                value={description} onChange={e => setDescription(e.target.value)} rows={3}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent outline-none resize-none transition-all font-medium text-slate-900"
              />
            </div>
          </div>

          <div className="bg-indigo-50/50 p-4 rounded-2xl border border-indigo-100 flex items-center justify-between mt-6">
            <div className="flex items-center gap-3">
              <input 
                type="checkbox" 
                id="eventIsPromoted"
                checked={isPromoted} 
                onChange={e => setIsPromoted(e.target.checked)}
                className="w-4 h-4 text-indigo-600 rounded border-gray-300 focus:ring-indigo-500 cursor-pointer"
              />
              <div className="flex flex-col">
                <label htmlFor="eventIsPromoted" className="text-xs font-bold text-indigo-950 uppercase tracking-wider cursor-pointer">Promote to top slider</label>
                <span className="text-[10px] text-slate-500 font-medium">Highlight this event at the top slider of Student Portal</span>
              </div>
            </div>
          </div>

          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-4 mt-6">
            <div className="flex items-center gap-3">
              <input 
                type="checkbox" 
                id="eventIsPaid"
                checked={isPaid} 
                onChange={e => setIsPaid(e.target.checked)}
                className="w-4 h-4 text-indigo-600 rounded border-gray-300 focus:ring-indigo-500 cursor-pointer"
              />
              <label htmlFor="eventIsPaid" className="text-sm font-bold text-slate-700 uppercase tracking-wider cursor-pointer">Require Payment</label>
            </div>
            
            {isPaid && (
              <div className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Event Fee (৳)</label>
                    <input 
                      type="number" 
                      required={isPaid} 
                      value={feeAmount || ''} 
                      onChange={e => setFeeAmount(parseInt(e.target.value) || 0)} 
                      className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none font-medium text-slate-950" 
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Discount (৳)</label>
                    <input 
                      type="number" 
                      value={discountAmount || ''} 
                      onChange={e => setDiscountAmount(parseInt(e.target.value) || 0)} 
                      className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none font-medium text-slate-950" 
                    />
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-200 flex items-center gap-3">
                  <input 
                    type="checkbox" 
                    id="eventReferralEnabled"
                    checked={referralEnabled} 
                    onChange={e => setReferralEnabled(e.target.checked)}
                    className="w-4 h-4 text-indigo-600 rounded border-gray-300 focus:ring-indigo-500 cursor-pointer"
                  />
                  <div className="flex flex-col">
                    <label htmlFor="eventReferralEnabled" className="text-xs font-bold text-slate-700 uppercase tracking-wider cursor-pointer">Enable Referral Discount</label>
                    <span className="text-[10px] text-slate-500 font-medium">Students can enter a referral code to get an extra discount</span>
                  </div>
                </div>

                {referralEnabled && (
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Extra Referral Discount (৳)</label>
                    <input 
                      type="number" 
                      required={referralEnabled} 
                      value={referralDiscount || ''} 
                      onChange={e => setReferralDiscount(parseInt(e.target.value) || 0)} 
                      placeholder="e.g. 50"
                      className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none font-medium text-slate-950" 
                    />
                  </div>
                )}
              </div>
            )}
          </div>
          <div className="mt-6 flex justify-end gap-3">
            {editingEventId && (
              <button 
                type="button"
                onClick={clearForm}
                className="bg-slate-100 hover:bg-slate-200 text-slate-700 px-6 py-2.5 rounded-xl text-sm font-bold uppercase tracking-wider transition-colors"
              >
                Cancel
              </button>
            )}
            <button 
              type="submit"
              className="bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-2.5 rounded-xl text-sm font-bold uppercase tracking-wider transition-colors shadow-lg shadow-indigo-600/20"
            >
              {editingEventId ? 'Update Event' : 'Save Event'}
            </button>
          </div>
        </form>
      )}

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-[10px] uppercase tracking-widest font-bold text-slate-500">
                <th className="py-4 px-6">Event Info</th>
                <th className="py-4 px-6">Schedule</th>
                <th className="py-4 px-6">Location</th>
                <th className="py-4 px-6 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {events.map((event) => (
                <tr key={event.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="py-4 px-6">
                    <div className="flex items-center gap-4">
                      {event.bannerUrl ? (
                        <img src={event.bannerUrl} alt={event.title} className="w-16 h-12 rounded-lg object-cover border border-slate-200 flex-shrink-0" />
                      ) : (
                        <div className="w-16 h-12 rounded-lg bg-slate-100 border border-slate-200 flex items-center justify-center flex-shrink-0">
                          <CalendarIcon className="w-5 h-5 text-slate-300" />
                        </div>
                      )}
                      <div>
                        <div className="font-bold text-slate-900 text-sm mb-1 flex items-center gap-2">
                          {event.title}
                          {event.isPaid && (
                            <span className="bg-amber-100 text-amber-850 px-1.5 py-0.5 rounded text-[9px] font-black tracking-wider border border-amber-200">
                              ৳{event.feeAmount}
                            </span>
                          )}
                        </div>
                        {event.description && <div className="text-xs font-medium text-slate-500 line-clamp-1">{event.description}</div>}
                        <div className="text-[10px] font-bold text-indigo-600 mt-1 uppercase tracking-widest flex items-center gap-1">
                          <Users className="w-3 h-3" /> {getJoinedUsersCount(event.id) + (event.fakeJoinCount || 0)} Joined
                          {(event.fakeJoinCount || 0) > 0 && <span className="text-slate-400 text-[8px] normal-case">(Real {getJoinedUsersCount(event.id)} + Fake {event.fakeJoinCount})</span>}
                        </div>
                      </div>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-700">
                      <Clock className="w-3.5 h-3.5 text-slate-400" /> 
                      {format(event.date, 'MMM d, yyyy h:mm a')}
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex items-center gap-1.5 text-xs font-medium text-slate-600">
                      <MapPin className="w-3.5 h-3.5 text-slate-400" />
                      {event.location || 'Not specified'}
                    </div>
                  </td>
                  <td className="py-4 px-6 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button 
                        onClick={() => handleEditClick(event)}
                        className="p-2 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors border border-slate-100 hover:border-indigo-100"
                        title="Edit Event"
                      >
                        <Pencil className="w-4 h-4" />
                      </button>
                      {confirmDeleteId === event.id ? (
                        <div className="flex items-center gap-1.5 bg-rose-50 border border-rose-100 px-2.5 py-1.5 rounded-xl animate-in fade-in zoom-in-95 duration-200">
                          <span className="text-[10px] font-black text-rose-800 uppercase px-1">Confirm?</span>
                          <button 
                            onClick={() => {
                              deleteEvent(event.id);
                              setConfirmDeleteId(null);
                            }}
                            className="px-2.5 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-[10px] font-black uppercase tracking-wider transition-all"
                          >
                            Yes
                          </button>
                          <button 
                            onClick={() => setConfirmDeleteId(null)}
                            className="px-2.5 py-1 bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all"
                          >
                            No
                          </button>
                        </div>
                      ) : (
                        <button 
                          onClick={() => setConfirmDeleteId(event.id)}
                          className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors border border-slate-100 hover:border-rose-100"
                          title="Delete Event"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
              {events.length === 0 && (
                <tr>
                  <td colSpan={4} className="py-12 text-center text-slate-500 font-medium">
                    No events found. Click "Add Event" to get started.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
