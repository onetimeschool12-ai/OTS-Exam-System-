import React, { useState } from 'react';
import { useStore } from '../../store/useStore';
import { Banner } from '../../types';
import { Image, Plus, Pencil, Trash2, X, Upload } from 'lucide-react';

export default function AdminBanners() {
  const banners = useStore(state => state.banners) || [];
  const createBanner = useStore(state => state.createBanner);
  const updateBanner = useStore(state => state.updateBanner);
  const deleteBanner = useStore(state => state.deleteBanner);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingBanner, setEditingBanner] = useState<Banner | null>(null);

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    badge: '',
    tagLine: '',
    bannerUrl: '',
    actionText: '',
    actionLink: '',
    isActive: true,
    order: 0,
  });

  const handleOpenModal = (banner?: Banner) => {
    if (banner) {
      setEditingBanner(banner);
      setFormData({
        title: banner.title,
        description: banner.description,
        badge: banner.badge,
        tagLine: banner.tagLine,
        bannerUrl: banner.bannerUrl,
        actionText: banner.actionText,
        actionLink: banner.actionLink || '',
        isActive: banner.isActive,
        order: banner.order,
      });
    } else {
      setEditingBanner(null);
      setFormData({
        title: '',
        description: '',
        badge: '',
        tagLine: '',
        bannerUrl: '',
        actionText: '',
        actionLink: '',
        isActive: true,
        order: 0,
      });
    }
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingBanner) {
      updateBanner(editingBanner.id, formData);
    } else {
      createBanner(formData);
    }
    setIsModalOpen(false);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this banner?')) {
      deleteBanner(id);
    }
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
            <Image className="w-6 h-6 text-indigo-600" /> Manage Banners
          </h1>
          <p className="text-sm text-slate-500">Add, edit, or remove custom slide banners for the student dashboard.</p>
        </div>
        <button
          onClick={() => handleOpenModal()}
          className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl text-sm font-semibold flex items-center gap-2 transition"
        >
          <Plus className="w-4 h-4" /> Add Banner
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {banners.sort((a, b) => a.order - b.order).map(banner => (
          <div key={banner.id} className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm hover:shadow-md transition">
            <div className="h-32 bg-slate-100 relative group overflow-hidden border-b border-slate-100">
              {banner.bannerUrl ? (
                <img src={banner.bannerUrl} alt={banner.title} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center text-slate-400">
                  <Image className="w-8 h-8 mb-2 opacity-50" />
                  <span className="text-xs font-semibold">No Image</span>
                </div>
              )}
              {!banner.isActive && (
                <div className="absolute inset-0 bg-slate-900/40 flex items-center justify-center">
                  <span className="bg-slate-800 text-white text-xs font-bold px-2 py-1 rounded-md">INACTIVE</span>
                </div>
              )}
            </div>
            
            <div className="p-4">
              <div className="flex justify-between items-start mb-2">
                <span className="text-[10px] font-extrabold px-2 py-1 rounded bg-slate-100 text-slate-500 uppercase tracking-wider">{banner.badge || 'Banner'}</span>
                <span className="text-[10px] font-bold text-slate-400">Order: {banner.order}</span>
              </div>
              <h3 className="font-bold text-slate-800 text-sm mb-1">{banner.title}</h3>
              <p className="text-xs text-slate-500 line-clamp-2">{banner.description}</p>
            </div>
            
            <div className="px-4 py-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
               <button 
                 onClick={() => handleOpenModal(banner)}
                 className="text-xs font-semibold text-indigo-600 flex items-center gap-1 hover:text-indigo-800"
               >
                 <Pencil className="w-3.5 h-3.5" /> Edit
               </button>
               <button 
                 onClick={() => handleDelete(banner.id)}
                 className="text-xs font-semibold text-rose-500 flex items-center gap-1 hover:text-rose-700"
               >
                 <Trash2 className="w-3.5 h-3.5" /> Delete
               </button>
            </div>
          </div>
        ))}

        {banners.length === 0 && (
          <div className="col-span-full border-2 border-dashed border-slate-200 rounded-2xl p-10 flex flex-col items-center justify-center text-center">
            <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mb-3">
              <Image className="w-8 h-8 text-slate-400" />
            </div>
            <h3 className="font-bold text-slate-700">No banners added</h3>
            <p className="text-sm text-slate-500 mt-1 mb-4">Create your first custom banner for the main slider.</p>
            <button
               onClick={() => handleOpenModal()}
               className="bg-slate-900 hover:bg-slate-800 text-white px-4 py-2 rounded-xl text-sm font-semibold flex items-center gap-2 transition"
            >
              <Plus className="w-4 h-4" /> Add Banner
            </button>
          </div>
        )}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-2xl rounded-2xl shadow-xl flex flex-col max-h-[90vh]">
            <div className="flex justify-between items-center p-5 border-b border-slate-100 shrink-0">
              <h2 className="text-lg font-bold text-slate-800">
                {editingBanner ? 'Edit Banner' : 'Create Banner'}
              </h2>
              <button 
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 transition bg-slate-100 hover:bg-slate-200 p-2 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 overflow-y-auto flex-1">
              <form id="bannerForm" onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Banner Title</label>
                    <input 
                      type="text" 
                      value={formData.title} 
                      onChange={e => setFormData({...formData, title: e.target.value})}
                      className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                      placeholder="e.g. Prepare for Excellence"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Badge Top Label</label>
                    <input 
                      type="text" 
                      value={formData.badge} 
                      onChange={e => setFormData({...formData, badge: e.target.value})}
                      className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                      placeholder="e.g. Announcements"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Description</label>
                  <textarea 
                    value={formData.description} 
                    onChange={e => setFormData({...formData, description: e.target.value})}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none resize-none h-20"
                    placeholder="Short descriptive text for the banner."
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                     <label className="block text-xs font-bold text-slate-700 mb-1">Tagline</label>
                     <input 
                        type="text" 
                        value={formData.tagLine} 
                        onChange={e => setFormData({...formData, tagLine: e.target.value})}
                        className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                        placeholder="e.g. ⭐ Best Offer"
                     />
                  </div>
                  <div>
                     <label className="block text-xs font-bold text-slate-700 mb-1">Image URL</label>
                     <input 
                        type="url" 
                        value={formData.bannerUrl} 
                        onChange={e => setFormData({...formData, bannerUrl: e.target.value})}
                        className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                        placeholder="https://images.unsplash..."
                     />
                  </div>
                  <div>
                     <label className="block text-xs font-bold text-slate-700 mb-1">Action Button Text</label>
                     <input 
                        type="text" 
                        value={formData.actionText} 
                        onChange={e => setFormData({...formData, actionText: e.target.value})}
                        className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                        placeholder="e.g. Learn More"
                     />
                  </div>
                  <div>
                     <label className="block text-xs font-bold text-slate-700 mb-1">Action Link (Optional)</label>
                     <input 
                        type="url" 
                        value={formData.actionLink} 
                        onChange={e => setFormData({...formData, actionLink: e.target.value})}
                        className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                        placeholder="https://..."
                     />
                  </div>
                </div>

                <div className="flex items-center gap-6 pt-2">
                   <label className="flex items-center gap-2 cursor-pointer">
                      <input 
                         type="checkbox"
                         checked={formData.isActive}
                         onChange={e => setFormData({...formData, isActive: e.target.checked})}
                         className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                      />
                      <span className="text-sm font-semibold text-slate-700">Active (Visible to users)</span>
                   </label>

                   <div className="flex items-center gap-2">
                     <label className="text-xs font-bold text-slate-700">Display Order:</label>
                     <input 
                        type="number" 
                        value={formData.order} 
                        onChange={e => setFormData({...formData, order: parseInt(e.target.value) || 0})}
                        className="w-16 px-2 py-1 border border-slate-200 rounded-lg text-sm text-center focus:ring-2 focus:ring-indigo-500 outline-none"
                     />
                   </div>
                </div>
              </form>
            </div>

            <div className="p-5 border-t border-slate-100 flex justify-end gap-3 shrink-0">
              <button 
                onClick={() => setIsModalOpen(false)}
                className="px-4 py-2 text-slate-500 bg-slate-100 hover:bg-slate-200 rounded-xl text-sm font-semibold transition"
              >
                Cancel
              </button>
              <button 
                type="submit"
                form="bannerForm"
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold transition shadow-sm"
              >
                {editingBanner ? 'Save Changes' : 'Create Banner'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
