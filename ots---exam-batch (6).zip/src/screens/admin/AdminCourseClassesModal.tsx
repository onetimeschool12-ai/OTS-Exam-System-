import React, { useState } from 'react';
import { useStore } from '../../store/useStore';
import { X, Plus, Trash2, Video, FileText, FileEdit, CheckCircle, GripVertical } from 'lucide-react';
import { Course, CourseClass, CourseClassResource } from '../../types';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  course: Course;
}

export default function AdminCourseClassesModal({ isOpen, onClose, course }: Props) {
  const { createCourseClass, updateCourseClass, deleteCourseClass, updateCourse } = useStore();
  
  const [activeTab, setActiveTab] = useState<'classes' | 'subjects' | 'chapters'>('classes');
  
  const [showForm, setShowForm] = useState(false);
  const [editingClassId, setEditingClassId] = useState<string | null>(null);
  const [form, setForm] = useState<{
    title: string;
    subject: string;
    chapter: string;
    videoUrl: string;
    description: string;
    resources: CourseClassResource[];
    isLive: boolean;
    liveStatus: 'upcoming' | 'live' | 'ended';
    livePlatform: 'youtube' | 'facebook' | 'both';
    facebookLiveUrl: string;
    scheduledStartTime: string;
    thumbnailUrl: string;
  }>({
    title: '',
    subject: '',
    chapter: '',
    videoUrl: '',
    description: '',
    resources: [],
    isLive: false,
    liveStatus: 'upcoming',
    livePlatform: 'both',
    facebookLiveUrl: '',
    scheduledStartTime: '',
    thumbnailUrl: ''
  });

  if (!isOpen) return null;

  const handleOpenForm = (courseClass?: CourseClass) => {
    if (courseClass) {
      setEditingClassId(courseClass.id);
      
      // Convert timestamp to datetime-local string
      let dStr = '';
      if (courseClass.scheduledStartTime) {
        try {
          const d = new Date(courseClass.scheduledStartTime);
          // Format as YYYY-MM-DDTHH:MM local time
          const pad = (n: number) => n.toString().padStart(2, '0');
          dStr = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
        } catch (e) {}
      }

      setForm({
        title: courseClass.title,
        subject: courseClass.subject || '',
        chapter: courseClass.chapter || '',
        videoUrl: courseClass.videoUrl,
        description: courseClass.description || '',
        resources: courseClass.resources || [],
        isLive: !!courseClass.isLive,
        liveStatus: courseClass.liveStatus || 'upcoming',
        livePlatform: courseClass.livePlatform || 'both',
        facebookLiveUrl: courseClass.facebookLiveUrl || '',
        scheduledStartTime: dStr,
        thumbnailUrl: courseClass.thumbnailUrl || ''
      });
    } else {
      setEditingClassId(null);
      setForm({
        title: '',
        subject: '',
        chapter: '',
        videoUrl: '',
        description: '',
        resources: [],
        isLive: false,
        liveStatus: 'upcoming',
        livePlatform: 'both',
        facebookLiveUrl: '',
        scheduledStartTime: '',
        thumbnailUrl: ''
      });
    }
    setShowForm(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const timestamp = form.scheduledStartTime ? new Date(form.scheduledStartTime).getTime() : undefined;
    
    const payload = {
      title: form.title,
      subject: form.subject,
      chapter: form.chapter,
      videoUrl: form.videoUrl,
      description: form.description,
      resources: form.resources,
      isLive: form.isLive,
      liveStatus: form.isLive ? form.liveStatus : undefined,
      livePlatform: form.isLive ? form.livePlatform : undefined,
      facebookLiveUrl: form.isLive ? form.facebookLiveUrl : undefined,
      scheduledStartTime: form.isLive ? timestamp : undefined,
      thumbnailUrl: form.thumbnailUrl || undefined
    };

    if (editingClassId) {
      updateCourseClass(course.id, editingClassId, payload);
    } else {
      createCourseClass(course.id, payload);
    }
    setShowForm(false);
  };

  const addResource = () => {
    setForm({
      ...form,
      resources: [
        ...form.resources,
        { id: `res_${Date.now()}`, title: '', url: '', type: 'lecture' }
      ]
    });
  };

  const updateResource = (idx: number, key: keyof CourseClassResource, value: string) => {
    const updated = [...form.resources];
    updated[idx] = { ...updated[idx], [key]: value };
    setForm({ ...form, resources: updated });
  };

  const removeResource = (idx: number) => {
    setForm({ ...form, resources: form.resources.filter((_, i) => i !== idx) });
  };

  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-[60] flex items-center justify-center p-4">
      <div className="bg-white max-w-4xl w-full rounded-3xl overflow-hidden shadow-2xl relative animate-slideDown max-h-[90vh] flex flex-col">
        <button onClick={onClose} className="absolute top-4 right-4 text-slate-400 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 p-2 rounded-full transition-colors z-10">
          <X className="w-4 h-4" />
        </button>
        
        <div className="p-6 border-b border-slate-100 bg-slate-50/50 flex-none">
           <h2 className="text-xl font-display font-bold text-slate-900">Manage Classes & Videos</h2>
           <p className="text-sm font-medium text-slate-500 mt-1">Course: <span className="font-bold text-indigo-600">{course.title}</span></p>
           {!showForm && (
             <div className="flex gap-4 mt-6 border-b border-slate-200">
               <button onClick={() => setActiveTab('classes')} className={`pb-3 text-sm font-bold transition-colors ${activeTab === 'classes' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-slate-500 hover:text-slate-700'}`}>Classes</button>
               <button onClick={() => setActiveTab('subjects')} className={`pb-3 text-sm font-bold transition-colors ${activeTab === 'subjects' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-slate-500 hover:text-slate-700'}`}>Subjects Cover Photos</button>
               <button onClick={() => setActiveTab('chapters')} className={`pb-3 text-sm font-bold transition-colors ${activeTab === 'chapters' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-slate-500 hover:text-slate-700'}`}>Chapters Cover Photos</button>
             </div>
           )}
        </div>

        <div className="flex-1 overflow-y-auto p-6 bg-slate-50">
          {!showForm ? (
            <div>
              {activeTab === 'classes' && (
                <>
                  <div className="flex justify-between items-center mb-6">
                     <h3 className="text-sm font-bold uppercase tracking-widest text-slate-500">Classes List ({course.classes?.length || 0})</h3>
                     <button onClick={() => handleOpenForm()} className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl text-xs font-bold transition-colors flex items-center gap-2 shadow-sm">
                       <Plus className="w-3.5 h-3.5" /> Add Class
                     </button>
                  </div>
              
              <div className="space-y-3">
                {(!course.classes || course.classes.length === 0) && (
                  <div className="text-center py-10 bg-white border border-slate-200 border-dashed rounded-2xl">
                    <Video className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                    <p className="text-sm font-medium text-slate-500">No classes added yet.</p>
                  </div>
                )}
                {course.classes?.map((cls, idx) => (
                  <div key={cls.id} className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex items-start gap-4 hover:border-indigo-200 transition-colors">
                    <div className="w-10 h-10 bg-indigo-50 rounded-xl flex items-center justify-center flex-shrink-0 text-indigo-600 font-bold text-sm">
                      {idx + 1}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="font-bold text-slate-900 truncate">{cls.title}</h4>
                        {cls.isLive && (
                          <span className={`px-2 py-0.5 text-[9px] uppercase font-black tracking-wider rounded-md flex items-center gap-1 ${
                            cls.liveStatus === 'live' 
                              ? 'bg-rose-500 text-white animate-pulse' 
                              : cls.liveStatus === 'upcoming' 
                                ? 'bg-amber-500 text-white' 
                                : 'bg-slate-500 text-white'
                          }`}>
                            <span className={`w-1.5 h-1.5 rounded-full bg-white ${cls.liveStatus === 'live' ? 'animate-ping' : ''}`} />
                            Live {cls.liveStatus}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-500 truncate mt-0.5">{cls.subject && `${cls.subject} `}{cls.chapter && `• ${cls.chapter}`}</p>
                      <p className="text-xs text-slate-400 truncate mt-0.5">
                        {cls.videoUrl} {cls.facebookLiveUrl && `• FB: ${cls.facebookLiveUrl}`}
                      </p>
                      {cls.isLive && cls.scheduledStartTime && (
                        <p className="text-[10px] text-indigo-600 font-bold mt-1 uppercase tracking-wider">
                          Scheduled: {new Date(cls.scheduledStartTime).toLocaleString('bn-BD', { hour12: true })}
                        </p>
                      )}
                      <div className="flex flex-wrap gap-2 mt-2">
                        {cls.resources?.map(res => (
                          <span key={res.id} className="bg-slate-100 text-slate-600 text-[10px] uppercase font-bold tracking-wider px-2 py-1 rounded-md border border-slate-200 flex items-center gap-1">
                            {res.type === 'lecture' && <FileText className="w-3 h-3" />}
                            {res.type === 'practice' && <FileEdit className="w-3 h-3" />}
                            {res.type === 'solution' && <CheckCircle className="w-3 h-3" />}
                            {res.title || res.type}
                          </span>
                        ))}
                      </div>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <button onClick={() => handleOpenForm(cls)} className="p-2 hover:bg-slate-100 text-slate-600 rounded-lg transition-colors">
                        <FileEdit className="w-4 h-4" />
                      </button>
                      <button onClick={() => deleteCourseClass(course.id, cls.id)} className="p-2 hover:bg-rose-50 text-rose-600 rounded-lg transition-colors">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
              </>
              )}

              {activeTab === 'subjects' && (
                <SubjectsTab course={course} updateCourse={updateCourse} />
              )}
              
              {activeTab === 'chapters' && (
                <ChaptersTab course={course} updateCourse={updateCourse} />
              )}
            </div>
          ) : (
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
               <h3 className="text-sm font-bold uppercase tracking-widest text-slate-500 mb-6 pb-4 border-b border-slate-100">
                 {editingClassId ? 'Edit Class Details' : 'Add New Class'}
               </h3>
               
               <form id="classForm" onSubmit={handleSubmit} className="space-y-5">
                 <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Class Title</label>
                    <input type="text" required value={form.title} onChange={e => setForm({...form, title: e.target.value})} className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none font-medium" placeholder="E.g., Integration Part 1" />
                 </div>
                 
                 <div className="grid grid-cols-2 gap-4">
                   <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Subject</label>
                      <input type="text" value={form.subject} onChange={e => setForm({...form, subject: e.target.value})} className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none font-medium text-sm" placeholder="E.g., Biology 1st Paper" />
                   </div>
                   <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Chapter</label>
                      <input type="text" value={form.chapter} onChange={e => setForm({...form, chapter: e.target.value})} className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none font-medium text-sm" placeholder="E.g., Chapter 1: ..." />
                   </div>
                 </div>
                 
                 <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">YouTube URL</label>
                    <input type="url" required={!form.isLive} value={form.videoUrl} onChange={e => setForm({...form, videoUrl: e.target.value})} className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none font-medium text-slate-600" placeholder="https://youtube.com/watch?v=..." />
                    <p className="text-[10px] text-slate-500 font-medium mt-1 uppercase tracking-widest">Unlisted or Public YouTube Video Link</p>
                    {/* Live Class Configuration Toggle Details */}
                    <div className="bg-indigo-50/50 p-4 rounded-xl border border-indigo-100/60 mt-4 space-y-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <label className="block text-xs font-bold text-slate-800">Live Class Settings (লাইভ ক্লাস সেটিংস)</label>
                          <p className="text-[9px] text-slate-500 font-bold">Enable livestream option on YouTube or Facebook Group.</p>
                        </div>
                        <input 
                          type="checkbox" 
                          checked={form.isLive} 
                          onChange={e => setForm({...form, isLive: e.target.checked})} 
                          className="w-4 h-4 text-indigo-600 rounded cursor-pointer" 
                        />
                      </div>
                      {form.isLive && (
                        <div className="space-y-3 border-t border-indigo-100/40 pt-3 animate-fadeIn">
                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <label className="block text-[9px] font-bold text-slate-600 uppercase">Platform (প্ল্যাটফর্ম)</label>
                              <select 
                                value={form.livePlatform} 
                                onChange={e => setForm({...form, livePlatform: e.target.value as any})} 
                                className="w-full text-xs p-1.5 border border-slate-200 rounded-lg bg-white font-medium"
                              >
                                <option value="both">Both (YouTube & Facebook)</option>
                                <option value="youtube">YouTube Live only</option>
                                <option value="facebook">Facebook Group / Video only</option>
                              </select>
                            </div>
                            <div>
                              <label className="block text-[9px] font-bold text-slate-600 uppercase">Live Status (লাইভ স্ট্যাটাস)</label>
                              <select 
                                value={form.liveStatus} 
                                onChange={e => setForm({...form, liveStatus: e.target.value as any})} 
                                className="w-full text-xs p-1.5 border border-slate-200 rounded-lg bg-white font-medium"
                              >
                                <option value="upcoming">Upcoming (আসন্ন ক্লাস)</option>
                                <option value="live">Live Now (লাইভ চলছে)</option>
                                <option value="ended">Ended (লাইভ শেষ হয়েছে)</option>
                              </select>
                            </div>
                          </div>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                            <div>
                              <label className="block text-[9px] font-bold text-slate-600 uppercase">Facebook Live / Group URL</label>
                              <input 
                                type="url" 
                                value={form.facebookLiveUrl} 
                                onChange={e => setForm({...form, facebookLiveUrl: e.target.value})} 
                                placeholder="E.g., https://facebook.com/groups/..." 
                                className="w-full text-xs p-1.5 border border-slate-200 rounded-lg" 
                              />
                            </div>
                            <div>
                              <label className="block text-[9px] font-bold text-slate-600 uppercase">Scheduled Start Time (নির্ধারিত সময়)</label>
                              <input 
                                type="datetime-local" 
                                value={form.scheduledStartTime} 
                                onChange={e => setForm({...form, scheduledStartTime: e.target.value})} 
                                className="w-full text-xs p-1.5 border border-slate-200 rounded-lg bg-white" 
                              />
                            </div>
                          </div>
                          <div>
                            <label className="block text-[9px] font-bold text-slate-600 uppercase">Live Class Thumbnail Image URL (থাম্বনিল ইমেজ লিংক)</label>
                            <input 
                              type="url" 
                              value={form.thumbnailUrl} 
                              onChange={e => setForm({...form, thumbnailUrl: e.target.value})} 
                              placeholder="E.g., https://images.unsplash.com/photo-... or dynamic poster URL" 
                              className="w-full text-xs p-1.5 border border-slate-200 rounded-lg outline-none focus:ring-1 focus:ring-indigo-500" 
                            />
                            <p className="text-[9px] text-slate-400 mt-0.5">We will show this thumbnail image to students before the class goes live.</p>
                          </div>
                        </div>
                      )}
                    </div>
                 </div>
                 
                 <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Description (Optional)</label>
                    <textarea rows={2} value={form.description} onChange={e => setForm({...form, description: e.target.value})} className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none font-medium resize-y" />
                 </div>
                 
                 <div className="pt-4 border-t border-slate-100">
                    <div className="flex justify-between items-center mb-4">
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">Resources (PDF Links)</label>
                      <button type="button" onClick={addResource} className="bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 py-1.5 rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5">
                        <Plus className="w-3 h-3" /> Add Resource
                      </button>
                    </div>
                    
                    <div className="space-y-3">
                      {form.resources.map((res, idx) => (
                        <div key={res.id} className="flex gap-2 items-start bg-slate-50 p-3 rounded-xl border border-slate-200">
                           <div className="w-full flex-1 space-y-2">
                             <div className="flex gap-2">
                               <input type="text" required placeholder="Title (e.g. Lecture Sheet)" value={res.title} onChange={e => updateResource(idx, 'title', e.target.value)} className="w-1/2 px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm outline-none focus:border-indigo-500" />
                               <select value={res.type} onChange={e => updateResource(idx, 'type', e.target.value)} className="w-1/2 px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm outline-none focus:border-indigo-500">
                                 <option value="lecture">Lecture Sheet</option>
                                 <option value="practice">Practice Sheet</option>
                                 <option value="solution">Solution Sheet</option>
                                 <option value="other">Other</option>
                               </select>
                             </div>
                             <input type="url" required placeholder="PDF URL (e.g. Google Drive Link)" value={res.url} onChange={e => updateResource(idx, 'url', e.target.value)} className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm outline-none focus:border-indigo-500" />
                           </div>
                           <button type="button" onClick={() => removeResource(idx)} className="p-2 ml-1 mt-1 text-rose-500 hover:bg-rose-50 rounded-lg transition-colors">
                             <Trash2 className="w-4 h-4" />
                           </button>
                        </div>
                      ))}
                    </div>
                 </div>
                 
                 <div className="flex gap-3 pt-6 border-t border-slate-100">
                   <button type="button" onClick={() => setShowForm(false)} className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 py-3 rounded-xl font-bold uppercase tracking-wider transition-colors">
                     Cancel
                   </button>
                   <button type="submit" className="flex-[2] bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded-xl font-bold uppercase tracking-wider transition-colors shadow-lg shadow-indigo-600/20">
                     Save Class
                   </button>
                 </div>
               </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function SubjectsTab({ course, updateCourse }: { course: Course; updateCourse: (id: string, data: Partial<Course>) => void }) {
  const subjects = Array.from(new Set(course.classes?.map(c => c.subject || 'General') || []));
  const currentMeta = course.subjectsMeta || [];

  const updateSubjectImage = (subjectName: string, imageUrl: string) => {
    let newMeta = [...currentMeta];
    const idx = newMeta.findIndex(m => m.name === subjectName);
    if (idx >= 0) {
      newMeta[idx] = { ...newMeta[idx], imageUrl };
    } else {
      newMeta.push({ name: subjectName, imageUrl });
    }
    updateCourse(course.id, { subjectsMeta: newMeta });
  };

  return (
    <div>
      <h3 className="text-sm font-bold uppercase tracking-widest text-slate-500 mb-6">Subject Cover Photos</h3>
      {subjects.length === 0 ? (
        <p className="text-sm text-slate-500">No subjects found. Create a class with a subject first.</p>
      ) : (
        <div className="space-y-4">
          {subjects.map(sub => {
            const meta = currentMeta.find(m => m.name === sub);
            return (
              <div key={sub} className="bg-white p-4 rounded-xl border border-slate-200">
                <div className="font-bold text-slate-900 mb-2">{sub}</div>
                <input 
                  type="text" 
                  value={meta?.imageUrl || ''} 
                  onChange={(e) => updateSubjectImage(sub, e.target.value)}
                  placeholder="Enter Image URL (e.g. https://...)" 
                  className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm"
                />
                {meta?.imageUrl && (
                  <div className="mt-3 relative h-24 overflow-hidden rounded-lg bg-slate-100">
                    <img src={meta.imageUrl} alt={sub} className="w-full h-full object-cover" />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function ChaptersTab({ course, updateCourse }: { course: Course; updateCourse: (id: string, data: Partial<Course>) => void }) {
  const chapters = Array.from(new Set(course.classes?.filter(c => c.chapter).map(c => JSON.stringify({ sub: c.subject || 'General', chapter: c.chapter })) || []))
    .map(c => JSON.parse(c) as { sub: string, chapter: string });
  
  const currentMeta = course.chaptersMeta || [];

  const updateChapterImage = (subjectName: string, chapterName: string, imageUrl: string) => {
    let newMeta = [...currentMeta];
    const idx = newMeta.findIndex(m => m.subjectName === subjectName && m.chapterName === chapterName);
    if (idx >= 0) {
      newMeta[idx] = { ...newMeta[idx], imageUrl };
    } else {
      newMeta.push({ subjectName, chapterName, imageUrl });
    }
    updateCourse(course.id, { chaptersMeta: newMeta });
  };

  return (
    <div>
      <h3 className="text-sm font-bold uppercase tracking-widest text-slate-500 mb-6">Chapter Cover Photos</h3>
      {chapters.length === 0 ? (
        <p className="text-sm text-slate-500">No chapters found. Create a class with a chapter first.</p>
      ) : (
        <div className="space-y-4">
          {chapters.map(c => {
            const meta = currentMeta.find(m => m.subjectName === c.sub && m.chapterName === c.chapter);
            return (
              <div key={`${c.sub}-${c.chapter}`} className="bg-white p-4 rounded-xl border border-slate-200">
                <div className="font-bold text-slate-900 text-sm mb-1">{c.sub}</div>
                <div className="font-bold text-slate-700 text-xs uppercase tracking-wider mb-2">{c.chapter}</div>
                <input 
                  type="text" 
                  value={meta?.imageUrl || ''} 
                  onChange={(e) => updateChapterImage(c.sub, c.chapter, e.target.value)}
                  placeholder="Enter Image URL (e.g. https://...)" 
                  className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm"
                />
                {meta?.imageUrl && (
                  <div className="mt-3 relative h-24 overflow-hidden rounded-lg bg-slate-100">
                    <img src={meta.imageUrl} alt={c.chapter} className="w-full h-full object-cover" />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
