import React, { useState, useMemo } from 'react';
import { useStore, getReferralCodeForTarget } from '../../store/useStore';
import { Users, TrendingUp, DollarSign, Award, Search, FileText, CheckCircle2 } from 'lucide-react';

interface AmbassadorRow {
  userId: string;
  name: string;
  email: string;
  mobile: string;
  activeCodes: { name: string; code: string }[];
  referralCount: number;
  totalSalesGenerated: number;
  referredFriends: {
    friendName: string;
    courseName: string;
    amountPaid: number;
    date: number;
  }[];
}

export default function AdminReferrals() {
  const { users, payments, courses, events } = useStore();
  const [searchQuery, setSearchQuery] = useState('');

  // Calculate Ambassador metrics based on real verified payments
  const leaderboardData = useMemo(() => {
    // Collect all users who are students
    const students = users.filter(u => u.role === 'user');

    const rows: AmbassadorRow[] = students.map(student => {
      // Filter payments that were referred by this student and are verified
      const successfulPayments = payments.filter(
        p => p.referredByUserId === student.id && p.status === 'verified'
      );

      const referredFriends = successfulPayments.map(pay => {
        const friend = users.find(u => u.id === pay.userId);
        const targetCourse = courses.find(c => c.id === pay.targetId);
        const targetEvent = events.find(e => e.id === pay.targetId);
        const itemName = targetCourse?.title || targetEvent?.title || 'Paid Entrance';

        return {
          friendName: friend?.name || 'Student Account',
          courseName: itemName,
          amountPaid: pay.amount,
          date: pay.createdAt
        };
      });

      const totalSales = successfulPayments.reduce((sum, current) => sum + current.amount, 0);

      // Generate active dynamic codes for student's enrolled courses and joined events
      const studentEnrolledCourses = student.enrolledCourses || [];
      const studentJoinedEvents = student.joinedEvents || [];

      const activeCodesList: { name: string; code: string }[] = [];

      studentEnrolledCourses.forEach(cid => {
        const course = courses.find(c => c.id === cid);
        if (course) {
          activeCodesList.push({
            name: course.title,
            code: getReferralCodeForTarget(student.id, cid, student.name).toUpperCase()
          });
        }
      });

      studentJoinedEvents.forEach(eid => {
        const ev = events.find(e => e.id === eid);
        if (ev) {
          activeCodesList.push({
            name: ev.title,
            code: getReferralCodeForTarget(student.id, eid, student.name).toUpperCase()
          });
        }
      });

      return {
        userId: student.id,
        name: student.name,
        email: student.email,
        mobile: student.profile?.mobile || 'N/A',
        activeCodes: activeCodesList,
        referralCount: successfulPayments.length,
        totalSalesGenerated: totalSales,
        referredFriends
      };
    });

    // Sort by count descending, then by sales descending
    return rows.sort((a, b) => b.referralCount - a.referralCount || b.totalSalesGenerated - a.totalSalesGenerated);
  }, [users, payments, courses, events]);

  // Overall Statistics Panel computations
  const totalReferralSales = useMemo(() => {
    return payments
      .filter(p => p.referredByUserId && p.status === 'verified')
      .reduce((sum, current) => sum + current.amount, 0);
  }, [payments]);

  const totalReferralAdmissions = useMemo(() => {
    return payments.filter(p => p.referredByUserId && p.status === 'verified').length;
  }, [payments]);

  const topAmbassador = useMemo(() => {
    if (leaderboardData.length === 0) return null;
    const top = leaderboardData[0];
    return top.referralCount > 0 ? top : null;
  }, [leaderboardData]);

  // Search filter
  const filteredLeaderboard = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return leaderboardData;
    return leaderboardData.filter(
      row =>
        row.name.toLowerCase().includes(q) ||
        row.mobile.toLowerCase().includes(q) ||
        row.activeCodes.some(c => c.code.toLowerCase().includes(q))
    );
  }, [leaderboardData, searchQuery]);

  return (
    <div className="space-y-8 animate-fadeIn text-left">
      <div>
        <h1 className="text-3xl font-display font-bold text-slate-900 tracking-tight">Referrals & Affiliation Program</h1>
        <p className="text-slate-500 text-sm mt-1 font-medium">Analyze ambassador performance, track student affiliate discounts, and monitor successful referred sales.</p>
      </div>

      {/* Analytics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4 hover:border-indigo-250 transition-colors">
          <div className="w-14 h-14 bg-indigo-50 rounded-xl flex items-center justify-center text-indigo-600 shrink-0">
            <DollarSign className="h-7 w-7" />
          </div>
          <div>
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest block mb-0.5">Total Referral Revenue</span>
            <span className="text-2xl font-black text-slate-900">৳{totalReferralSales}</span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4 hover:border-indigo-250 transition-colors">
          <div className="w-14 h-14 bg-emerald-50 rounded-xl flex items-center justify-center text-emerald-600 shrink-0">
            <TrendingUp className="h-7 w-7" />
          </div>
          <div>
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest block mb-0.5">Referred Admissions</span>
            <span className="text-2xl font-black text-slate-900">{totalReferralAdmissions} Students</span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4 hover:border-indigo-250 transition-colors">
          <div className="w-14 h-14 bg-amber-50 rounded-xl flex items-center justify-center text-amber-500 shrink-0">
            <Award className="h-7 w-7" />
          </div>
          <div className="min-w-0">
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest block mb-0.5">Top Ambassador User</span>
            <span className="text-base font-black text-slate-900 block truncate">
              {topAmbassador ? `${topAmbassador.name} (${topAmbassador.referralCount} Ref)` : 'No Referrals Yet'}
            </span>
          </div>
        </div>
      </div>

      {/* Main Table Screen */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-50/50">
          <div>
            <h2 className="text-base font-bold text-slate-900">Affiliate Referral Leaderboard</h2>
            <p className="text-xs text-slate-400 font-semibold tracking-wider uppercase mt-0.5">Ranked by verified refer counts</p>
          </div>

          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input 
              type="text" 
              placeholder="Search by student or code..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="pl-9 pr-4 py-2 bg-white border border-slate-200 rounded-xl outline-none focus:border-indigo-500 text-xs font-bold transition-all w-full sm:w-64"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                <th className="py-4 px-6 text-center w-16">Rank</th>
                <th className="py-4 px-6">Student Brand Ambassador</th>
                <th className="py-4 px-6">Referral Code</th>
                <th className="py-4 px-6 text-center">Successful Refers</th>
                <th className="py-4 px-6 text-right">Total Revenue Generated</th>
                <th className="py-4 px-6">Referred Friends</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredLeaderboard.map((row, index) => {
                const isRanked = row.referralCount > 0;
                return (
                  <tr key={row.userId} className="hover:bg-slate-50/80 transition-colors">
                    {/* Rank Badge */}
                    <td className="py-4 px-6 text-center">
                      {isRanked ? (
                        <span className={`inline-flex items-center justify-center w-6 h-6 rounded-lg text-xs font-black ${
                          index === 0 ? 'bg-amber-100 text-amber-700 border border-amber-200' :
                          index === 1 ? 'bg-slate-100 text-slate-600 border border-slate-200' :
                          index === 2 ? 'bg-orange-100 text-orange-700 border border-orange-200' :
                          'bg-slate-50 text-slate-500'
                        }`}>
                          {index + 1}
                        </span>
                      ) : (
                        <span className="text-slate-350 text-xs">-</span>
                      )}
                    </td>

                    {/* Student Name */}
                    <td className="py-4 px-6">
                      <div>
                        <div className="font-extrabold text-slate-900 border-none inline-block text-sm leading-tight">{row.name}</div>
                        <div className="text-[10px] font-bold text-slate-450 text-slate-400 mt-1 uppercase tracking-wider">
                          Mobile: {row.mobile}
                        </div>
                      </div>
                    </td>

                    {/* Referral Codes */}
                    <td className="py-4 px-6 z-10">
                      {row.activeCodes.length === 0 ? (
                        <span className="text-[10px] text-slate-400 italic">No active enrollments</span>
                      ) : (
                        <div className="flex flex-col gap-1.5 max-w-[220px]">
                          {row.activeCodes.map((ac, idx) => (
                            <div key={idx} className="flex flex-col gap-0.5 bg-indigo-50/40 border border-indigo-100/40 rounded-lg p-1.5 hover:bg-indigo-50 transition-colors">
                              <span className="text-[8px] font-black text-slate-400 uppercase tracking-wider truncate" title={ac.name}>
                                {ac.name}
                              </span>
                              <span className="font-mono font-black text-[10px] text-indigo-600 uppercase tracking-wider">
                                {ac.code}
                              </span>
                            </div>
                          ))}
                        </div>
                      )}
                    </td>

                    {/* Success Count */}
                    <td className="py-4 px-6 text-center">
                      <span className={`inline-flex items-center gap-1 text-sm font-black ${row.referralCount > 0 ? 'text-emerald-600' : 'text-slate-400'}`}>
                        {row.referralCount > 0 && <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />}
                        {row.referralCount}
                      </span>
                    </td>

                    {/* Revenue Generated */}
                    <td className="py-4 px-6 text-right font-mono font-bold text-sm text-slate-800">
                      ৳{row.totalSalesGenerated}
                    </td>

                    {/* Referred Friends lists */}
                    <td className="py-4 px-6">
                      {row.referredFriends.length === 0 ? (
                        <span className="text-[10px] text-slate-400 italic">No referred checkouts</span>
                      ) : (
                        <div className="flex flex-wrap gap-1.5 max-w-sm">
                          {row.referredFriends.map((friend, idx) => (
                            <span 
                              key={idx} 
                              className="text-[9px] font-semibold bg-slate-100 text-slate-700 px-2 py-0.5 rounded-full border border-slate-200"
                              title={`Enrolled in ${friend.friendName} | Paid Price: ৳${friend.amountPaid}`}
                            >
                              {friend.friendName} ({friend.courseName.slice(0,10)}...)
                            </span>
                          ))}
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}

              {filteredLeaderboard.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-400 font-medium whitespace-nowrap">
                    No matching student brand ambassadors located.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
