import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useStore } from '../../store/useStore';
import { Exam, Question } from '../../types';
import { ArrowLeft, Plus, Trash2, Upload, Download, ArrowUp, ArrowDown, Image as ImageIcon } from 'lucide-react';
import { format } from 'date-fns';
import Papa from 'papaparse';
import { ImageUpload } from '../../components/ImageUpload';

export default function AdminExamForm() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { exams, createExam, updateExam, courses, events, categories } = useStore();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const isEditing = !!id;
  const existingExam = isEditing ? exams.find(e => e.id === id) : null;

  const [title, setTitle] = useState(existingExam?.title || '');
  const [description, setDescription] = useState(existingExam?.description || '');
  const [thumbnailUrl, setThumbnailUrl] = useState(existingExam?.thumbnailUrl || '');
  const [subject, setSubject] = useState(existingExam?.subject || '');
  const [category, setCategory] = useState(existingExam?.category || '');
  const [subCategory, setSubCategory] = useState(existingExam?.subCategory || '');
  const [durationMinutes, setDurationMinutes] = useState(existingExam?.durationMinutes || 30);
  
  const [isPaid, setIsPaid] = useState(existingExam?.isPaid || false);
  const [feeAmount, setFeeAmount] = useState(existingExam?.feeAmount || 0);
  const [discountAmount, setDiscountAmount] = useState(existingExam?.discountAmount || 0);
  
  const [accessType, setAccessType] = useState(existingExam?.accessType || 'public');
  const [courseIds, setCourseIds] = useState<string[]>(existingExam?.courseIds || []);
  const [eventIds, setEventIds] = useState<string[]>(existingExam?.eventIds || []);
  
  const [hasNegativeMarking, setHasNegativeMarking] = useState(existingExam?.hasNegativeMarking || false);
  const [negativeMarksPerWrongAnswer, setNegativeMarksPerWrongAnswer] = useState(existingExam?.negativeMarksPerWrongAnswer || 0.25);
  
  const [instructionsBn, setInstructionsBn] = useState(existingExam?.instructionsBn || '');
  const [instructionsEn, setInstructionsEn] = useState(existingExam?.instructionsEn || '');
  
  const [examType, setExamType] = useState<'live' | 'practice'>(existingExam?.examType || 'live');
  const [publishType, setPublishType] = useState<'instant' | 'manual'>(existingExam?.publishType || 'instant');
  
  // Format for datetime-local input
  const formatForInput = (timestamp: number) => {
    return new Date(timestamp - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 16);
  };
  
  const [startTime, setStartTime] = useState(
    existingExam ? formatForInput(existingExam.startTime) : formatForInput(Date.now() + 86400000)
  );
  
  const [endTime, setEndTime] = useState(
    existingExam ? formatForInput(existingExam.endTime) : formatForInput(Date.now() + 172800000)
  );

  const [questions, setQuestions] = useState<Question[]>(existingExam?.questions || []);

  const handleAddQuestion = () => {
    setQuestions([
      ...questions,
      {
        id: `q_${Date.now()}_${Math.random()}`,
        text: '',
        options: ['', '', '', ''],
        correctOptionIndex: 0,
        marks: 1
      }
    ]);
  };

  const handleBulkUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      transformHeader: (header) => header.trim().toLowerCase(),
      complete: (results) => {
        const newQuestions: Question[] = [];
        
        results.data.forEach((row: any) => {
          let qText = row['question'] || row['question '];
          let opt1 = row['option1'] || row['option 1'] || row['option_1'] || '';
          let opt2 = row['option2'] || row['option 2'] || row['option_2'] || '';
          let opt3 = row['option3'] || row['option 3'] || row['option_3'] || '';
          let opt4 = row['option4'] || row['option 4'] || row['option_4'] || '';
          let coi = row['correctoptionindex'] || row['correct option index'] || row['correct option'] || row['answer'];
          let marks = row['marks'] || row['mark'];
          let imageUrl = row['imageurl'] || row['image url'] || row['image_url'] || row['image'] || '';
          let explanation = row['explanation'] || row['solution'] || '';
          let explanationImageUrl = row['explanationimageurl'] || row['solutionimage'] || '';

          // Fallback for improperly quoted CSVs where everything is clumped into one key-value pair
          if (!qText && Object.keys(row).length === 1) {
             const key = Object.keys(row)[0];
             const val = row[key];
             if (key.includes('question') && key.includes('option1')) {
                // Try to split the value line manually by comma from the end
                // E.g. "Question Text With Commas?,16,4,1,0,2,1"
                if (typeof val === 'string') {
                    // split from end to get marks, coi, opt4, opt3, opt2, opt1
                    const parts = val.split(',');
                    if (parts.length >= 6) {
                        marks = parts.pop();
                        coi = parts.pop();
                        opt4 = parts.pop();
                        opt3 = parts.pop();
                        opt2 = parts.pop();
                        opt1 = parts.pop();
                        qText = parts.join(','); // The rest is the question text
                    }
                }
             }
          }

          if (qText && coi !== undefined) {
            let parsedCoi = parseInt(coi, 10);
            if (isNaN(parsedCoi)) parsedCoi = 1;

            newQuestions.push({
              id: `q_${Date.now()}_${Math.random()}`,
              text: (qText + "").trim(),
              imageUrl: imageUrl.trim() || undefined,
              options: [opt1, opt2, opt3, opt4].filter(Boolean),
              correctOptionIndex: Math.max(0, parsedCoi - 1), // Assume CSV has 1-4, convert to 0-3
              marks: marks ? parseFloat(marks) || 1 : 1,
              explanation: explanation.trim() || undefined,
              explanationImageUrl: explanationImageUrl.trim() || undefined
            });
          }
        });

        if (newQuestions.length > 0) {
          setQuestions(prev => [...prev, ...newQuestions]);
          alert(`Successfully added ${newQuestions.length} questions from CSV.`);
        } else {
          alert('No valid questions found in CSV. Please ensure headers are: Question, Option1, Option2, Option3, Option4, CorrectOptionIndex, Marks (Optional). Download the template to see the correct format.');
        }
        
        if (fileInputRef.current) {
          fileInputRef.current.value = '';
        }
      },
      error: (error) => {
        alert('Error parsing CSV file');
        console.error(error);
      }
    });
  };

  const downloadCSVTemplate = () => {
    const csvContent = "Question,Option1,Option2,Option3,Option4,CorrectOptionIndex,Marks\n" +
                       "What is the capital of Bangladesh?,Khulna,Dhaka,Sylhet,Rajshahi,2,1\n" +
                       "Which planet is known as the Red Planet?,Venus,Jupiter,Mars,Saturn,3,1\n";
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", "Exam_Questions_Template.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleQuestionChange = (index: number, field: keyof Question | 'option', value: any, optionIndex?: number) => {
    const updated = [...questions];
    if (field === 'option' && optionIndex !== undefined) {
      updated[index].options[optionIndex] = value;
    } else {
      updated[index] = { ...updated[index], [field]: value };
    }
    setQuestions(updated);
  };

  const handleRemoveQuestion = (index: number) => {
    setQuestions(questions.filter((_, i) => i !== index));
  };

  const handleMoveQuestion = (index: number, direction: 'up' | 'down') => {
    if (direction === 'up' && index === 0) return;
    if (direction === 'down' && index === questions.length - 1) return;
    const updated = [...questions];
    const newIndex = direction === 'up' ? index - 1 : index + 1;
    [updated[index], updated[newIndex]] = [updated[newIndex], updated[index]];
    setQuestions(updated);
  };

  const handleSave = () => {
    const examData: Omit<Exam, 'id' | 'createdAt'> = {
      title,
      description,
      thumbnailUrl,
      subject,
      category,
      subCategory,
      durationMinutes: Number(durationMinutes),
      startTime: new Date(startTime).getTime(),
      endTime: new Date(endTime).getTime(),
      status: 'published',
      questions,
      isPaid: false,
      feeAmount: 0,
      discountAmount: 0,
      accessType,
      courseIds,
      eventIds,
      hasNegativeMarking,
      negativeMarksPerWrongAnswer,
      instructionsBn,
      instructionsEn,
      examType,
      publishType,
      resultsPublished: publishType === 'instant' ? true : (existingExam?.resultsPublished ?? false),
    };

    if (isEditing && id) {
      updateExam(id, examData);
    } else {
      createExam(examData);
    }
    navigate('/admin/exams');
  };

  return (
    <div className="max-w-4xl mx-auto pb-20">
      <div className="flex items-center gap-4 mb-8">
        <button 
          onClick={() => navigate('/admin/exams')}
          className="p-2 hover:bg-gray-100 rounded-full transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-gray-500" />
        </button>
        <div>
          <h1 className="text-3xl font-display font-bold text-slate-900 tracking-tight">{isEditing ? 'Edit Exam' : 'Create New Exam'}</h1>
        </div>
      </div>

      <div className="space-y-8">
        {/* Basic Details */}
        <section className="bg-white p-6 sm:p-8 rounded-3xl shadow-sm border border-slate-200">
          <h2 className="text-[11px] uppercase tracking-widest font-bold text-slate-400 mb-6 flex items-center">
            Basic Information
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Title</label>
              <input 
                type="text" value={title} onChange={e => setTitle(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent outline-none transition-all font-medium text-slate-900"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Description</label>
              <textarea 
                value={description} onChange={e => setDescription(e.target.value)} rows={3}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent outline-none resize-none transition-all font-medium text-slate-900"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Subject</label>
              <input 
                type="text" value={subject} onChange={e => setSubject(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent outline-none transition-all font-medium text-slate-900"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider font-semibold">Category (Batch)</label>
              <select 
                required
                value={category} 
                onChange={e => {
                  setCategory(e.target.value);
                  setSubCategory('');
                }}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent outline-none transition-all font-medium text-slate-900 cursor-pointer"
              >
                <option value="">-- Select Category --</option>
                {(categories || []).map(cat => (
                  <option key={cat.id} value={cat.name}>{cat.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider font-semibold">Sub-Category (Segment)</label>
              <select 
                value={subCategory} 
                onChange={e => setSubCategory(e.target.value)} 
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent outline-none transition-all font-medium text-slate-900 cursor-pointer"
              >
                <option value="">-- None / General --</option>
                {((categories || []).find(cat => cat.name === category)?.subCategories || []).map(sub => (
                  <option key={sub} value={sub}>{sub}</option>
                ))}
              </select>
            </div>
            <div className="sm:col-span-2">
               <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Thumbnail Image</label>
               <ImageUpload 
                 placeholder="Drag & drop or click to upload Exam Thumbnail"
                 value={thumbnailUrl} 
                 onChange={value => setThumbnailUrl(value || '')}
               />
            </div>
          </div>
        </section>

        {/* Custom Instructions */}
        <section className="bg-white p-6 sm:p-8 rounded-3xl shadow-sm border border-slate-200">
          <h2 className="text-[11px] uppercase tracking-widest font-bold text-slate-400 mb-6 flex items-center">
            Custom Instructions
          </h2>
          <div className="space-y-5">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Instructions (Bengali) - optional</label>
              <textarea 
                value={instructionsBn} 
                onChange={e => setInstructionsBn(e.target.value)} 
                rows={4}
                placeholder="১. প্রতিটি MCQ প্রশ্নের জন্য চারটি করে option আছে..."
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent outline-none resize-y transition-all font-medium text-slate-900"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Instructions (English) - optional</label>
              <textarea 
                value={instructionsEn} 
                onChange={e => setInstructionsEn(e.target.value)} 
                rows={4}
                placeholder="1. There are four options for each MCQ question..."
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent outline-none resize-y transition-all font-medium text-slate-900"
              />
            </div>
          </div>
        </section>

        {/* Schedule */}
        <section className="bg-white p-6 sm:p-8 rounded-3xl shadow-sm border border-slate-200">
          <h2 className="text-[11px] uppercase tracking-widest font-bold text-slate-400 mb-6 flex items-center">
            Timing & Schedule
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Duration (minutes)</label>
              <input 
                type="number" value={durationMinutes} onChange={e => setDurationMinutes(Number(e.target.value))} min={1}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent outline-none transition-all font-bold text-slate-900 font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Start Time</label>
              <input 
                type="datetime-local" value={startTime} onChange={e => setStartTime(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent outline-none transition-all font-medium text-slate-900"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">End Time</label>
              <input 
                type="datetime-local" value={endTime} onChange={e => setEndTime(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent outline-none transition-all font-medium text-slate-900"
              />
            </div>
          </div>
        </section>

        {/* Scoring & Leaderboard Configuration */}
        <section className="bg-white p-6 sm:p-8 rounded-3xl shadow-sm border border-slate-200 space-y-4">
          <h2 className="text-[11px] uppercase tracking-widest font-bold text-slate-400">
            Exam Mode & Result Publication
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Exam Type</label>
              <select 
                value={examType} onChange={e => setExamType(e.target.value as any)}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent outline-none transition-all font-semibold text-slate-800 cursor-pointer"
              >
                <option value="live">⚡ Live/Mock Exam (Auto Leaderboard, Restricted Attempts; auto-covert to Practice after End Time)</option>
                <option value="practice">🧠 Pure Practice Exam (Instant Result, Multi-attempt, No Leaderboard)</option>
              </select>
              <p className="mt-1.5 text-[11px] text-slate-400 leading-normal font-medium">
                Live exams have single-attempt anti-cheat locks and automatic scoreboard logic. <strong>Once the set End Time is reached, they automatically transition into Practice Exams</strong>, opening for unlimited practice attempts with instant solution disclosure.
              </p>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Result Publication Flow</label>
              <select 
                value={publishType} onChange={e => setPublishType(e.target.value as any)}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent outline-none transition-all font-semibold text-slate-800 cursor-pointer"
              >
                <option value="instant">✅ Instant - Auto-Publish immediately after submission</option>
                <option value="manual">🔒 Manual - Hold results until manual panel review</option>
              </select>
              <p className="mt-1.5 text-[11px] text-slate-400 leading-normal font-medium">
                Manual Hold will show a "Result Processing..." state to students post-live exam until you click "Publish Results" in the admin dashboard.
              </p>
            </div>
          </div>
        </section>

        {/* Questions Header */}
        <section className="space-y-4">
          <div className="bg-indigo-50 border border-indigo-100 rounded-2xl p-4 mb-4 text-sm text-indigo-800">
            <strong>💡 Tip for Mathematical Equations:</strong> You can write math formulas using LaTeX formatting! Wrap inline math with single dollar signs (e.g., <code>$E=mc^2$</code>) and block math with double dollar signs (e.g., <code>$$ \frac{1}{2} $$</code>). They will render properly on the exam view!
          </div>
          <div className="flex items-center justify-between pl-2 mb-2">
            <h2 className="text-[11px] uppercase tracking-widest font-bold text-slate-400">Questions ({questions.length})</h2>
            <div className="flex flex-wrap items-center justify-end gap-2">
              <input
                type="file"
                accept=".csv"
                ref={fileInputRef}
                style={{ display: 'none' }}
                onChange={handleBulkUpload}
              />
              <button 
                type="button"
                onClick={downloadCSVTemplate}
                className="bg-slate-100 hover:bg-slate-200 text-slate-700 px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition-colors flex items-center gap-1.5 shadow-sm"
              >
                <Download className="w-3.5 h-3.5" /> Template
              </button>
              <button 
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="bg-emerald-50 hover:bg-emerald-100 text-emerald-700 px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition-colors flex items-center gap-1.5 shadow-sm"
              >
                <Upload className="w-3.5 h-3.5" /> CSV Upload
              </button>
              <button 
                type="button"
                onClick={handleAddQuestion}
                className="bg-indigo-50 hover:bg-indigo-100 text-indigo-700 px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition-colors flex items-center gap-1.5 shadow-sm"
              >
                <Plus className="w-3.5 h-3.5" /> Add MCQ
              </button>
            </div>
          </div>
          
          <div className="space-y-4 mt-4">
            {questions.map((q, qIndex) => (
              <div key={q.id} className="bg-white p-6 sm:p-8 rounded-3xl shadow-sm border border-slate-200">
                <div className="flex justify-between items-start mb-6">
                  <span className="font-bold text-indigo-600 bg-indigo-50 px-3 py-1 rounded-lg text-xs tracking-widest uppercase">Q{qIndex + 1}</span>
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-1.5">
                      <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Marks:</label>
                      <input 
                        type="number" min={0} step="0.5"
                        value={q.marks ?? 1} 
                        onChange={e => handleQuestionChange(qIndex, 'marks', parseFloat(e.target.value) || 1)}
                        className="w-16 px-2 py-1 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-600 outline-none text-xs font-bold text-center"
                      />
                    </div>
                    <button 
                      type="button"
                      disabled={qIndex === 0}
                      onClick={() => handleMoveQuestion(qIndex, 'up')}
                      className="text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 p-2 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <ArrowUp className="w-4 h-4" />
                    </button>
                    <button 
                      type="button"
                      disabled={qIndex === questions.length - 1}
                      onClick={() => handleMoveQuestion(qIndex, 'down')}
                      className="text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 p-2 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <ArrowDown className="w-4 h-4" />
                    </button>
                    <button 
                      type="button"
                      onClick={() => handleRemoveQuestion(qIndex)}
                      className="text-slate-400 hover:text-rose-600 hover:bg-rose-50 p-2 rounded-lg transition-colors border border-transparent hover:border-rose-100"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                
                <div className="mb-6 space-y-3">
                  <input 
                    type="text" placeholder="Question text..."
                    value={q.text} onChange={e => handleQuestionChange(qIndex, 'text', e.target.value)}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent outline-none font-bold text-slate-900 transition-all text-lg"
                  />
                  <div className="flex gap-2">
                    <div className="flex-1">
                       <ImageUpload 
                        placeholder="Drag & drop or click to upload Question Image"
                        value={q.imageUrl} 
                        onChange={value => handleQuestionChange(qIndex, 'imageUrl', value)}
                       />
                    </div>
                  </div>
                </div>

                <div className="space-y-3 mb-6">
                  {q.options.map((opt, oIndex) => (
                    <div key={oIndex} className="flex items-center gap-4">
                      <div className="flex items-center justify-center p-1">
                        <input 
                          type="radio" name={`correct_${q.id}`} 
                          checked={q.correctOptionIndex === oIndex}
                          onChange={() => handleQuestionChange(qIndex, 'correctOptionIndex', oIndex)}
                          className="w-5 h-5 text-indigo-600 border-slate-300 focus:ring-indigo-600 cursor-pointer"
                        />
                      </div>
                      <input 
                        type="text" placeholder={`Option ${oIndex + 1}`}
                        value={opt} onChange={e => handleQuestionChange(qIndex, 'option', e.target.value, oIndex)}
                        className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 focus:border-transparent outline-none text-sm font-medium text-slate-700 transition-all shadow-sm"
                      />
                    </div>
                  ))}
                </div>

                <div className="space-y-3 pt-6 border-t border-slate-100">
                  <h3 className="text-[11px] uppercase tracking-widest font-bold text-slate-400">Solution / Explanation (Optional)</h3>
                  <textarea 
                    placeholder="Explanation for the correct answer..."
                    value={q.explanation || ''} onChange={e => handleQuestionChange(qIndex, 'explanation', e.target.value)}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none text-sm font-medium text-slate-700 transition-all min-h-[80px]"
                  />
                  <div className="flex gap-2">
                    <div className="flex-1">
                       <ImageUpload 
                        placeholder="Drag & drop or click to upload Solution Image"
                        value={q.explanationImageUrl} 
                        onChange={value => handleQuestionChange(qIndex, 'explanationImageUrl', value)}
                       />
                    </div>
                  </div>
                </div>
              </div>
            ))}
            
            {questions.length === 0 && (
               <div className="bg-slate-50 border-2 border-dashed border-slate-200 rounded-3xl p-12 text-center text-slate-400 font-bold uppercase tracking-widest text-xs">
                  No questions added yet.
               </div>
            )}
          </div>
        </section>

        {/* Access Control */}
        <section className="bg-white p-6 sm:p-8 rounded-3xl shadow-sm border border-slate-200 space-y-4">
           <h2 className="text-[11px] uppercase tracking-widest font-bold text-slate-400 mb-6 flex items-center">
             Access Control
           </h2>
           <div>
             <label className="block text-xs font-bold text-slate-700 mb-3 uppercase tracking-wider">Visibility & Access</label>
             <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {(['public', 'private', 'course', 'event'] as const).map(type => (
                  <button 
                    key={type}
                    type="button"
                    onClick={() => setAccessType(type)}
                    className={`py-3 px-4 rounded-xl border font-bold capitalize text-sm transition-all ${accessType === type ? 'border-indigo-600 bg-indigo-50 text-indigo-700 shadow-sm' : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'}`}
                  >
                    {type}
                  </button>
                ))}
             </div>
           </div>
           
           {accessType === 'course' && (
             <div className="pt-4 border-t border-slate-100">
               <label className="block text-xs font-bold text-slate-700 mb-2 uppercase tracking-wider">Assign to Courses</label>
               <div className="max-h-48 overflow-y-auto space-y-2 pr-2">
                 {courses.map(c => (
                   <label key={c.id} className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200 cursor-pointer hover:bg-indigo-50 hover:border-indigo-200 transition-colors">
                     <input 
                        type="checkbox" 
                        checked={courseIds.includes(c.id)}
                        onChange={(e) => {
                          if (e.target.checked) setCourseIds(prev => [...prev, c.id]);
                          else setCourseIds(prev => prev.filter(id => id !== c.id));
                        }}
                        className="w-4 h-4 text-indigo-600 rounded border-gray-300 focus:ring-indigo-500" 
                     />
                     <span className="text-sm font-bold text-slate-800">{c.title}</span>
                   </label>
                 ))}
                 {courses.length === 0 && <div className="text-sm text-slate-500 font-medium">No courses available.</div>}
               </div>
             </div>
           )}

           {accessType === 'event' && (
             <div className="pt-4 border-t border-slate-100">
               <label className="block text-xs font-bold text-slate-700 mb-2 uppercase tracking-wider">Assign to Events</label>
               <div className="max-h-48 overflow-y-auto space-y-2 pr-2">
                 {events.map(ev => (
                   <label key={ev.id} className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200 cursor-pointer hover:bg-indigo-50 hover:border-indigo-200 transition-colors">
                     <input 
                        type="checkbox" 
                        checked={eventIds.includes(ev.id)}
                        onChange={(e) => {
                          if (e.target.checked) setEventIds(prev => [...prev, ev.id]);
                          else setEventIds(prev => prev.filter(id => id !== ev.id));
                        }}
                        className="w-4 h-4 text-indigo-600 rounded border-gray-300 focus:ring-indigo-500" 
                     />
                     <span className="text-sm font-bold text-slate-800">{ev.title}</span>
                   </label>
                 ))}
                 {events.length === 0 && <div className="text-sm text-slate-500 font-medium">No events available.</div>}
               </div>
             </div>
           )}
        </section>

        {/* Negative Marking Configuration */}
        <section className="bg-slate-50 p-6 rounded-2xl border border-slate-200 space-y-4">
          <h2 className="text-[11px] uppercase tracking-widest font-bold text-slate-400">Negative Marking</h2>
          <div className="flex items-center gap-3">
            <input 
              type="checkbox" 
              id="hasNegativeMarking"
              checked={hasNegativeMarking} 
              onChange={e => setHasNegativeMarking(e.target.checked)}
              className="w-4 h-4 text-indigo-600 rounded border-gray-300 focus:ring-indigo-500"
            />
            <label htmlFor="hasNegativeMarking" className="text-sm font-bold text-slate-700 uppercase tracking-wider">Enable Negative Marking</label>
          </div>
          
          {hasNegativeMarking && (
             <div className="mt-4">
                <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Marks Deducted Per Wrong Answer</label>
                <input 
                  type="number" step="0.01" value={negativeMarksPerWrongAnswer || ''} onChange={e => setNegativeMarksPerWrongAnswer(parseFloat(e.target.value) || 0)}
                  className="w-full sm:w-1/2 px-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-600 outline-none font-medium"
                />
             </div>
          )}
        </section>



        {/* Action Bottom Bar */}
        <div className="bg-white border-t border-slate-200 p-4 fixed bottom-0 md:relative left-0 right-0 z-10 flex justify-end gap-3 shadow-[0_-8px_20px_-10px_rgba(0,0,0,0.1)] md:shadow-none md:rounded-3xl md:border">
           <button 
             onClick={() => navigate('/admin/exams')}
             className="px-6 py-2.5 rounded-xl text-sm font-bold uppercase tracking-wider text-slate-600 hover:bg-slate-100 transition-colors"
           >
             Cancel
           </button>
           <button 
             onClick={handleSave}
             className="bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-2.5 rounded-xl text-sm font-bold uppercase tracking-wider transition-colors shadow-lg shadow-indigo-600/20"
           >
             Save Exam
           </button>
        </div>
      </div>
    </div>
  );
}
