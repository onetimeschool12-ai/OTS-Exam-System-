import React, { useState, useRef } from 'react';
import { useStore } from '../../store/useStore';
import { Plus, Edit2, Trash2, Clock, Users, Printer, Download } from 'lucide-react';
import { Link } from 'react-router-dom';
import { format } from 'date-fns';
// @ts-ignore
import html2pdf from 'html2pdf.js';
import { MathText } from '../../components/MathText';

export default function AdminExams() {
  const { exams, deleteExam, updateExam } = useStore();
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [selectedExamIds, setSelectedExamIds] = useState<string[]>([]);
  const [isExporting, setIsExporting] = useState(false);
  const printContainerRef = useRef<HTMLDivElement>(null);

  const toggleSelectAll = () => {
    if (selectedExamIds.length === exams.length) {
      setSelectedExamIds([]);
    } else {
      setSelectedExamIds(exams.map(e => e.id));
    }
  };

  const toggleSelectExam = (id: string) => {
    if (selectedExamIds.includes(id)) {
      setSelectedExamIds(prev => prev.filter(eId => eId !== id));
    } else {
      setSelectedExamIds(prev => [...prev, id]);
    }
  };

  const handleBulkExport = async () => {
    if (selectedExamIds.length === 0 || !printContainerRef.current) return;
    setIsExporting(true);
    
    // Slight delay to ensure React commits the rendering of the print container if it was unmounted or modified
    setTimeout(async () => {
      try {
        const element = printContainerRef.current;
        const opt = {
          margin:       0.5,
          filename:     `Bulk_Solution_Papers.pdf`,
          image:        { type: 'jpeg' as const, quality: 0.98 },
          html2canvas:  { scale: 2, useCORS: true, logging: false },
          jsPDF:        { unit: 'in', format: 'letter', orientation: 'portrait' as const }
        };
        await html2pdf().set(opt).from(element).save();
      } catch (err) {
        console.error("Export failed:", err);
      } finally {
        setIsExporting(false);
      }
    }, 500);
  };

  const selectedExamsData = exams.filter(e => selectedExamIds.includes(e.id));

  return (
    <div>
      <div className="print-hidden">
        <div className="flex sm:items-center justify-between flex-col sm:flex-row gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-display font-bold text-slate-900 tracking-tight">Manage Exams</h1>
            <p className="text-slate-500 text-sm mt-1 font-medium">Create, edit, and organize online tests</p>
          </div>
          <div className="flex items-center gap-3">
          {selectedExamIds.length > 0 && (
            <button
              onClick={handleBulkExport}
              disabled={isExporting}
              className="bg-slate-800 hover:bg-slate-900 text-white px-4 py-2.5 rounded-xl text-sm font-bold transition-colors flex items-center justify-center gap-2 shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isExporting ? (
                <>
                  <div className="w-4 h-4 rounded-full border-2 border-white/30 border-t-white animate-spin" />
                  Exporting PDF...
                </>
              ) : (
                <>
                  <Printer className="w-4 h-4" /> 
                  Print {selectedExamIds.length} Selected
                </>
              )}
            </button>
          )}
          <Link 
            to="/admin/exams/new" 
            className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-xl text-sm font-bold transition-colors flex items-center justify-center gap-2 shadow-md shadow-indigo-200"
          >
            <Plus className="w-4 h-4" /> Create Exam
          </Link>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-[10px] uppercase tracking-widest font-bold text-slate-500">
                <th className="py-4 px-6 w-12">
                  <input 
                    type="checkbox"
                    className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-600 cursor-pointer"
                    checked={exams.length > 0 && selectedExamIds.length === exams.length}
                    onChange={toggleSelectAll}
                  />
                </th>
                <th className="py-4 px-6 whitespace-nowrap">Title & Subject</th>
                <th className="py-4 px-6 whitespace-nowrap">Schedule</th>
                <th className="py-4 px-6 whitespace-nowrap">Questions</th>
                <th className="py-4 px-6 whitespace-nowrap">Status</th>
                <th className="py-4 px-6 text-right whitespace-nowrap">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {exams.map(exam => {
                const isActive = Date.now() >= exam.startTime && Date.now() <= exam.endTime;
                const isSelected = selectedExamIds.includes(exam.id);
                
                return (
                  <tr key={exam.id} className={`hover:bg-slate-50/50 transition-colors group ${isSelected ? 'bg-indigo-50/30' : ''}`}>
                    <td className="py-4 px-6">
                      <input 
                        type="checkbox"
                        className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-600 cursor-pointer"
                        checked={isSelected}
                        onChange={() => toggleSelectExam(exam.id)}
                      />
                    </td>
                    <td className="py-4 px-6">
                      <div className="font-bold text-slate-900 text-sm mb-1">{exam.title}</div>
                      <div className="text-[10px] font-bold text-indigo-600 uppercase tracking-wider">
                        {exam.category}{exam.subCategory ? ` / ${exam.subCategory}` : ''} • {exam.subject}
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-700">
                        <Clock className="w-3.5 h-3.5 text-slate-400" /> 
                        {format(exam.startTime, 'MMM d, h:mm a')}
                      </div>
                      <div className="text-[10px] font-bold text-slate-400 mt-1 uppercase tracking-widest">{exam.durationMinutes} mins</div>
                    </td>
                    <td className="py-4 px-6 text-sm font-medium text-slate-700">
                      {exam.questions.length} <span className="text-slate-400">Qs</span>
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex flex-col gap-1 items-start">
                        {exam.status === 'completed' ? (
                          <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-700 uppercase tracking-widest mb-1">
                            Closed
                          </span>
                        ) : isActive && exam.status === 'published' ? (
                          <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-rose-50 text-rose-600 uppercase tracking-widest mb-1">
                            Live
                          </span>
                        ) : (
                          <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-600 uppercase tracking-widest mb-1">
                            {exam.status === 'draft' ? 'Draft' : 'Scheduled / Practice'}
                          </span>
                        )}
                        <span className={`inline-flex items-center px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider ${exam.examType === 'practice' ? 'bg-amber-50 text-amber-600 border border-amber-100' : 'bg-indigo-50 text-indigo-600 border border-indigo-100'}`}>
                          {exam.examType === 'practice' ? 'Practice' : 'Live Exam'}
                        </span>
                        {exam.examType !== 'practice' && (
                          <span className={`text-[9px] font-bold mt-1 uppercase tracking-wider ${exam.resultsPublished !== false ? 'text-emerald-600' : 'text-slate-400'}`}>
                            {exam.resultsPublished !== false ? '● Results Live' : '○ Results Held'}
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="py-4 px-6 text-right">
                      <div className="flex items-center justify-end gap-2">
                        {exam.examType !== 'practice' && exam.publishType === 'manual' && (
                          <button 
                            onClick={() => {
                              updateExam(exam.id, { resultsPublished: !exam.resultsPublished });
                            }}
                            title={exam.resultsPublished ? "Hold Leaderboard" : "Release Leaderboard"}
                            className={`px-3 py-1.5 rounded-lg transition-colors border text-[10px] font-bold uppercase tracking-widest ${exam.resultsPublished !== false ? 'text-amber-700 bg-amber-50 hover:bg-amber-100 border-amber-200' : 'text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border-emerald-200'}`}
                          >
                            {exam.resultsPublished !== false ? 'Hold' : 'Release'}
                          </button>
                        )}
                        {exam.status !== 'completed' ? (
                          <button 
                            onClick={() => {
                               updateExam(exam.id, { status: exam.status === 'draft' ? 'published' : 'draft' });
                            }}
                            title={exam.status === 'draft' ? "Publish Exam" : "Move to Draft"}
                            className={`p-2 rounded-lg transition-colors border ${exam.status === 'draft' ? 'text-indigo-600 bg-indigo-50 hover:bg-indigo-100 border-indigo-100' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-100 border-transparent'}`}
                          >
                            <span className="text-[10px] font-bold uppercase tracking-widest">{exam.status === 'draft' ? 'Publish' : 'Unpublish'}</span>
                          </button>
                        ) : (
                          <button
                            onClick={() => {
                               updateExam(exam.id, { status: 'published' });
                            }}
                            title="Re-open Exam"
                            className="p-2 rounded-lg transition-colors border text-amber-600 bg-amber-50 hover:bg-amber-100 border-amber-100"
                          >
                            <span className="text-[10px] font-bold uppercase tracking-widest">Re-open</span>
                          </button>
                        )}
                        {exam.status === 'published' && (
                          <button
                            onClick={() => {
                               updateExam(exam.id, { status: 'completed' });
                            }}
                            title="Close Exam"
                            className="p-2 rounded-lg transition-colors border text-rose-600 bg-rose-50 hover:bg-rose-100 border-rose-100"
                          >
                            <span className="text-[10px] font-bold uppercase tracking-widest">Close</span>
                          </button>
                        )}
                        <Link 
                          to={`/admin/exams/${exam.id}/edit`}
                          className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors border border-transparent hover:border-indigo-100"
                        >
                          <Edit2 className="w-4 h-4" />
                        </Link>
                        {confirmDeleteId === exam.id ? (
                          <div className="flex items-center gap-1.5 bg-rose-50 border border-rose-100 px-2 py-1 rounded-lg animate-in fade-in zoom-in-95 duration-200">
                            <span className="text-[9px] font-black text-rose-800 uppercase px-1">Confirm?</span>
                            <button 
                              onClick={() => {
                                deleteExam(exam.id);
                                setConfirmDeleteId(null);
                              }}
                              className="px-2 py-0.5 bg-rose-600 hover:bg-rose-700 text-white rounded text-[9px] font-black uppercase tracking-wider transition-all"
                            >
                              Yes
                            </button>
                            <button 
                              onClick={() => setConfirmDeleteId(null)}
                              className="px-2 py-0.5 bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 rounded text-[9px] font-black uppercase tracking-wider transition-all"
                            >
                              No
                            </button>
                          </div>
                        ) : (
                          <button 
                            onClick={() => setConfirmDeleteId(exam.id)}
                            className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors border border-transparent hover:border-rose-100"
                            title="Delete Exam"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
              {exams.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-500 font-medium">
                    No exams found. Click "Create Exam" to get started.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
      </div>

      {/* Hidden Container for Bulk PDF Export */}
      <div className="fixed top-0 left-[-9999px] opacity-0 pointer-events-none z-[-10]">
        <div ref={printContainerRef} className="w-[800px] bg-white p-8 space-y-12 text-slate-900">
          <div className="text-center pb-4 border-b-2 border-slate-900 mb-8">
            <h1 className="text-3xl font-black uppercase tracking-widest">BULK SOLUTION PAPERS</h1>
            <p className="text-sm font-bold text-slate-500 mt-2">Exported on {format(new Date(), 'dd MMM yyyy, h:mm a')}</p>
          </div>
          
          {selectedExamsData.map((exam, index) => (
            <div key={exam.id} className="break-inside-avoid mb-16 relative">
              {/* Exam Header */}
              <div className="bg-slate-50 border border-slate-200 p-6 rounded-2xl mb-6 shadow-sm">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <span className="text-[10px] font-black uppercase text-indigo-600 tracking-widest bg-indigo-50 px-2 py-1 rounded inline-block mb-2">
                      Exam {index + 1}
                    </span>
                    <h2 className="text-2xl font-black text-slate-900 font-display leading-tight">{exam.title}</h2>
                  </div>
                  <div className="text-right flex flex-col gap-1 items-end">
                    <span className="text-xs font-bold text-slate-500 uppercase tracking-widest bg-white border border-slate-200 px-2 py-1 rounded">
                      {exam.subject}
                    </span>
                    <span className="text-[10px] font-bold text-slate-400 bg-white border border-slate-100 px-2.5 py-0.5 rounded-full mt-1">
                      {exam.questions.length} Questions
                    </span>
                  </div>
                </div>
                {exam.category && (
                  <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-2">
                    <span className="text-indigo-400">Category:</span> {exam.category} {exam.subCategory && ` / ${exam.subCategory}`}
                  </div>
                )}
              </div>

              {/* Exam Questions */}
              <div className="space-y-6 pl-2">
                {exam.questions.map((q, qIndex) => {
                  return (
                    <div key={q.id} className="border-b border-slate-200 pb-6 last:border-0 break-inside-avoid page-break-inside-avoid">
                      <div className="flex items-start gap-3 mb-4">
                        <span className="w-8 h-8 flex-shrink-0 bg-slate-900 text-white rounded-full flex items-center justify-center font-black text-sm shadow-sm ring-4 ring-slate-50">
                          {qIndex + 1}
                        </span>
                        <div className="pt-1.5 flex-1 w-full min-w-0">
                          <div className="text-base text-slate-800 font-medium leading-relaxed whitespace-pre-wrap">
                            <MathText content={q.text} />
                            {q.imageUrl && (
                              <div className="mt-4 break-inside-avoid">
                                <img 
                                  src={q.imageUrl} 
                                  alt={`Question ${qIndex + 1}`}
                                  referrerPolicy="no-referrer"
                                  className="max-w-full rounded-xl border border-slate-200 shadow-sm max-h-64 object-contain"
                                />
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pl-11 mb-4">
                        {q.options.map((opt, oIdx) => {
                          const isCorrect = oIdx === q.correctOptionIndex;
                          return (
                            <div key={oIdx} className={`p-3 rounded-xl border flex items-start gap-3 ${isCorrect ? 'bg-emerald-50 border-emerald-500 shadow-sm ring-1 ring-emerald-500' : 'bg-white border-slate-200'}`}>
                              <span className={`w-5 h-5 flex-shrink-0 rounded-full flex items-center justify-center text-[10px] font-black ${isCorrect ? 'bg-emerald-500 text-white' : 'bg-slate-100 text-slate-500'}`}>
                                {String.fromCharCode(65 + oIdx)}
                              </span>
                              <div className={`pt-0.5 text-sm font-medium flex-1 overflow-x-auto ${isCorrect ? 'text-emerald-900 font-bold' : 'text-slate-600'}`}>
                                <MathText content={opt} />
                              </div>
                            </div>
                          );
                        })}
                      </div>

                      {q.explanation && (
                        <div className="ml-11 mt-4 bg-slate-50 rounded-xl p-4 border border-slate-200 break-inside-avoid">
                           <h4 className="text-[10px] uppercase tracking-widest font-bold text-slate-500 mb-2">Solution / Explanation</h4>
                           <div className="text-sm font-medium text-slate-700">
                             <MathText content={q.explanation} />
                           </div>
                           {q.explanationImageUrl && (
                             <div className="mt-4">
                               <img src={q.explanationImageUrl} alt="Solution diagram" className="max-w-full rounded-lg border border-slate-300 shadow-sm max-h-64 object-contain" referrerPolicy="no-referrer" />
                             </div>
                           )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
