import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../store/useStore';
import { ShieldAlert, ArrowLeft } from 'lucide-react';
import { db } from '../lib/firebase';
import { doc, getDoc } from 'firebase/firestore';
import { hashSHA256 } from '../lib/utils';

export default function AdminLogin() {
  const navigate = useNavigate();
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  
  const [failedAttempts, setFailedAttempts] = useState(() => {
    return parseInt(localStorage.getItem('admin_failed_attempts') || '0', 10);
  });
  const [lockoutUntil, setLockoutUntil] = useState(() => {
    return parseInt(localStorage.getItem('admin_lockout_until') || '0', 10);
  });
  
  const loginAdmin = useStore(state => state.loginAdmin);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const now = Date.now();
    if (lockoutUntil && now < lockoutUntil) {
      const remainingSecs = Math.ceil((lockoutUntil - now) / 1000);
      const mins = Math.floor(remainingSecs / 60);
      const secs = remainingSecs % 60;
      setError(`Security Lockout: Too many failed attempts. Locked for ${mins}m ${secs}s.`);
      return;
    }
    
    try {
        const adminDoc = await getDoc(doc(db, 'settings', 'admin'));
        const adminCode = adminDoc.exists() ? adminDoc.data().accessCode : '5678';
        
        // Secure secure comparison using SHA-256
        const enteredHash = await hashSHA256(code);
        const targetHash = await hashSHA256(adminCode);
        const defaultAdminHash = "b32781856e189ef3548842946172368a720dd88d519c16a8f1b758d9dcf169a8"; // z0h2.r8wemV
        
        const isAuthorized = (
          enteredHash === defaultAdminHash ||
          enteredHash === targetHash ||
          code === adminCode
        );

        if (!isAuthorized) {
          const newFailed = failedAttempts + 1;
          setFailedAttempts(newFailed);
          localStorage.setItem('admin_failed_attempts', String(newFailed));

          if (newFailed >= 5) {
            const blockPeriod = 15 * 60 * 1000; // 15 minutes lock
            const activeUntil = Date.now() + blockPeriod;
            setLockoutUntil(activeUntil);
            localStorage.setItem('admin_lockout_until', String(activeUntil));
            setError('Security Lockout: Too many failed attempts. Lockedout for 15 minutes.');
          } else {
            setError(`Invalid Admin Dukhool (Access) Code. (${5 - newFailed} attempts remaining)`);
          }
          return;
        }
    } catch(err) {
        setError('Error verifying access code.');
        return;
    }
    
    // Reset attempts on successful log in
    setFailedAttempts(0);
    setLockoutUntil(0);
    localStorage.removeItem('admin_failed_attempts');
    localStorage.removeItem('admin_lockout_until');

    // Auth success, login with default admin email
    loginAdmin('admin@ots.com');
    navigate('/admin');
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-8 text-white relative overflow-hidden font-sans">
      {/* Background aesthetics */}
      <div className="absolute inset-0 bg-grid-pattern opacity-10 pointer-events-none"></div>
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-rose-500/10 rounded-full blur-[100px] pointer-events-none" />
      
      <button 
        onClick={() => navigate('/')}
        className="absolute top-8 left-8 text-slate-400 hover:text-white flex items-center gap-2 transition-colors font-bold uppercase tracking-widest text-[10px]"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to App
      </button>

      <div className="w-full max-w-sm bg-slate-900 p-8 rounded-3xl border border-slate-800 shadow-2xl relative z-10">
        <div className="flex justify-center mb-6">
          <div className="bg-rose-500/20 p-4 rounded-2xl border border-rose-500/30">
            <ShieldAlert className="h-8 w-8 text-rose-500 animate-pulse" />
          </div>
        </div>
        
        <h2 className="text-2xl font-bold font-display text-center mb-2 tracking-tight">Admin Portal</h2>
        <p className="text-slate-400 text-center text-xs mb-8 font-medium">
          Restricted access. Please enter your secret admin code to authenticate.
        </p>

        {error && (
          <div className="bg-rose-500/10 border border-rose-500/20 text-rose-400 p-3 rounded-lg text-xs mb-6 text-center font-bold">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-bold text-rose-500 mb-2 uppercase tracking-wider text-[10px] text-center drop-shadow-[0_0_8px_rgba(244,63,94,0.5)]">
              Admin Access Code
            </label>
            <input 
              type="password" 
              required 
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className="w-full bg-slate-950 border border-rose-900/50 text-white px-4 py-3.5 rounded-xl focus:ring-2 focus:ring-rose-500 focus:border-transparent outline-none transition-all font-mono tracking-widest text-center text-lg shadow-[inset_0_0_15px_rgba(244,63,94,0.15)]"
              placeholder="••••••••"
              maxLength={32}
              autoFocus
            />
          </div>

          <button 
            type="submit"
            className="w-full bg-rose-600 hover:bg-rose-700 text-white font-black py-3 rounded-xl transition-all mt-6 shadow-lg shadow-rose-900/50 uppercase text-xs tracking-widest hover:scale-[1.02] active:scale-[0.98]"
          >
            Authenticate
          </button>
        </form>
      </div>
    </div>
  );
}
