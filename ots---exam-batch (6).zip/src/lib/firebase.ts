import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { initializeFirestore } from 'firebase/firestore';

const env = (import.meta as any).env || {};

const firebaseConfig = {
  apiKey: env.VITE_FIREBASE_API_KEY || "AIzaSyB7NIQrn7l6PWk-7HGjvZcO8aTGcKU1e44",
  authDomain: env.VITE_FIREBASE_AUTH_DOMAIN || "ots---exam-system.firebaseapp.com",
  databaseURL: env.VITE_FIREBASE_DATABASE_URL || "https://ots---exam-system-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: env.VITE_FIREBASE_PROJECT_ID || "ots---exam-system",
  storageBucket: env.VITE_FIREBASE_STORAGE_BUCKET || "ots---exam-system.firebasestorage.app",
  messagingSenderId: env.VITE_FIREBASE_MESSAGING_SENDER_ID || "446665491206",
  appId: env.VITE_FIREBASE_APP_ID || "1:446665491206:web:98630b2c8c5ee4bf641487",
  measurementId: env.VITE_FIREBASE_MEASUREMENT_ID || "G-GBFPR25JH1"
};

const app = initializeApp(firebaseConfig);
export const db = initializeFirestore(app, {
  experimentalForceLongPolling: true,
});
export const auth = getAuth(app);
