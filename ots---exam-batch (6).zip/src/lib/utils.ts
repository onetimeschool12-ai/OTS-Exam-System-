import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Strips script tags, HTML tags, and trims whitespace from a string to prevent XSS.
 */
export function sanitizeInput(value: string | undefined | null): string {
  if (!value) return '';
  return value
    .replace(/<script[^>]*>([\s\S]*?)<\/script>/gi, '') // Remove scripts
    .replace(/<\/?[^>]+(>|$)/g, '') // Strip element tags
    .trim();
}

/**
 * Hashes a string using SHA-256 (Web Crypto API).
 */
export async function hashSHA256(text: string): Promise<string> {
  const msgUint8 = new TextEncoder().encode(text);
  const hashBuffer = await window.crypto.subtle.digest('SHA-256', msgUint8);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

/**
 * Deeply sanitizes payloads to ensure nested data is completely clean and secure.
 */
export function sanitizePayload<T>(payload: T): T {
  if (payload === null || payload === undefined) return payload;
  if (typeof payload === 'string') {
    return sanitizeInput(payload) as unknown as T;
  }
  if (typeof payload === 'object') {
    if (Array.isArray(payload)) {
      return payload.map(item => sanitizePayload(item)) as unknown as T;
    }
    const sanitizedObj: any = {};
    for (const key in payload) {
      if (Object.prototype.hasOwnProperty.call(payload, key)) {
        sanitizedObj[key] = sanitizePayload(payload[key]);
      }
    }
    return sanitizedObj as T;
  }
  return payload;
}
