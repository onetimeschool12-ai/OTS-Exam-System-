import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Fix html2canvas unsupported oklab/oklch color function crashes with Tailwind CSS v4
try {
  const originalGet = Object.getOwnPropertyDescriptor(CSSStyleSheet.prototype, 'cssRules')?.get;
  if (originalGet) {
    Object.defineProperty(CSSStyleSheet.prototype, 'cssRules', {
      get() {
        try {
          const rules = originalGet.call(this);
          if (!rules) return rules;
          const filtered: CSSRule[] = [];
          for (let i = 0; i < rules.length; i++) {
            const rule = rules[i];
            const cssText = rule.cssText;
            if (
              !cssText.includes('oklab(') &&
              !cssText.includes('oklch(') &&
              !cssText.includes('oklab ') &&
              !cssText.includes('oklch ')
            ) {
              filtered.push(rule);
            }
          }
          // Build an array-like CSSRuleList-compliant object
          const ruleList = Object.create(CSSRuleList.prototype);
          filtered.forEach((rule, index) => {
            Object.defineProperty(ruleList, index, {
              value: rule,
              writable: false,
              enumerable: true,
              configurable: true
            });
          });
          Object.defineProperty(ruleList, 'length', {
            value: filtered.length,
            writable: false,
            enumerable: true,
            configurable: true
          });
          Object.defineProperty(ruleList, 'item', {
            value: function(index: number) {
              return filtered[index] || null;
            },
            writable: false,
            enumerable: true,
            configurable: true
          });
          return ruleList;
        } catch (e) {
          return originalGet.call(this);
        }
      },
      configurable: true,
      enumerable: true
    });
  }
} catch (err) {
  console.error('Failed to patch CSSStyleSheet.prototype.cssRules for html2canvas compatibility', err);
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);

