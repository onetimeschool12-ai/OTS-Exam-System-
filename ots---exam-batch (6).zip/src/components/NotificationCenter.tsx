import React, { useState } from 'react';
import { Bell, Check, Trash2, Clock, Calendar, Info } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useStore } from '../store/useStore';
import { formatDistanceToNow } from 'date-fns';
import { cn } from '../lib/utils';

export default function NotificationCenter() {
  const { notifications, currentUser, markNotificationAsRead, clearNotifications } = useStore();
  const [isOpen, setIsOpen] = useState(false);

  const userNotifications = notifications.filter(n => n.userId === currentUser?.id);
  const unreadCount = userNotifications.filter(n => !n.isRead).length;

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'exam_upcoming': return <Clock className="w-4 h-4 text-amber-500" />;
      case 'course_notice': return <Info className="w-4 h-4 text-blue-500" />;
      case 'course_exam': return <Calendar className="w-4 h-4 text-emerald-500" />;
      default: return <Bell className="w-4 h-4 text-slate-400" />;
    }
  };

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="relative p-1.5 sm:p-2 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
      >
        <Bell className="w-5 h-5 sm:w-6 sm:h-6" />
        {unreadCount > 0 && (
          <span className="absolute top-1 sm:top-1.5 right-1 sm:right-1.5 w-3.5 h-3.5 sm:w-4 sm:h-4 bg-rose-500 text-white text-[9px] sm:text-[10px] font-black flex items-center justify-center rounded-full border border-slate-900">
            {unreadCount}
          </span>
        )}
      </button>

      <AnimatePresence>
        {isOpen && (
          <>
            <div 
              className="fixed inset-0 z-40" 
              onClick={() => setIsOpen(false)} 
            />
            <motion.div
              initial={{ opacity: 0, y: 10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 10, scale: 0.95 }}
              className="absolute right-0 mt-3 w-80 sm:w-96 bg-white rounded-3xl shadow-2xl border border-slate-200 z-50 overflow-hidden"
            >
              <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
                <h3 className="font-black text-slate-900 flex items-center gap-2">
                  Notifications
                  {unreadCount > 0 && <span className="text-xs font-bold text-slate-400">({unreadCount} new)</span>}
                </h3>
                <button
                  onClick={clearNotifications}
                  className="text-xs font-bold text-slate-400 hover:text-rose-500 flex items-center gap-1 transition-colors"
                >
                  <Trash2 className="w-3 h-3" />
                  Clear all
                </button>
              </div>

              <div className="max-h-[400px] overflow-y-auto">
                {userNotifications.length === 0 ? (
                  <div className="p-12 text-center space-y-3">
                    <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto">
                      <Bell className="w-8 h-8 text-slate-300" />
                    </div>
                    <p className="text-sm font-bold text-slate-400 tracking-tight">No notifications yet</p>
                  </div>
                ) : (
                  <div className="divide-y divide-slate-100">
                    {userNotifications.map(notification => (
                      <div
                        key={notification.id}
                        className={cn(
                          "p-4 transition-colors relative group",
                          !notification.isRead ? "bg-indigo-50/30" : "hover:bg-slate-50"
                        )}
                      >
                        <div className="flex gap-3">
                          <div className="mt-1 flex-shrink-0">
                            <div className="w-8 h-8 rounded-full bg-white shadow-sm border border-slate-100 flex items-center justify-center">
                              {getTypeIcon(notification.type)}
                            </div>
                          </div>
                          <div className="flex-1 space-y-1">
                            <div className="flex items-start justify-between gap-2">
                              <p className={cn(
                                "text-sm font-black tracking-tight",
                                !notification.isRead ? "text-slate-900" : "text-slate-600"
                              )}>
                                {notification.title}
                              </p>
                              {!notification.isRead && (
                                <button
                                  onClick={() => markNotificationAsRead(notification.id)}
                                  className="p-1 rounded-md text-indigo-400 hover:bg-indigo-50 hover:text-indigo-600 transition-colors"
                                  title="Mark as read"
                                >
                                  <Check className="w-3 h-3" />
                                </button>
                              )}
                            </div>
                            <p className="text-xs font-semibold text-slate-500 leading-relaxed">
                              {notification.message}
                            </p>
                            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                              {formatDistanceToNow(notification.createdAt)} ago
                            </p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="p-3 border-t border-slate-100 bg-slate-50/50 text-center">
                <button 
                  onClick={() => setIsOpen(false)}
                  className="text-xs font-black text-indigo-600 hover:text-indigo-700 tracking-tight"
                >
                  Close Panel
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
