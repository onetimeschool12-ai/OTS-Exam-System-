import React from 'react';
import ReactMarkdown from 'react-markdown';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import 'katex/dist/katex.min.css';
import { cn } from '../lib/utils';

interface MathTextProps {
  content: string;
  className?: string;
}

export function MathText({ content, className }: MathTextProps) {
  return (
    <div className={cn("math-text-wrapper break-words overflow-x-auto", className)}>
      <ReactMarkdown
        remarkPlugins={[remarkMath]}
        rehypePlugins={[rehypeKatex]}
        components={{
          p: ({node, ...props}) => <span className="inline-block align-middle" {...props} />,
          li: ({node, ...props}) => <li className="mb-1" {...props} />
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  );
}
