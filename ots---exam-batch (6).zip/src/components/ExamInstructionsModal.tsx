import React, { useState } from 'react';
import { ClipboardList, AlertCircle, Info, Check } from 'lucide-react';
import { Exam } from '../types';

interface Props {
  exam: Exam;
  onStart: () => void;
}

export function ExamInstructionsModal({ exam, onStart }: Props) {
  const [agreed, setAgreed] = useState(false);

  const totalQuestions = exam.questions?.length || 0;
  const totalMarks = exam.questions?.reduce((acc, q) => acc + (q.marks ?? 1), 0) || 0;
  
  // Format to standard Bengali layout
  const defaultBn = `১. প্রতিটি MCQ প্রশ্নের জন্য চারটি করে option আছে। সর্বোৎকৃষ্ট উত্তরটি বাছাই করতে হবে। সঠিক উত্তরটি সতর্কতার সহিত Select করতে হবে। কারণ, সঠিক উত্তর একবার Select করলে আর Deselect করা যাবে না। একই প্রশ্নের একাধিক উত্তর গ্রহণযোগ্য হবে না। কোনো প্রশ্নের সঠিক উত্তর না থাকলে সবচেয়ে কাছাকাছি উত্তরটি বাছাই করতে হবে।
২. প্রতিটি সঠিক উত্তরের জন্য ১ নম্বর পাওয়া যাবে।${exam.hasNegativeMarking ? `\n৩. প্রতিটি ভুল উত্তরের জন্য ${exam.negativeMarksPerWrongAnswer ? (exam.negativeMarksPerWrongAnswer * 100) : 25}% নম্বর কাটা যাবে।` : ''}`;

  const defaultEn = `1. There are four options for each MCQ question. Select the best option. The correct answer must be selected with caution. Because once you select the correct answer, you can't be deselected. Multiple answers to the same question will not be acceptable. If there is no correct answer to a question, the nearest answer should be chosen.
2. 1 mark will be given for each correct answer.`;

  const bnInstructions = exam.instructionsBn ? exam.instructionsBn : defaultBn;
  const enInstructions = exam.instructionsEn ? exam.instructionsEn : defaultEn;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/40 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-white rounded-[32px] w-full max-w-2xl shadow-2xl border border-slate-100 flex flex-col overflow-hidden max-h-[90vh] animate-in fade-in-50 zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="p-6 pb-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-3">
            <span className="bg-rose-500 text-white font-extrabold text-[10px] tracking-widest uppercase px-2.5 py-1 rounded-sm">
              Test Exam
            </span>
            <div className="text-sm font-black text-rose-500 uppercase tracking-widest">OTS Exam Engine</div>
          </div>
        </div>

        {/* Content body */}
        <div className="p-6 md:p-8 overflow-y-auto space-y-6">
          {/* Title */}
          <div className="text-center">
            <h1 className="text-2xl md:text-3xl font-black text-slate-900 tracking-tight leading-snug">
              {exam.title}
            </h1>
            {exam.description && (
              <p className="text-sm font-bold text-slate-500 mt-2 max-w-lg mx-auto whitespace-pre-wrap">
                {exam.description}
              </p>
            )}
          </div>

          {/* 3 Grid Statistics Blocks */}
          <div className="grid grid-cols-3 gap-3 md:gap-4">
            {/* Block 1 */}
            <div className="bg-slate-50 border border-slate-100/80 rounded-2xl p-4 text-center">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider block mb-1">Full Marks</span>
              <div className="flex justify-between text-xs text-slate-500 font-bold border-b border-slate-200/50 pb-1.5 mb-1.5 px-1">
                <span>MCQ:</span>
                <span>{totalMarks}</span>
              </div>
              <div className="flex justify-between text-xs text-slate-800 font-black px-1">
                <span>Total:</span>
                <span>{totalMarks}</span>
              </div>
            </div>

            {/* Block 2 */}
            <div className="bg-slate-50 border border-slate-100/80 rounded-2xl p-4 text-center">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider block mb-1">Duration</span>
              <div className="flex justify-between text-xs text-slate-500 font-bold border-b border-slate-200/50 pb-1.5 mb-1.5 px-1">
                <span>MCQ:</span>
                <span>{exam.durationMinutes}m</span>
              </div>
              <div className="flex justify-between text-xs text-slate-800 font-black px-1">
                <span>Total:</span>
                <span>{exam.durationMinutes}m</span>
              </div>
            </div>

            {/* Block 3 */}
            <div className="bg-slate-50 border border-slate-100/80 rounded-2xl p-4 text-center">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider block mb-1">Total Question</span>
              <div className="flex justify-between text-xs text-slate-500 font-bold border-b border-slate-200/50 pb-1.5 mb-1.5 px-1">
                <span>MCQ:</span>
                <span>{totalQuestions}</span>
              </div>
              <div className="flex justify-between text-xs text-slate-800 font-black px-1">
                <span>Total:</span>
                <span>{totalQuestions}</span>
              </div>
            </div>
          </div>

          {/* Bengali rules card */}
          <div className="bg-slate-50/50 border border-slate-100 p-5 md:p-6 rounded-2xl text-left">
            <h3 className="text-base font-black text-slate-800 tracking-wide mb-3 text-center border-b border-slate-200 pb-2">
              পরীক্ষার্থীদের জন্য নির্দেশাবলি
            </h3>
            <div className="text-slate-600 text-xs md:text-sm leading-relaxed whitespace-pre-line font-medium space-y-2">
              {bnInstructions}
            </div>
          </div>

          {/* English rules card */}
          <div className="bg-slate-50/50 border border-slate-100 p-5 md:p-6 rounded-2xl text-left">
            <h3 className="text-base font-black text-slate-800 tracking-wide mb-3 text-center border-b border-slate-200 pb-2">
              Instructions for the examinees
            </h3>
            <div className="text-slate-600 text-xs md:text-sm leading-relaxed whitespace-pre-line font-medium space-y-2">
              {enInstructions}
            </div>
          </div>
        </div>

        {/* Start Bottom Footer & Checkbox */}
        <div className="p-6 bg-slate-50 border-t border-slate-100 space-y-4">
          <label className="flex items-center gap-3 cursor-pointer select-none">
            <div className="relative">
              <input 
                type="checkbox"
                checked={agreed}
                onChange={e => setAgreed(e.target.checked)}
                className="sr-only"
              />
              <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${agreed ? 'bg-indigo-600 border-indigo-600 scale-105' : 'border-slate-300 bg-white'}`}>
                {agreed && <Check className="w-3.5 h-3.5 text-white stroke-[3.5]" />}
              </div>
            </div>
            <span className="text-sm font-bold text-slate-700 select-none">
              I agree with the terms and conditions
            </span>
          </label>

          <button 
            disabled={!agreed}
            onClick={onStart}
            className={`w-full py-3.5 rounded-2xl text-sm font-black uppercase tracking-wider transition-all duration-200 ${agreed ? 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-lg shadow-indigo-600/30 active:scale-[0.98]' : 'bg-slate-200 text-slate-400 cursor-not-allowed'}`}
          >
            Start MCQ Exam
          </button>
        </div>

      </div>
    </div>
  );
}
