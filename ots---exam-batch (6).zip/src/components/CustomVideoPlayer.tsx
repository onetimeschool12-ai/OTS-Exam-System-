import React, { useState, useRef, useEffect } from 'react';
import ReactPlayer from 'react-player';
import screenfull from 'screenfull';
import { Play, Pause, Maximize, Minimize, Settings, Volume2, VolumeX, RotateCcw, RotateCw } from 'lucide-react';

interface Props {
  url: string;
  title?: string;
}

export default function CustomVideoPlayer({ url, title }: Props) {
  const playerRef = useRef<any>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  
  const [playing, setPlaying] = useState(false);
  const [volume, setVolume] = useState(1);
  const [muted, setMuted] = useState(false);
  const [played, setPlayed] = useState(0);
  const [duration, setDuration] = useState(0);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [showSettings, setShowSettings] = useState<'speed' | 'quality' | null>(null);
  const [quality, setQuality] = useState('Auto'); // Cosmetic only for YouTube
  const [captionsEnabled, setCaptionsEnabled] = useState(false);
  
  const handlePlayerReady = (player?: any) => {
    if (!player) return;
    try {
      const internal = player.getInternalPlayer();
      if (internal) {
        if (!captionsEnabled) {
          if (typeof internal.unloadModule === 'function') {
            internal.unloadModule("captions");
          }
          if (typeof internal.setOption === 'function') {
            internal.setOption("captions", "track", {});
          }
        } else {
          if (typeof internal.loadModule === 'function') {
            internal.loadModule("captions");
          }
        }
      }
    } catch (e) {
      console.warn("Captions module ignored:", e);
    }
  };
  
  const [isHolding, setIsHolding] = useState(false);
  const pressHoldRef = useRef<NodeJS.Timeout | null>(null);
  const originalPlaybackRateRef = useRef<number>(1);
  const lastTapRef = useRef<{time: number, x: number}>({ time: 0, x: 0 });
  const singleTapTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const controlsTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const handlePlayPause = (e?: React.SyntheticEvent) => {
    e?.stopPropagation();
    setPlaying(p => !p);
  };
  
  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    
    if (playing) {
      if (pressHoldRef.current) clearTimeout(pressHoldRef.current);
      pressHoldRef.current = setTimeout(() => {
        setIsHolding(true);
        originalPlaybackRateRef.current = playbackRate;
        setPlaybackRate(2);
        setShowControls(true);
      }, 500);
    }
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.pointerType === 'mouse' && e.button !== 0) return;

    if (pressHoldRef.current) {
      clearTimeout(pressHoldRef.current);
      pressHoldRef.current = null;
    }

    if (isHolding) {
      setIsHolding(false);
      setPlaybackRate(originalPlaybackRateRef.current);
      setShowControls(false);
      return;
    }

    const currentTime = new Date().getTime();
    const tapDistance = currentTime - lastTapRef.current.time;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const isRight = x > rect.width / 2;

    if (tapDistance < 300) {
      if (singleTapTimeoutRef.current) {
        clearTimeout(singleTapTimeoutRef.current);
        singleTapTimeoutRef.current = null;
      }
      if (isRight) {
        skipForward();
      } else {
        skipBackward();
      }
      lastTapRef.current = { time: 0, x: 0 };
    } else {
      lastTapRef.current = { time: currentTime, x };
      singleTapTimeoutRef.current = setTimeout(() => {
        const centerXStart = rect.width * 0.35;
        const centerXEnd = rect.width * 0.65;
        const centerYStart = rect.height * 0.25;
        const centerYEnd = rect.height * 0.75;

        if (x >= centerXStart && x <= centerXEnd && y >= centerYStart && y <= centerYEnd) {
          handlePlayPause();
        } else {
          setShowControls(prev => !prev);
        }
      }, 300);
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setVolume(parseFloat(e.target.value));
    setMuted(parseFloat(e.target.value) === 0);
  };
  
  const handleToggleMuted = () => setMuted(!muted);
  
  const handleProgress = (state: { played: number, loaded: number }) => {
    if (!seeking) {
      setPlayed(state.played);
    }
  };
  
  const [seeking, setSeeking] = useState(false);
  
  const handleSeekMouseDown = () => setSeeking(true);
  const handleSeekChange = (e: React.ChangeEvent<HTMLInputElement>) => setPlayed(parseFloat(e.target.value));
  const handleSeekMouseUp = (e: React.MouseEvent<HTMLInputElement>) => {
    setSeeking(false);
    if (playerRef.current && duration) {
       playerRef.current.currentTime = parseFloat((e.target as HTMLInputElement).value) * duration;
    }
  };
  const handleSeekTouchEnd = (e: React.TouchEvent<HTMLInputElement>) => {
    setSeeking(false);
    if (playerRef.current && duration) {
       playerRef.current.currentTime = parseFloat((e.target as HTMLInputElement).value) * duration;
    }
  };

  const [doubleTapInd, setDoubleTapInd] = useState<'left' | 'right' | null>(null);
  const [isPortrait, setIsPortrait] = useState(window.innerHeight > window.innerWidth);

  useEffect(() => {
    const checkOrientation = () => {
      setIsPortrait(window.innerHeight > window.innerWidth);
    };
    window.addEventListener('resize', checkOrientation);
    window.addEventListener('orientationchange', checkOrientation);
    return () => {
      window.removeEventListener('resize', checkOrientation);
      window.removeEventListener('orientationchange', checkOrientation);
    };
  }, []);

  const isMobilePortrait = isFullscreen && isPortrait && window.innerWidth < 1024;

  const skipForward = () => {
    if (playerRef.current) {
      playerRef.current.currentTime = (played * duration) + 10;
      setDoubleTapInd('right');
      setTimeout(() => setDoubleTapInd(null), 500);
    }
  };

  const skipBackward = () => {
    if (playerRef.current) {
      playerRef.current.currentTime = (played * duration) - 10;
      setDoubleTapInd('left');
      setTimeout(() => setDoubleTapInd(null), 500);
    }
  };

  const handlePlaybackRateChange = (rate: number) => {
    setPlaybackRate(rate);
    setShowSettings(null);
  };

  const handleFullscreen = () => {
    if (!isFullscreen) {
      if (screenfull.isEnabled && containerRef.current) {
        screenfull.request(containerRef.current).then(() => {
          try {
            if (window.screen && window.screen.orientation && (window.screen.orientation as any).lock) {
              (window.screen.orientation as any).lock('landscape').catch(() => {});
            } else if (window.screen && (window.screen as any).lockOrientation) {
              (window.screen as any).lockOrientation('landscape');
            } else if (window.screen && (window.screen as any).mozLockOrientation) {
              (window.screen as any).mozLockOrientation('landscape');
            } else if (window.screen && (window.screen as any).msLockOrientation) {
              (window.screen as any).msLockOrientation('landscape');
            }
          } catch(e) {}
        }).catch(() => {});
      } else {
        setIsFullscreen(true);
      }
    } else {
      if (screenfull.isEnabled) {
        screenfull.exit();
        try {
          if (window.screen && window.screen.orientation && (window.screen.orientation as any).unlock) {
            (window.screen.orientation as any).unlock();
          } else if (window.screen && (window.screen as any).unlockOrientation) {
            (window.screen as any).unlockOrientation();
          } else if (window.screen && (window.screen as any).mozUnlockOrientation) {
            (window.screen as any).mozUnlockOrientation();
          } else if (window.screen && (window.screen as any).msUnlockOrientation) {
            (window.screen as any).msUnlockOrientation();
          }
        } catch(e) {}
      } else {
        setIsFullscreen(false);
      }
    }
  };

  useEffect(() => {
    if (screenfull.isEnabled) {
      const changeHandler = () => {
        setIsFullscreen(screenfull.isFullscreen);
        if (!screenfull.isFullscreen) {
          try {
            if (window.screen && window.screen.orientation && (window.screen.orientation as any).unlock) {
              (window.screen.orientation as any).unlock();
            } else if (window.screen && (window.screen as any).unlockOrientation) {
              (window.screen as any).unlockOrientation();
            } else if (window.screen && (window.screen as any).mozUnlockOrientation) {
              (window.screen as any).mozUnlockOrientation();
            } else if (window.screen && (window.screen as any).msUnlockOrientation) {
              (window.screen as any).msUnlockOrientation();
            }
          } catch(e) {}
        }
      };
      screenfull.on('change', changeHandler);
      return () => screenfull.off('change', changeHandler);
    }
  }, []);

  const handleMouseMove = () => {
    setShowControls(true);
    if (controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current);
    controlsTimeoutRef.current = setTimeout(() => {
      if (playing) setShowControls(false);
      setShowSettings(null);
    }, 3000);
  };

  const formatTime = (seconds: number) => {
    const date = new Date(seconds * 1000);
    const hh = date.getUTCHours();
    const mm = date.getUTCMinutes();
    const ss = date.getUTCSeconds().toString().padStart(2, '0');
    if (hh) return `${hh}:${mm.toString().padStart(2, '0')}:${ss}`;
    return `${mm}:${ss}`;
  };

  const handlePointerLeave = (e: React.PointerEvent<HTMLDivElement>) => {
    if (pressHoldRef.current) {
      clearTimeout(pressHoldRef.current);
      pressHoldRef.current = null;
    }
    if (isHolding) {
      setIsHolding(false);
      setPlaybackRate(originalPlaybackRateRef.current);
      setShowControls(false);
    }
  };

  const cleanUrl = typeof url === 'string' 
    ? url.replace(/([?&])list=[^&]+/ig, '').replace(/([?&])index=[^&]+/ig, '').replace(/[?&]$/, '').replace(/\?&/, '?')
    : url;

  return (
    <div 
      ref={containerRef}
      className={`relative bg-black flex justify-center items-center overflow-hidden group font-sans ${isFullscreen ? 'w-screen h-screen z-[100] fixed top-0 left-0' : 'w-full aspect-video rounded-3xl shadow-2xl ring-1 ring-white/10'}`}
      onMouseMove={handleMouseMove}
      onTouchStart={handleMouseMove}
      onClick={() => setShowControls(true)}
      onMouseLeave={() => { if (playing) setShowControls(false); setShowSettings(null); }}
    >
      <div 
        style={
          isMobilePortrait 
            ? {
                position: 'absolute',
                width: '100vh',
                height: '100vw',
                top: '50%',
                left: '50%',
                transform: 'translate(-50%, -50%) rotate(90deg)',
                transformOrigin: 'center center',
              }
            : {
                position: 'absolute',
                width: '100%',
                height: '100%',
                top: 0,
                left: 0,
              }
        }
        className="overflow-hidden flex items-center justify-center"
      >
      {isHolding && (
         <div className="absolute top-8 left-1/2 -translate-x-1/2 bg-black/80 px-4 py-1.5 rounded-full z-50 text-white text-sm font-medium flex items-center gap-2 tracking-wide">
            Fast forward &middot; 2x speed
         </div>
      )}

      {/* Double Tap Indicators */}
      <div className={`absolute top-0 bottom-0 left-0 w-1/2 bg-white/20 z-40 pointer-events-none transition-opacity duration-300 rounded-r-full blur-xl ${doubleTapInd === 'left' ? 'opacity-100 scale-100' : 'opacity-0 scale-95'}`} style={{ transformOrigin: 'left center' }} />
      <div className={`absolute inset-y-0 left-16 flex flex-col justify-center items-center z-50 transition-opacity duration-300 pointer-events-none ${doubleTapInd === 'left' ? 'opacity-100' : 'opacity-0'}`}>
         <RotateCcw className="w-8 h-8 text-white mb-2 animate-[spin_1s_ease-in-out_infinite] -rotate-45" />
         <span className="text-white font-bold">10 seconds</span>
      </div>

      <div className={`absolute top-0 bottom-0 right-0 w-1/2 bg-white/20 z-40 pointer-events-none transition-opacity duration-300 rounded-l-full blur-xl ${doubleTapInd === 'right' ? 'opacity-100 scale-100' : 'opacity-0 scale-95'}`} style={{ transformOrigin: 'right center' }} />
      <div className={`absolute inset-y-0 right-16 flex flex-col justify-center items-center z-50 transition-opacity duration-300 pointer-events-none ${doubleTapInd === 'right' ? 'opacity-100' : 'opacity-0'}`}>
         <RotateCw className="w-8 h-8 text-white mb-2 animate-[spin_1s_ease-in-out_infinite] rotate-45" />
         <span className="text-white font-bold">10 seconds</span>
      </div>

      {/* Click blocker to hide YouTube native UI and capture clicks */}
      <div 
        className={`absolute inset-0 z-10 transition-all duration-300 ${!playing ? 'bg-transparent' : ''}`} 
        onPointerDown={handlePointerDown}
        onPointerUp={handlePointerUp}
        onPointerLeave={handlePointerLeave}
        onContextMenu={(e) => {
           // Prevent right click on overlay to avoid interfering with tap
           e.preventDefault();
        }}
      ></div>
      
      <div className="absolute inset-0 pointer-events-none scale-[1.02]">
        <ReactPlayer
          key={captionsEnabled ? 'cc-on' : 'cc-off'}
          ref={playerRef}
          src={cleanUrl}
          width="100%"
          height="100%"
          playing={playing}
          controls={false}
          volume={volume}
          muted={muted}
          playbackRate={playbackRate}
          onDurationChange={(e: any) => setDuration(e.target?.duration || 0)}
          onTimeUpdate={(e: any) => {
            if (!seeking && e.target?.duration) {
               setPlayed((e.target?.currentTime || 0) / e.target.duration);
            }
          }}
          onPlay={() => setPlaying(true)}
          onPause={() => setPlaying(false)}
          onReady={handlePlayerReady}
          config={{
            youtube: {
              playerVars: { 
                showinfo: 0, 
                rel: 0, 
                modestbranding: 1, 
                iv_load_policy: 3, 
                fs: 0, 
                disablekb: 1,
                cc_load_policy: captionsEnabled ? 1 : 0,
                cc_lang_pref: captionsEnabled ? 'bn' : 'none',
                hl: 'bn'
              }
            } as any
          }}
          style={{ pointerEvents: 'none' }} // Crucial: prevents interacting directly with YT iframe
        />
      </div>

      {/* Controls Overlay */}
      <div className={`absolute inset-0 z-20 transition-opacity duration-300 flex flex-col justify-between ${showControls || !playing ? 'opacity-100' : 'opacity-0'} pointer-events-none`}>
        
        {/* Top Right: Speed Indicator */}
        <div className="flex justify-end p-4">
          <button 
            onClick={(e) => { e.stopPropagation(); setShowSettings(showSettings === 'speed' ? null : 'speed'); }}
            className="pointer-events-auto bg-black/60 hover:bg-black/80 px-3 py-1 rounded-md text-white font-bold text-sm backdrop-blur transition-colors"
          >
            {playbackRate === 1 ? 'Normal' : `${playbackRate}x`}
          </button>
        </div>

        {/* Bottom Controls */}
        <div className="w-full bg-gradient-to-t from-black/90 via-black/80 to-transparent pt-8 pb-2 px-0 pointer-events-auto flex flex-col mt-auto">
          
          {/* Scrubber Full Width */}
          <div className="w-full relative flex items-center group cursor-pointer h-5 px-3 md:px-4 mb-1"
             onMouseDown={handleSeekMouseDown}
             onTouchStart={handleSeekMouseDown}
          >
            <input
              type="range"
              min={0}
              max={1}
              step="any"
              value={played}
              onChange={handleSeekChange}
              onMouseUp={handleSeekMouseUp}
              onTouchEnd={handleSeekTouchEnd}
              className="w-full absolute z-30 opacity-0 cursor-pointer h-full left-0 right-0 mx-3 md:mx-4"
              style={{ width: 'calc(100% - 24px)' }}
            />
            {/* Progress Track */}
            <div className="w-full h-1 md:h-[3px] bg-white/30 relative overflow-hidden pointer-events-none rounded-full">
              <div 
                className="absolute top-0 left-0 h-full bg-red-600"
                style={{ width: `${played * 100}%` }}
              />
            </div>
            {/* Thumb indicator */}
            <div 
               className="w-3 h-3 md:w-3.5 md:h-3.5 bg-red-600 rounded-full absolute pointer-events-none scale-0 group-hover:scale-100 transition-transform origin-center shadow"
               style={{ left: `calc(${played * 100}% + 6px)` }}
            />
          </div>

          {/* Bottom Bar Buttons */}
          <div className="flex items-center justify-between px-3 md:px-4 pt-2">
            
            <div className="flex items-center gap-3 md:gap-4">
              {/* Play/Pause */}
              <button onClick={handlePlayPause} className="text-white hover:text-white/80 transition-colors">
                {playing ? <Pause className="w-5 h-5 md:w-6 md:h-6 fill-current" /> : <Play className="w-5 h-5 md:w-6 md:h-6 fill-current" />}
              </button>

              {/* Time Progress */}
              <div className="flex flex-col">
                <div className="text-white text-xs md:text-sm font-medium tracking-wide">
                  {formatTime(played * duration)} <span className="opacity-70 mx-0.5">/</span> {formatTime(duration)}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-4">
              {/* CC Button */}
              <button 
                onClick={(e) => { 
                  e.stopPropagation(); 
                  setCaptionsEnabled(!captionsEnabled); 
                }} 
                className={`px-2 py-0.5 rounded text-xs font-bold transition-all border shrink-0 ${captionsEnabled ? 'bg-indigo-600 text-white border-indigo-500 shadow-[0_0_8px_rgba(99,102,241,0.5)]' : 'bg-black/40 text-slate-300 border-white/20 hover:text-white hover:border-white/40'}`}
                title={captionsEnabled ? "Turn off captions (ক্যাপশন বন্ধ করুন)" : "Turn on captions (ক্যাপশন চালু করুন)"}
              >
                CC
              </button>

              {/* Quality Text Button */}
              <button onClick={(e) => { e.stopPropagation(); setShowSettings(showSettings === 'quality' ? null : 'quality'); }} className="text-white font-semibold text-sm md:text-base hover:text-white/80 transition-colors">
                {quality}
              </button>

              {/* Fullscreen */}
              <button onClick={handleFullscreen} className="text-white hover:text-white/80 transition-colors">
                {isFullscreen ? <Minimize className="w-5 h-5 md:w-6 md:h-6" /> : <Maximize className="w-5 h-5 md:w-6 md:h-6" />}
              </button>
            </div>
            
          </div>
        </div>
      </div>
      
      {/* Settings Side Panel */}
      <div 
        className={`absolute top-0 right-0 bottom-0 w-64 bg-slate-900/95 backdrop-blur-xl border-l border-white/10 shadow-2xl p-4 text-sm z-[100] flex flex-col h-full pointer-events-auto transition-transform duration-300 ease-out transform ${showSettings ? 'translate-x-0' : 'translate-x-full'}`}
      >
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-white/10 shrink-0 mt-2">
           <h3 className="text-white font-bold text-base">{showSettings === 'speed' ? 'Playback Speed' : 'Video Settings'}</h3>
           <button onClick={(e) => { e.stopPropagation(); setShowSettings(null); }} className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-white/10 transition-colors">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"/></svg>
           </button>
        </div>
        
        <div className="flex-1 overflow-y-auto custom-scrollbar pr-2 mb-safe">
          {showSettings === 'speed' && (
            <div className="mb-6">
              <div className="space-y-1">
                {[0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2].map(rate => (
                  <button
                    key={rate}
                    onClick={(e) => { e.stopPropagation(); handlePlaybackRateChange(rate); }}
                    className={`w-full text-left px-3 py-2.5 rounded-xl transition-colors flex items-center justify-between ${playbackRate === rate ? 'bg-indigo-600/20 text-indigo-400 font-bold border border-indigo-500/30' : 'text-slate-300 hover:bg-white/10 border border-transparent'}`}
                  >
                    <span>{rate === 1 ? 'Normal' : `${rate}x`}</span>
                    {playbackRate === rate && <div className="w-2 h-2 rounded-full bg-indigo-400"></div>}
                  </button>
                ))}
              </div>
            </div>
          )}
          
          {showSettings === 'quality' && (
            <div>
              <div className="space-y-1">
                 {['Auto', '1080p', '720p', '480p'].map(q => (
                    <button
                      key={q}
                      onClick={(e) => { e.stopPropagation(); setQuality(q); setShowSettings(null); }}
                      className={`w-full text-left px-3 py-2.5 rounded-xl transition-colors flex items-center justify-between ${quality === q ? 'bg-indigo-600/20 text-indigo-400 font-bold border border-indigo-500/30' : 'text-slate-300 hover:bg-white/10 border border-transparent'}`}
                    >
                      <span>{q}</span>
                      {quality === q && <div className="w-2 h-2 rounded-full bg-indigo-400"></div>}
                    </button>
                 ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
    </div>
  );
}
