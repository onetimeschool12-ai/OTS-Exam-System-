import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useStore } from './store/useStore';
import Landing from './screens/Landing';
import AdminLogin from './screens/AdminLogin';
import StudentDashboard from './screens/student/StudentDashboard';
import StudentProfile from './screens/student/StudentProfile';
import ExamView from './screens/student/ExamView';
import ResultView from './screens/student/ResultView';
import AdminLayout from './screens/admin/AdminLayout';
import AdminDashboard from './screens/admin/AdminDashboard';
import AdminExams from './screens/admin/AdminExams';
import AdminExamForm from './screens/admin/AdminExamForm';
import AdminUsers from './screens/admin/AdminUsers';
import AdminLeaderboard from './screens/admin/AdminLeaderboard';
import AdminEvents from './screens/admin/AdminEvents';
import AdminCourses from './screens/admin/AdminCourses';
import AdminBanners from './screens/admin/AdminBanners';
import AdminCategories from './screens/admin/AdminCategories';
import AdminPayments from './screens/admin/AdminPayments';
import AdminFAQ from './screens/admin/AdminFAQ';
import AdminReferrals from './screens/admin/AdminReferrals';
import SecurityEnforcer from './components/SecurityEnforcer';

export default function App() {
  const currentUser = useStore(state => state.currentUser);
  const checkUpcomingExams = useStore(state => state.checkUpcomingExams);
  const syncFromCloud = useStore(state => state.syncFromCloud);
  const [hydrated, setHydrated] = React.useState(false);

  React.useEffect(() => {
    // Listen for hydration complete to avoid race issues with async indexedDB
    if (useStore.persist?.hasHydrated()) {
      setHydrated(true);
    } else {
      const unsub = useStore.persist?.onFinishHydration(() => {
        setHydrated(true);
      });
      return () => {
        if (unsub) unsub();
      };
    }
  }, []);

  React.useEffect(() => {
    if (hydrated) {
      syncFromCloud();
    }
  }, [hydrated, syncFromCloud]);

  React.useEffect(() => {
    if (currentUser?.role === 'user') {
      // Check immediately
      checkUpcomingExams();
      
      // Check every 5 minutes
      const interval = setInterval(() => {
        checkUpcomingExams();
      }, 5 * 60 * 1000);

      return () => clearInterval(interval);
    }
  }, [currentUser, checkUpcomingExams, hydrated]);

  if (!hydrated) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6">
        <div className="flex flex-col items-center gap-4 text-center">
          <div className="relative w-16 h-16">
            <div className="absolute inset-0 rounded-full border-4 border-indigo-100" />
            <div className="absolute inset-0 rounded-full border-4 border-indigo-600 border-t-transparent animate-spin" />
          </div>
          <h2 className="text-xl font-extrabold text-slate-900 tracking-tight font-display mt-2">OTS EXAM SYSTEM</h2>
          <p className="text-xs text-slate-400 font-black uppercase tracking-widest">Syncing portal session & course data...</p>
        </div>
      </div>
    );
  }

  return (
    <BrowserRouter>
      <SecurityEnforcer />
      <div className="min-h-screen bg-slate-50 text-slate-800 font-sans selection:bg-indigo-100 selection:text-indigo-900 select-none">
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/admin-login" element={<AdminLogin />} />
          
          {/* Admin Routes */}
          <Route path="/admin/*" element={
            currentUser?.role === 'admin' ? (
              <AdminLayout />
            ) : (
              <Navigate to="/admin-login" />
            )
          }>
             <Route index element={<AdminDashboard />} />
             <Route path="exams" element={<AdminExams />} />
             <Route path="exams/new" element={<AdminExamForm />} />
             <Route path="exams/:id/edit" element={<AdminExamForm />} />
             <Route path="events" element={<AdminEvents />} />
             <Route path="users" element={<AdminUsers />} />
             <Route path="payments" element={<AdminPayments />} />
             <Route path="courses" element={<AdminCourses />} />
             <Route path="banners" element={<AdminBanners />} />
             <Route path="categories" element={<AdminCategories />} />
             <Route path="leaderboard" element={<AdminLeaderboard />} />
             <Route path="referrals" element={<AdminReferrals />} />
             <Route path="faqs" element={<AdminFAQ />} />
          </Route>

          {/* Student Routes */}
          <Route path="/student/*" element={
            currentUser?.role === 'user' ? (
              <Routes>
                 <Route index element={<StudentDashboard />} />
                 <Route path="profile" element={<StudentProfile />} />
                 <Route path="exam/:id" element={<ExamView />} />
                 <Route path="result/:id" element={<ResultView />} />
                 <Route path="*" element={<Navigate to="/student" />} />
              </Routes>
            ) : (
              <Navigate to="/" />
            )
          } />
          
        </Routes>
      </div>
    </BrowserRouter>
  );
}
